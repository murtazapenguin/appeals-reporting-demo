"""
Penguin Agents Module

Provides agent functionality for LLM + tool orchestration.

Classes:
    Agent: Reusable agent with pre-configured LLM and tools
    AgentResponse: Response container from agent runs
    ToolGeneratorService: Generate tools from natural language
    GeneratedTool: Container for generated tools awaiting registration
    CodeGeneratorAgent: Agent for generating code from workflow descriptions
    WorkflowSuggestionAgent: Agent for workflow design and orchestration

Functions:
    chat_with_tools: Execute an agentic loop with tool execution
"""

from .base import Agent, AgentResponse, chat_with_tools
from .tool_generator import ToolGeneratorService, GeneratedTool
from .coder import CodeGeneratorAgent, PenguinCoderAgent
from .workflow import WorkflowSuggestionAgent

__all__ = [
    "Agent",
    "AgentResponse",
    "chat_with_tools",
    "ToolGeneratorService",
    "GeneratedTool",
    "CodeGeneratorAgent",
    "PenguinCoderAgent",  # Backwards compat alias
    "WorkflowSuggestionAgent",
]
