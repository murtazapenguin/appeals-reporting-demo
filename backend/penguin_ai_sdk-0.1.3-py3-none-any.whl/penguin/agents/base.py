"""
Penguin Agent Module

Provides agentic loop functionality - binding LLM calls with tool execution.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from penguin.llm import UserMessage, AssistantMessage, ToolMessage
from penguin.llm.base import BaseChatCompletionClient
from penguin.tools import ToolExecutor

# Tracing support
from penguin.observability.config import is_tracing_enabled, should_capture_content, get_tracer
from penguin.observability.attributes import GenAIAttributes, GenAISpanKind

logger = logging.getLogger(__name__)


@dataclass
class AgentResponse:
    """Response from an agent run."""
    answer: str
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    iterations: int = 0
    total_tokens: int = 0


async def chat_with_tools(
    prompt: str,
    client: BaseChatCompletionClient,
    executor: ToolExecutor,
    system_prompt: Optional[str] = None,
    max_iterations: int = 10,
    max_tokens: int = 4096,
    temperature: float = 0.7,
    verbose: bool = False,
) -> AgentResponse:
    """
    Execute an agentic loop: LLM decides when to use tools, executes them,
    and provides a final answer.

    Args:
        prompt: User's question/request
        client: LLM client (from create_client)
        executor: ToolExecutor with registered tools
        system_prompt: Optional system prompt
        max_iterations: Maximum tool-call rounds before giving up
        max_tokens: Max tokens per LLM call
        temperature: LLM temperature
        verbose: Print debug information

    Returns:
        AgentResponse with final answer and tool call log

    Example:
        from penguin.llm import create_client
        from penguin.tools import tool, ToolExecutor
        from penguin.agents import chat_with_tools

        @tool
        def get_weather(city: str) -> str:
            return f"Weather in {city}: Sunny"

        client = create_client("bedrock", model="claude-sonnet-4-5")
        executor = ToolExecutor([get_weather])

        result = await chat_with_tools(
            "What's the weather in NYC?",
            client,
            executor
        )
        print(result.answer)
    """
    # Execute with tracing if enabled
    if is_tracing_enabled():
        return await _chat_with_tools_traced(
            prompt, client, executor, system_prompt,
            max_iterations, max_tokens, temperature, verbose
        )
    else:
        return await _chat_with_tools_impl(
            prompt, client, executor, system_prompt,
            max_iterations, max_tokens, temperature, verbose
        )


async def _chat_with_tools_traced(
    prompt: str,
    client: BaseChatCompletionClient,
    executor: ToolExecutor,
    system_prompt: Optional[str],
    max_iterations: int,
    max_tokens: int,
    temperature: float,
    verbose: bool,
) -> AgentResponse:
    """Execute chat_with_tools with OpenTelemetry tracing."""
    tracer = get_tracer("penguin.agent")

    with tracer.start_as_current_span("agent.run") as span:
        # Set agent attributes
        span.set_attribute(GenAIAttributes.SPAN_TYPE, "agent")
        span.set_attribute(GenAIAttributes.REQUEST_MODEL, client.model)
        span.set_attribute(GenAIAttributes.SYSTEM, client.provider_name)
        span.set_attribute("gen_ai.agent.max_iterations", max_iterations)
        span.set_attribute("gen_ai.agent.tools", executor.list_names())

        # Capture prompt if enabled
        if should_capture_content():
            span.set_attribute(GenAIAttributes.PROMPT, prompt[:10000])
            if system_prompt:
                span.set_attribute("gen_ai.system_prompt", system_prompt[:5000])

        try:
            result = await _chat_with_tools_impl(
                prompt, client, executor, system_prompt,
                max_iterations, max_tokens, temperature, verbose
            )

            # Record completion attributes
            span.set_attribute("gen_ai.agent.iterations", result.iterations)
            span.set_attribute("gen_ai.agent.total_tokens", result.total_tokens)
            span.set_attribute("gen_ai.agent.tool_call_count", len(result.tool_calls))

            # Capture answer if enabled
            if should_capture_content() and result.answer:
                span.set_attribute(GenAIAttributes.COMPLETION, result.answer[:10000])

            return result

        except Exception as e:
            span.record_exception(e)
            raise


async def _chat_with_tools_impl(
    prompt: str,
    client: BaseChatCompletionClient,
    executor: ToolExecutor,
    system_prompt: Optional[str],
    max_iterations: int,
    max_tokens: int,
    temperature: float,
    verbose: bool,
) -> AgentResponse:
    """Core implementation of chat_with_tools (without tracing wrapper)."""
    # Convert tools to provider format
    tools = executor.to_provider_format(client.provider_name)

    # Build initial messages
    messages = []
    if system_prompt:
        from penguin.llm import SystemMessage
        messages.append(SystemMessage(system_prompt))
    messages.append(UserMessage(prompt))

    tool_calls_log = []
    total_tokens = 0

    # Get tracer for LLM call spans (will be no-op if tracing disabled)
    tracer = get_tracer("penguin.llm")

    for iteration in range(max_iterations):
        if verbose:
            logger.info(f"Agent iteration {iteration + 1}")

        # Call LLM with optional tracing
        with tracer.start_as_current_span(f"llm.create") as llm_span:
            llm_span.set_attribute(GenAIAttributes.SPAN_TYPE, GenAISpanKind.LLM)
            llm_span.set_attribute(GenAIAttributes.REQUEST_MODEL, client.model)
            llm_span.set_attribute(GenAIAttributes.SYSTEM, client.provider_name)
            llm_span.set_attribute(GenAIAttributes.REQUEST_MAX_TOKENS, max_tokens)
            llm_span.set_attribute(GenAIAttributes.REQUEST_TEMPERATURE, temperature)
            llm_span.set_attribute("gen_ai.agent.iteration", iteration + 1)

            result = await client.create(
                messages,
                tools=tools,
                max_tokens=max_tokens,
                temperature=temperature
            )

            # Record token usage
            if result.usage:
                total_tokens += result.usage.total_tokens
                llm_span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, result.usage.prompt_tokens)
                llm_span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, result.usage.completion_tokens)
                llm_span.set_attribute(GenAIAttributes.USAGE_TOTAL_TOKENS, result.usage.total_tokens)

            llm_span.set_attribute("gen_ai.response.finish_reason", result.finish_reason or "unknown")
            llm_span.set_attribute("gen_ai.response.tool_calls", len(result.tool_calls or []))

        if verbose:
            logger.info(f"LLM response: content={result.content is not None}, "
                       f"tool_calls={len(result.tool_calls or [])}, "
                       f"finish_reason={result.finish_reason}")

        # Check if LLM wants to use tools
        if result.tool_calls:
            # Add assistant message with tool calls
            messages.append(AssistantMessage(
                content=result.content or "",
                tool_calls=result.tool_calls
            ))

            # Execute each tool call (tracing is handled in executor.execute())
            for tc in result.tool_calls:
                if verbose:
                    logger.info(f"Executing tool: {tc.tool_name}({tc.parameters})")

                tool_result = await executor.execute(tc)

                if verbose:
                    logger.info(f"Tool result: {tool_result.content}")

                tool_calls_log.append({
                    "tool": tc.tool_name,
                    "input": tc.parameters,
                    "output": tool_result.content,
                    "success": tool_result.success,
                    "error": tool_result.error
                })

                # Add tool result to messages
                messages.append(ToolMessage(
                    tool_call_id=tc.call_id,
                    tool_name=tc.tool_name,
                    content=tool_result.to_message_content(),
                    is_error=not tool_result.success
                ))

            # Continue loop to get LLM's response to tool results
            continue

        else:
            # No tool calls - LLM has final answer
            return AgentResponse(
                answer=result.content or "",
                tool_calls=tool_calls_log,
                iterations=iteration + 1,
                total_tokens=total_tokens
            )

    # Max iterations reached
    logger.warning(f"Max iterations ({max_iterations}) reached without final answer")
    return AgentResponse(
        answer="I wasn't able to complete the task within the allowed iterations.",
        tool_calls=tool_calls_log,
        iterations=max_iterations,
        total_tokens=total_tokens
    )


class Agent:
    """
    Reusable agent with pre-configured LLM and tools.

    Example:
        agent = Agent(
            client=create_client("bedrock", model="claude-sonnet-4-5"),
            tools=[get_weather, calculate],
            system_prompt="You are a helpful assistant."
        )

        result = await agent.run("What's the weather in NYC?")
        print(result.answer)
    """

    def __init__(
        self,
        client: BaseChatCompletionClient,
        tools: List[Any],
        system_prompt: Optional[str] = None,
        max_iterations: int = 10,
        max_tokens: int = 4096,
        temperature: float = 0.7,
    ):
        """
        Initialize an agent.

        Args:
            client: LLM client
            tools: List of tools (decorated with @tool or BaseTool instances)
            system_prompt: Optional system prompt
            max_iterations: Max tool-call rounds
            max_tokens: Max tokens per LLM call
            temperature: LLM temperature
        """
        self.client = client
        self.executor = ToolExecutor(tools)
        self.system_prompt = system_prompt
        self.max_iterations = max_iterations
        self.max_tokens = max_tokens
        self.temperature = temperature

    async def run(self, prompt: str, verbose: bool = False) -> AgentResponse:
        """
        Run the agent with a prompt.

        Args:
            prompt: User's question/request
            verbose: Print debug info

        Returns:
            AgentResponse with answer and tool call log
        """
        return await chat_with_tools(
            prompt=prompt,
            client=self.client,
            executor=self.executor,
            system_prompt=self.system_prompt,
            max_iterations=self.max_iterations,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            verbose=verbose
        )

    def add_tool(self, tool) -> None:
        """Add a tool to the agent."""
        self.executor.register(tool)

    @property
    def tools(self) -> List[str]:
        """List tool names."""
        return [t.name for t in self.executor.list_tools()]
