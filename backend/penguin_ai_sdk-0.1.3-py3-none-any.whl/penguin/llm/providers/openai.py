"""
Penguin OpenAI LLM Provider

OpenAI GPT implementation of BaseChatCompletionClient.
"""

import json
import os
from typing import Any, AsyncGenerator, Dict, List, Optional, Type

from openai import AsyncOpenAI
from pydantic import BaseModel

from ..base import (
    BaseChatCompletionClient,
    ChatCompletionError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
    ContentFilterError,
)
from ..messages import (
    Message,
    SystemMessage,
    UserMessage,
    AssistantMessage,
    ToolMessage,
    ToolCall,
)
from ..types import (
    ChatCompletionResult,
    ChatCompletionChunk,
    TokenUsage,
    ProviderCapabilities,
    FinishReason,
)
from ..models import get_model


class OpenAIChatClient(BaseChatCompletionClient):
    """
    OpenAI GPT chat completion client.

    Supports:
    - GPT-4o, GPT-4o-mini, GPT-4-turbo
    - GPT-3.5-turbo
    - Structured output via JSON Schema
    - Tool/function calling
    - Streaming responses
    """

    def __init__(
        self,
        model: str = "gpt-4o",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        organization: Optional[str] = None,
        **kwargs: Any
    ):
        """
        Initialize OpenAI client.

        Args:
            model: Model identifier (e.g., "gpt-4o", "gpt-4o-mini")
            api_key: API key (falls back to OPENAI_API_KEY env var)
            base_url: Optional custom base URL (for Azure or proxies)
            organization: Optional organization ID
            **kwargs: Additional configuration
        """
        api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise AuthenticationError(
                "OPENAI_API_KEY environment variable is required",
                provider="openai"
            )

        super().__init__(model=model, api_key=api_key, **kwargs)

        client_kwargs = {"api_key": api_key}
        if base_url:
            client_kwargs["base_url"] = base_url
        if organization:
            client_kwargs["organization"] = organization

        self.client = AsyncOpenAI(**client_kwargs)

    @property
    def provider_name(self) -> str:
        return "openai"

    @property
    def capabilities(self) -> ProviderCapabilities:
        # Get capabilities from centralized model registry
        model_info = get_model(self.model)
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tool_calls=True,
            supports_vision=model_info.supports_vision if model_info else False,
            supports_thinking=model_info.supports_thinking if model_info else False,
            supports_structured_output=True,
            supports_system_message=True,
            max_context_tokens=model_info.context_window if model_info else 128000,
            max_output_tokens=model_info.max_tokens if model_info else 16384,
        )

    # ================== MESSAGE CONVERSION ==================

    def _convert_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """
        Convert Penguin messages to OpenAI format.

        OpenAI uses the standard format that our Message classes are based on.
        """
        return self._convert_messages_to_openai_format(messages)

    def _convert_tools(
        self,
        tools: Optional[List[Dict[str, Any]]]
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Convert tools to OpenAI format.

        OpenAI expects tools in this format:
        {
            "type": "function",
            "function": {
                "name": "...",
                "description": "...",
                "parameters": { JSON Schema }
            }
        }
        """
        if not tools:
            return None

        openai_tools = []
        for tool in tools:
            # Handle both flat format and nested format
            if "type" in tool and tool["type"] == "function":
                # Already in OpenAI format
                openai_tools.append(tool)
            else:
                # Flat format - check for both "parameters" and "input_schema" (Anthropic format)
                schema = tool.get("input_schema") or tool.get("parameters", {})
                openai_tools.append({
                    "type": "function",
                    "function": {
                        "name": tool.get("name", ""),
                        "description": tool.get("description", ""),
                        "parameters": schema,
                    }
                })
        return openai_tools

    # ================== RESPONSE NORMALIZATION ==================

    def _normalize_response(self, response: Any) -> ChatCompletionResult:
        """Normalize OpenAI response to standard format."""
        choice = response.choices[0] if response.choices else None

        content = None
        tool_calls = None

        if choice and choice.message:
            msg = choice.message
            content = msg.content

            # Parse tool calls
            if msg.tool_calls:
                tool_calls = []
                for tc in msg.tool_calls:
                    # Parse arguments from JSON string
                    try:
                        params = json.loads(tc.function.arguments) if tc.function.arguments else {}
                    except json.JSONDecodeError:
                        params = {"raw": tc.function.arguments}

                    tool_calls.append(ToolCall(
                        call_id=tc.id,
                        tool_name=tc.function.name,
                        parameters=params
                    ))

        finish_reason = self._map_finish_reason(choice)
        usage = self._normalize_usage(response.usage)

        return ChatCompletionResult(
            content=content,
            tool_calls=tool_calls,
            thinking=None,  # OpenAI doesn't have extended thinking
            finish_reason=finish_reason,
            usage=usage,
            model=response.model,
            provider=self.provider_name,
            raw_response=response,
        )

    def _map_finish_reason(self, choice: Any) -> FinishReason:
        """Map OpenAI finish reason to standard format."""
        if not choice:
            return FinishReason.ERROR

        reason = getattr(choice, 'finish_reason', None)
        if reason:
            mapping = {
                "stop": FinishReason.STOP,
                "length": FinishReason.LENGTH,
                "tool_calls": FinishReason.TOOL_CALLS,
                "content_filter": FinishReason.CONTENT_FILTER,
            }
            return mapping.get(reason, FinishReason.STOP)
        return FinishReason.STOP

    def _normalize_usage(self, usage: Any) -> TokenUsage:
        """Normalize OpenAI usage to standard format."""
        if not usage:
            return TokenUsage()
        return TokenUsage(
            prompt_tokens=getattr(usage, 'prompt_tokens', 0) or 0,
            completion_tokens=getattr(usage, 'completion_tokens', 0) or 0,
            total_tokens=getattr(usage, 'total_tokens', 0) or 0,
        )

    # ================== API CALLS ==================

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Execute OpenAI API call.

        Args:
            messages: Conversation messages
            tools: Tool definitions
            output_format: Pydantic model for structured output
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            **kwargs: Additional parameters (seed, top_p, etc.)
        """
        api_messages = self._convert_messages(messages)

        # Build request parameters
        request_params = {
            "model": self.model,
            "messages": api_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        # Optional parameters
        if "seed" in kwargs:
            request_params["seed"] = kwargs["seed"]
        if "top_p" in kwargs:
            request_params["top_p"] = kwargs["top_p"]

        # Tools
        converted_tools = self._convert_tools(tools)
        if converted_tools:
            request_params["tools"] = converted_tools

        # Structured output (supports both Pydantic models and raw schema dicts)
        if output_format:
            schema, schema_name = self._normalize_schema(output_format)
            # OpenAI strict mode requires additionalProperties: false
            self._add_additional_properties_false(schema)
            request_params["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": schema_name,
                    "schema": schema,
                    "strict": True,
                }
            }

        try:
            response = await self.client.chat.completions.create(**request_params)
            result = self._normalize_response(response)

            # Parse structured output if requested
            if output_format and result.content:
                try:
                    parsed = json.loads(result.content)
                    result.content = parsed
                except json.JSONDecodeError:
                    pass  # Keep raw content

            return result

        except Exception as e:
            self._handle_error(e)

    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Execute streaming OpenAI API call.

        Yields ChatCompletionChunk objects with incremental content.
        """
        api_messages = self._convert_messages(messages)

        request_params = {
            "model": self.model,
            "messages": api_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},  # Get usage in final chunk
        }

        # Optional parameters
        if "seed" in kwargs:
            request_params["seed"] = kwargs["seed"]

        # Tools
        converted_tools = self._convert_tools(tools)
        if converted_tools:
            request_params["tools"] = converted_tools

        try:
            stream = await self.client.chat.completions.create(**request_params)

            chunk_index = 0
            accumulated_tool_calls: Dict[int, Dict[str, Any]] = {}

            async for chunk in stream:
                delta_content = None
                delta_tool_calls = None
                finish_reason = None
                usage = None

                if chunk.choices:
                    choice = chunk.choices[0]
                    delta = choice.delta

                    # Extract text content
                    if delta and delta.content:
                        delta_content = delta.content

                    # Extract tool calls (streamed incrementally)
                    if delta and delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            idx = tc_delta.index
                            if idx not in accumulated_tool_calls:
                                accumulated_tool_calls[idx] = {
                                    "id": "",
                                    "name": "",
                                    "arguments": ""
                                }

                            if tc_delta.id:
                                accumulated_tool_calls[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    accumulated_tool_calls[idx]["name"] = tc_delta.function.name
                                if tc_delta.function.arguments:
                                    accumulated_tool_calls[idx]["arguments"] += tc_delta.function.arguments

                    # Check finish reason
                    if choice.finish_reason:
                        finish_reason = self._map_finish_reason(choice)

                        # If finish reason is tool_calls, emit the complete tool calls
                        if finish_reason == FinishReason.TOOL_CALLS and accumulated_tool_calls:
                            delta_tool_calls = []
                            for tc_data in accumulated_tool_calls.values():
                                try:
                                    params = json.loads(tc_data["arguments"]) if tc_data["arguments"] else {}
                                except json.JSONDecodeError:
                                    params = {"raw": tc_data["arguments"]}

                                delta_tool_calls.append(ToolCall(
                                    call_id=tc_data["id"],
                                    tool_name=tc_data["name"],
                                    parameters=params
                                ))

                # Extract usage from final chunk
                if chunk.usage:
                    usage = TokenUsage(
                        prompt_tokens=chunk.usage.prompt_tokens or 0,
                        completion_tokens=chunk.usage.completion_tokens or 0,
                        total_tokens=chunk.usage.total_tokens or 0,
                    )

                yield ChatCompletionChunk(
                    delta_content=delta_content,
                    delta_tool_calls=delta_tool_calls,
                    delta_thinking=None,
                    finish_reason=finish_reason,
                    usage=usage,
                    model=self.model,
                    provider=self.provider_name,
                    chunk_index=chunk_index,
                )
                chunk_index += 1

        except Exception as e:
            self._handle_error(e)

    def _handle_error(self, e: Exception) -> None:
        """Handle OpenAI API errors and convert to standard exceptions."""
        from openai import (
            APIError,
            RateLimitError as OpenAIRateLimitError,
            AuthenticationError as OpenAIAuthError,
            BadRequestError,
        )

        error_msg = str(e)

        if isinstance(e, OpenAIRateLimitError):
            raise RateLimitError(
                message=error_msg,
                provider=self.provider_name
            )
        elif isinstance(e, OpenAIAuthError):
            raise AuthenticationError(
                message=error_msg,
                provider=self.provider_name
            )
        elif isinstance(e, BadRequestError):
            if "content_filter" in error_msg.lower():
                raise ContentFilterError(
                    message=error_msg,
                    provider=self.provider_name
                )
            raise InvalidRequestError(
                message=error_msg,
                provider=self.provider_name
            )
        elif isinstance(e, APIError):
            raise ChatCompletionError(
                message=error_msg,
                provider=self.provider_name,
                status_code=getattr(e, 'status_code', None)
            )
        else:
            raise ChatCompletionError(
                message=error_msg,
                provider=self.provider_name
            )


# Backward compatibility alias
OpenAILLMProvider = OpenAIChatClient
