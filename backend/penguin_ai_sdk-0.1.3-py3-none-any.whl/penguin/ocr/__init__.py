"""
Penguin OCR Module

Multi-provider OCR abstraction supporting Azure Document Intelligence and AWS Textract.

Usage:
    from penguin.ocr import AzureOCRProvider, AWSTextractProvider

    # Azure
    azure_ocr = AzureOCRProvider()
    result = await azure_ocr.process_file("document.pdf")

    # AWS Textract
    aws_ocr = AWSTextractProvider()
    result = await aws_ocr.process_file("document.pdf")
"""

from .base import BaseOCRProvider
from .models import OCRResult, OCRLine, Point
from .providers.azure import AzureOCRProvider
from .providers.aws import AWSTextractProvider

__all__ = [
    "BaseOCRProvider",
    "OCRResult",
    "OCRLine",
    "Point",
    "AzureOCRProvider",
    "AWSTextractProvider",
]
