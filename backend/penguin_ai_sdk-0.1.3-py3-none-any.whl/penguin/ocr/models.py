from typing import List, Dict, Optional, Any
from pydantic import BaseModel

class Point(BaseModel):
    x: float
    y: float

class OCRLine(BaseModel):
    content: str
    page_number: int
    bounding_box: List[Dict[str, float]] # List of {x, y}
    confidence: Optional[float] = None

class OCRResult(BaseModel):
    file_path: str
    full_text: str
    lines: List[OCRLine]
    provider: str
    metadata: Dict[str, Any] = {}