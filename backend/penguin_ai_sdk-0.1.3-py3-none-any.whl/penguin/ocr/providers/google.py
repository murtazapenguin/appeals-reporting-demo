"""
Google Document AI OCR Provider
Implements OCR using Google Cloud Document AI with conversion to Azure-compatible format
"""

import os
import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional, Union
from google.cloud import documentai_v1 as documentai
from google.api_core.client_options import ClientOptions
from ..base import BaseOCRProvider
from ..models import OCRResult, OCRLine


class GoogleToAzureConverter:
    """
    Converts Google Document AI response format to Azure Document Intelligence format.
    This enables standardization across different OCR providers.
    """

    def __init__(self, extract_tables: bool = False):
        """
        Initialize the converter.

        Args:
            extract_tables: Whether to extract table information
        """
        self.extract_tables = extract_tables

    def convert(self, google_response: Any) -> Dict[str, Any]:
        """
        Convert Google Document AI response to Azure-compatible format.

        Args:
            google_response: Response from Google Document AI process_document

        Returns:
            Dictionary in Azure Document Intelligence format
        """
        document = google_response.document

        # Extract full text
        content = document.text

        # Convert pages
        pages = []
        for page in document.pages:
            azure_page = self._convert_page(page, document.text)
            pages.append(azure_page)

        # Extract tables if requested
        tables = []
        if self.extract_tables and hasattr(document, 'entities'):
            tables = self._extract_tables(document)

        result = {
            'api_version': '2023-07-31',
            'model_id': 'google_document_ai',
            'content': content,
            'pages': pages,
            'tables': tables
        }

        return result

    def _convert_page(self, page, full_text: str) -> Dict[str, Any]:
        """
        Convert a Google Document AI page to Azure format.

        Args:
            page: Google Document AI page object
            full_text: Full document text for reference

        Returns:
            Dictionary in Azure page format
        """
        # Get page dimensions
        raw_width = page.dimension.width if hasattr(page, 'dimension') else 8.5
        raw_height = page.dimension.height if hasattr(page, 'dimension') else 11
        unit = page.dimension.unit if hasattr(page, 'dimension') else 'inch'

        # Convert pixels to inches if needed
        # Google often returns dimensions in pixels, but Azure uses inches
        if raw_width > 100 or raw_height > 100:  # Likely in pixels
            # Assume standard letter size and calculate DPI
            # Standard letter: 8.5 × 11 inches
            width_dpi = raw_width / 8.5
            height_dpi = raw_height / 11.0

            # Convert to inches
            width = 8.5  # Standard letter width
            height = 11.0  # Standard letter height
            unit = 'inch'

            # Store DPI for coordinate conversion
            dpi_scale = {'width_dpi': width_dpi, 'height_dpi': height_dpi}
        else:
            # Already in inches
            width = raw_width
            height = raw_height
            dpi_scale = None

        # Convert lines
        lines = []
        if hasattr(page, 'lines'):
            for line in page.lines:
                azure_line = self._convert_line(line, full_text, width, height, dpi_scale)
                lines.append(azure_line)

        azure_page = {
            'page_number': page.page_number,
            'width': width,
            'height': height,
            'unit': unit,
            'lines': lines
        }

        return azure_page

    def _convert_line(self, line, full_text: str, page_width: float, page_height: float, dpi_scale: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        """
        Convert a Google Document AI line to Azure format.

        Args:
            line: Google Document AI line object
            full_text: Full document text
            page_width: Page width for coordinate normalization (in inches)
            page_height: Page height for coordinate normalization (in inches)
            dpi_scale: Optional DPI scaling factors for pixel-to-inch conversion

        Returns:
            Dictionary in Azure line format
        """
        # Extract text from text segments
        content = self._get_text_from_layout(line.layout, full_text)

        # Convert bounding polygon
        polygon = []
        if hasattr(line.layout, 'bounding_poly') and line.layout.bounding_poly.normalized_vertices:
            # Normalized vertices (0-1 range) - scale by page dimensions
            for vertex in line.layout.bounding_poly.normalized_vertices:
                polygon.append({
                    'x': vertex.x * page_width,
                    'y': vertex.y * page_height
                })
        elif hasattr(line.layout, 'bounding_poly') and line.layout.bounding_poly.vertices:
            # Absolute coordinates - may be in pixels, convert if needed
            for vertex in line.layout.bounding_poly.vertices:
                if dpi_scale:
                    # Convert pixels to inches
                    polygon.append({
                        'x': vertex.x / dpi_scale['width_dpi'],
                        'y': vertex.y / dpi_scale['height_dpi']
                    })
                else:
                    # Already in inches
                    polygon.append({
                        'x': vertex.x,
                        'y': vertex.y
                    })

        # Convert words (tokens)
        words = []
        if hasattr(line, 'tokens'):
            for token in line.tokens:
                word = self._convert_token(token, full_text, page_width, page_height, dpi_scale)
                words.append(word)

        azure_line = {
            'content': content,
            'polygon': polygon,
            'words': words
        }

        return azure_line

    def _convert_token(self, token, full_text: str, page_width: float, page_height: float, dpi_scale: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        """
        Convert a Google Document AI token (word) to Azure format.

        Args:
            token: Google Document AI token object
            full_text: Full document text
            page_width: Page width (in inches)
            page_height: Page height (in inches)
            dpi_scale: Optional DPI scaling factors for pixel-to-inch conversion

        Returns:
            Dictionary in Azure word format
        """
        content = self._get_text_from_layout(token.layout, full_text)

        # Convert bounding polygon
        polygon = []
        if hasattr(token.layout, 'bounding_poly') and token.layout.bounding_poly.normalized_vertices:
            # Normalized vertices (0-1 range) - scale by page dimensions
            for vertex in token.layout.bounding_poly.normalized_vertices:
                polygon.append({
                    'x': vertex.x * page_width,
                    'y': vertex.y * page_height
                })
        elif hasattr(token.layout, 'bounding_poly') and token.layout.bounding_poly.vertices:
            # Absolute coordinates - may be in pixels, convert if needed
            for vertex in token.layout.bounding_poly.vertices:
                if dpi_scale:
                    # Convert pixels to inches
                    polygon.append({
                        'x': vertex.x / dpi_scale['width_dpi'],
                        'y': vertex.y / dpi_scale['height_dpi']
                    })
                else:
                    # Already in inches
                    polygon.append({
                        'x': vertex.x,
                        'y': vertex.y
                    })

        # Get confidence if available
        confidence = token.layout.confidence if hasattr(token.layout, 'confidence') else None

        word = {
            'content': content,
            'polygon': polygon
        }

        if confidence is not None:
            word['confidence'] = confidence

        return word

    def _get_text_from_layout(self, layout, full_text: str) -> str:
        """
        Extract text content from layout using text anchors.

        Args:
            layout: Google Document AI layout object
            full_text: Full document text

        Returns:
            Extracted text string
        """
        if not hasattr(layout, 'text_anchor') or not layout.text_anchor.text_segments:
            return ""

        text_parts = []
        for segment in layout.text_anchor.text_segments:
            start_idx = segment.start_index if hasattr(segment, 'start_index') else 0
            end_idx = segment.end_index if hasattr(segment, 'end_index') else len(full_text)
            text_parts.append(full_text[start_idx:end_idx])

        return "".join(text_parts)

    def _extract_tables(self, document) -> List[Dict[str, Any]]:
        """
        Extract tables from Google Document AI response.

        Args:
            document: Google Document AI document object

        Returns:
            List of tables in Azure format
        """
        tables = []

        if not hasattr(document, 'pages'):
            return tables

        for page in document.pages:
            if not hasattr(page, 'tables'):
                continue

            for table in page.tables:
                azure_table = self._convert_table(table, document.text)
                tables.append(azure_table)

        return tables

    def _convert_table(self, table, full_text: str) -> Dict[str, Any]:
        """
        Convert a Google Document AI table to Azure format.

        Args:
            table: Google Document AI table object
            full_text: Full document text

        Returns:
            Dictionary in Azure table format
        """
        row_count = table.header_rows[0].cells[0].layout.text_anchor.text_segments[0].end_index if hasattr(table, 'header_rows') and table.header_rows else 0
        col_count = len(table.header_rows[0].cells) if hasattr(table, 'header_rows') and table.header_rows else 0

        cells = []

        # Process header rows
        if hasattr(table, 'header_rows'):
            for row_idx, header_row in enumerate(table.header_rows):
                for col_idx, cell in enumerate(header_row.cells):
                    content = self._get_text_from_layout(cell.layout, full_text)
                    cells.append({
                        'row_index': row_idx,
                        'column_index': col_idx,
                        'content': content,
                        'kind': 'columnHeader'
                    })

        # Process body rows
        if hasattr(table, 'body_rows'):
            header_row_count = len(table.header_rows) if hasattr(table, 'header_rows') else 0
            for row_idx, body_row in enumerate(table.body_rows):
                for col_idx, cell in enumerate(body_row.cells):
                    content = self._get_text_from_layout(cell.layout, full_text)
                    cells.append({
                        'row_index': row_idx + header_row_count,
                        'column_index': col_idx,
                        'content': content,
                        'kind': 'content'
                    })

        return {
            'row_count': len(table.header_rows) + len(table.body_rows) if hasattr(table, 'header_rows') and hasattr(table, 'body_rows') else 0,
            'column_count': col_count,
            'cells': cells
        }


class GoogleDocumentAIProvider(BaseOCRProvider):
    """
    OCR provider using Google Cloud Document AI.
    Converts Google's response format to Azure-compatible format for standardization.
    """

    def __init__(
        self,
        project_id: str = None,
        location: str = None,
        processor_id: str = None,
        credentials_path: str = None,
        extract_tables: bool = False
    ):
        """
        Initialize Google Document AI provider.

        Args:
            project_id: GCP project ID (defaults to GOOGLE_PROJECT_ID env var)
            location: Processor location, e.g., 'us', 'eu' (defaults to GOOGLE_LOCATION env var)
            processor_id: Document AI processor ID (defaults to GOOGLE_PROCESSOR_ID env var)
            credentials_path: Path to service account JSON (defaults to GOOGLE_APPLICATION_CREDENTIALS env var)
            extract_tables: Whether to extract table information
        """
        # Get credentials from environment if not provided
        self.project_id = project_id or os.environ.get("GOOGLE_PROJECT_ID")
        self.location = location or os.environ.get("GOOGLE_LOCATION", "us")
        self.processor_id = processor_id or os.environ.get("GOOGLE_PROCESSOR_ID")
        self.credentials_path = credentials_path or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")

        # Validate required parameters
        if not self.project_id:
            raise ValueError("project_id is required. Set GOOGLE_PROJECT_ID environment variable or pass it explicitly.")
        if not self.processor_id:
            raise ValueError("processor_id is required. Set GOOGLE_PROCESSOR_ID environment variable or pass it explicitly.")

        # Set credentials path in environment if provided
        if self.credentials_path:
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self.credentials_path

        # Initialize Document AI client
        opts = ClientOptions(api_endpoint=f"{self.location}-documentai.googleapis.com")
        self.client = documentai.DocumentProcessorServiceClient(client_options=opts)

        # Build processor name
        self.processor_name = self.client.processor_path(
            self.project_id, self.location, self.processor_id
        )

        # Initialize converter
        self.converter = GoogleToAzureConverter(extract_tables=extract_tables)

        self.extract_tables = extract_tables

    async def process_file(self, file_path: str) -> OCRResult:
        """
        Process a single file with Google Document AI.

        Args:
            file_path: Path to the file to process

        Returns:
            OCRResult containing extracted text and metadata
        """
        # Read file
        with open(file_path, 'rb') as f:
            file_content = f.read()

        # Determine mime type
        mime_type = self._get_mime_type(file_path)

        # Create request
        request = documentai.ProcessRequest(
            name=self.processor_name,
            raw_document=documentai.RawDocument(content=file_content, mime_type=mime_type)
        )

        # Process document (synchronous call, wrapped in async)
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(None, self.client.process_document, request)

        # Convert to Azure format and then to Penguin format
        return self._parse_google_result(file_path, response)

    async def process_batch(
        self,
        file_paths: List[str],
        max_concurrency: int = 5
    ) -> List[OCRResult]:
        """
        Process multiple files concurrently.

        Args:
            file_paths: List of file paths to process
            max_concurrency: Maximum number of concurrent requests

        Returns:
            List of OCRResult objects
        """
        semaphore = asyncio.Semaphore(max_concurrency)

        async def process_with_semaphore(file_path: str) -> OCRResult:
            async with semaphore:
                return await self.process_file(file_path)

        tasks = [process_with_semaphore(fp) for fp in file_paths]
        results = await asyncio.gather(*tasks)
        return results

    def _parse_google_result(self, file_path: str, google_response) -> OCRResult:
        """
        Parse Google Document AI response into Penguin OCRResult format.

        Args:
            file_path: Original file path
            google_response: Response from Google Document AI

        Returns:
            OCRResult object
        """
        # Convert to Azure format first
        azure_result = self.converter.convert(google_response)

        # Extract lines from Azure format
        all_lines_data = []
        for page in azure_result.get('pages', []):
            for line in page.get('lines', []):
                line_obj = OCRLine(
                    content=line['content'],
                    page_number=page['page_number'],
                    bounding_box=line.get('polygon', [])
                )
                all_lines_data.append(line_obj)

        # Build metadata with Azure format included
        metadata = {
            "project_id": self.project_id,
            "location": self.location,
            "processor_id": self.processor_id,
            "azure_format": azure_result,  # Full Azure-compatible result
            "pages_count": len(azure_result.get('pages', [])),
            "tables_count": len(azure_result.get('tables', []))
        }

        return OCRResult(
            file_path=file_path,
            full_text=azure_result.get('content', ''),
            lines=all_lines_data,
            provider="google_document_ai",
            metadata=metadata
        )

    def _get_mime_type(self, file_path: str) -> str:
        """
        Determine MIME type from file extension.

        Args:
            file_path: Path to the file

        Returns:
            MIME type string
        """
        extension = Path(file_path).suffix.lower()
        mime_types = {
            '.pdf': 'application/pdf',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.tiff': 'image/tiff',
            '.tif': 'image/tiff',
            '.gif': 'image/gif',
            '.bmp': 'image/bmp',
            '.webp': 'image/webp'
        }
        return mime_types.get(extension, 'application/pdf')
