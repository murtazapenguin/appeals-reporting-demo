"""
Penguin Observability Decorator

Decorator for tracing functions with OpenTelemetry support.
Supports both sync and async functions.

Uses consolidated OTel pipeline - all traces go through OTel with
file export via OTelFileExporter. Legacy Span model is deprecated.
"""

import asyncio
import functools
import time
import uuid
from typing import Any, Callable, Optional, TypeVar

from .context import (
    get_current_trace_id,
    get_current_span_id,
    get_current_project_id,
    set_trace_context,
    reset_context,
)
from .middleware import MiddlewareChain, MiddlewareContext, OTelMiddleware
from .setup import auto_setup_if_enabled, is_tracing_enabled

T = TypeVar("T")

# Global middleware chain
_middleware_chain: Optional[MiddlewareChain] = None


def get_middleware_chain() -> MiddlewareChain:
    """Get or create the global middleware chain."""
    global _middleware_chain
    if _middleware_chain is None:
        # Auto-setup tracing if enabled
        auto_setup_if_enabled()
        _middleware_chain = MiddlewareChain([
            OTelMiddleware(),
        ])
    return _middleware_chain


def observe(
    name: Optional[str] = None,
    type: str = "chain",
    project_id: Optional[str] = None,
    provider: Optional[str] = None,
    model: Optional[str] = None,
):
    """
    Decorator to trace a function and capture observability data.

    Supports both sync and async functions automatically.

    Args:
        name: Override span name (default is function name)
        type: Span type - 'llm', 'tool', 'ocr', 'chain', 'vlm'
        project_id: Project identifier (inherits from context if None)
        provider: LLM provider name (e.g., 'gemini', 'openai')
        model: Model identifier

    Example:
        @observe(type="llm", provider="openai")
        async def generate_response(prompt: str) -> str:
            ...

        @observe(type="tool")
        def calculate_sum(a: int, b: int) -> int:
            ...
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        is_async = asyncio.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs) -> T:
            return await _execute_with_tracing(
                func, args, kwargs, name, type, project_id, provider, model, is_async=True
            )

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs) -> T:
            return _execute_with_tracing_sync(
                func, args, kwargs, name, type, project_id, provider, model
            )

        return async_wrapper if is_async else sync_wrapper

    return decorator


async def _execute_with_tracing(
    func: Callable,
    args: tuple,
    kwargs: dict,
    name: Optional[str],
    span_type: str,
    project_id: Optional[str],
    provider: Optional[str],
    model: Optional[str],
    is_async: bool = True,
) -> Any:
    """Execute function with tracing (async version).

    Uses consolidated OTel pipeline. All span data including thinking
    content is captured via OTelMiddleware and exported to JSONL via
    OTelFileExporter.
    """
    # Resolve context
    active_project = project_id or get_current_project_id()
    trace_id = get_current_trace_id() or str(uuid.uuid4())
    parent_id = get_current_span_id()
    span_name = name or func.__name__
    span_id = str(uuid.uuid4())

    # Create middleware context (OTel handles span creation and export)
    context = MiddlewareContext(
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_id,
        project_id=active_project,
        span_name=span_name,
        span_type=span_type,
        provider=provider,
        model=model,
        inputs=_safe_serialize(kwargs),
        start_time=time.time(),
    )

    # Set context for child spans
    tokens = set_trace_context(trace_id, span_id, active_project)

    chain = get_middleware_chain()
    context = chain.before_execute(context)

    try:
        # Execute function
        if is_async:
            result = await func(*args, **kwargs)
        else:
            result = func(*args, **kwargs)

        context.end_time = time.time()
        context.status = "OK"

        # Capture outputs
        context.outputs = _safe_serialize(result)

        # OTel middleware handles span completion and export
        context = chain.after_execute(context, result)
        return result

    except Exception as e:
        context.end_time = time.time()
        context.status = "ERROR"
        context.error = str(e)
        context = chain.on_error(context, e)
        raise

    finally:
        reset_context(*tokens)


def _execute_with_tracing_sync(
    func: Callable,
    args: tuple,
    kwargs: dict,
    name: Optional[str],
    span_type: str,
    project_id: Optional[str],
    provider: Optional[str],
    model: Optional[str],
) -> Any:
    """Execute function with tracing (sync version).

    Uses consolidated OTel pipeline. All span data including thinking
    content is captured via OTelMiddleware and exported to JSONL via
    OTelFileExporter.
    """
    # Resolve context
    active_project = project_id or get_current_project_id()
    trace_id = get_current_trace_id() or str(uuid.uuid4())
    parent_id = get_current_span_id()
    span_name = name or func.__name__
    span_id = str(uuid.uuid4())

    # Create middleware context (OTel handles span creation and export)
    context = MiddlewareContext(
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=parent_id,
        project_id=active_project,
        span_name=span_name,
        span_type=span_type,
        provider=provider,
        model=model,
        inputs=_safe_serialize(kwargs),
        start_time=time.time(),
    )

    # Set context for child spans
    tokens = set_trace_context(trace_id, span_id, active_project)

    chain = get_middleware_chain()
    context = chain.before_execute(context)

    try:
        result = func(*args, **kwargs)

        context.end_time = time.time()
        context.status = "OK"

        # Capture outputs
        context.outputs = _safe_serialize(result)

        # OTel middleware handles span completion and export
        context = chain.after_execute(context, result)
        return result

    except Exception as e:
        context.end_time = time.time()
        context.status = "ERROR"
        context.error = str(e)
        context = chain.on_error(context, e)
        raise

    finally:
        reset_context(*tokens)


def _safe_serialize(obj: Any) -> Any:
    """Safely serialize an object for storage."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, dict):
        return {k: _safe_serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_safe_serialize(v) for v in obj]
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "dict"):
        return obj.dict()
    return str(obj)
