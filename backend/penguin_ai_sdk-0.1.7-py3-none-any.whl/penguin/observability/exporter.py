import json
import logging
import os
from .models import Span

logger = logging.getLogger("penguin.observability")

class FileExporter:
    def __init__(self, filepath="penguin_traces.jsonl"):
        self.filepath = filepath

    def export(self, span: Span):
        """Writes the completed span to JSONL."""
        try:
            # We append to the file
            with open(self.filepath, "a") as f:
                f.write(span.json() + "\n")
        except Exception as e:
            logger.error(f"Failed to export trace: {e}")

    def read_all(self) -> list:
        """
        Read all spans from the trace file.

        Returns:
            List of span dictionaries
        """
        spans = []
        if os.path.exists(self.filepath):
            with open(self.filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            spans.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        return spans

# Global instance
_exporter = FileExporter()

def get_exporter():
    return _exporter