"""
Penguin Observability Module

OpenTelemetry-based tracing and observability for LLM operations.

All tracing goes through a unified OTel pipeline with file export via
OTelFileExporter. This captures all Gen-AI attributes including extended
thinking content.

Usage:
    # Setup tracing (optional, auto-configured via environment)
    from penguin.observability import setup_tracing
    setup_tracing()  # Writes to penguin_traces.jsonl

    # Use the decorator
    @observe(type="llm", provider="openai")
    async def generate_response(prompt: str) -> str:
        ...

    @observe(type="tool")
    def calculate_sum(a: int, b: int) -> int:
        ...

Environment Variables:
    PENGUIN_ENABLE_TRACING=true  - Enable tracing (opt-in)
    PENGUIN_TRACE_FILE_PATH=...  - Custom trace file path
    OTEL_EXPORTER_OTLP_ENDPOINT=... - OTLP endpoint for Jaeger/Grafana
"""

# Main decorator
from .decorator import observe, get_middleware_chain

# Setup functions (unified OTel pipeline)
from .setup import (
    setup_tracing,
    shutdown_tracing,
    get_file_exporter,
    is_tracing_enabled,
    auto_setup_if_enabled,
)

# Configuration
from .config import (
    ObservabilityConfig,
    ExporterConfig,
    ExporterType,
    SamplerType,
    get_config,
    set_config,
    should_capture_content,
    get_tracer,
)

# Attributes (Gen-AI semantic conventions)
from .attributes import (
    GenAIAttributes,
    GenAISpanKind,
    GenAISystem,
    provider_to_system,
)

# Middleware
from .middleware import (
    BaseMiddleware,
    MiddlewareChain,
    MiddlewareContext,
    OTelMiddleware,
)

# Exporters
from .exporters import (
    BaseExporter,
    FileExporter,
    OTLPExporter,
    CompositeExporter,
)
from .exporters.otel_file import OTelFileExporter

# Legacy models (for backward compatibility)
from .models import Span, TokenUsage

# Legacy exporter helper
from .exporter import get_exporter

# Context management
from .context import (
    get_current_trace_id,
    get_current_span_id,
    get_current_project_id,
    set_trace_context,
    reset_context,
)

__all__ = [
    # Decorator
    "observe",
    "get_middleware_chain",
    # Setup (unified OTel pipeline)
    "setup_tracing",
    "shutdown_tracing",
    "get_file_exporter",
    "is_tracing_enabled",
    "auto_setup_if_enabled",
    # Config
    "ObservabilityConfig",
    "ExporterConfig",
    "ExporterType",
    "SamplerType",
    "get_config",
    "set_config",
    # Attributes
    "GenAIAttributes",
    "GenAISpanKind",
    "GenAISystem",
    "provider_to_system",
    # Middleware
    "BaseMiddleware",
    "MiddlewareChain",
    "MiddlewareContext",
    "OTelMiddleware",
    # Exporters
    "BaseExporter",
    "FileExporter",
    "OTLPExporter",
    "OTelFileExporter",
    "CompositeExporter",
    # Models (legacy, for backward compat)
    "Span",
    "TokenUsage",
    # Legacy exporter helper
    "get_exporter",
    # Context
    "get_current_trace_id",
    "get_current_span_id",
    "get_current_project_id",
    "set_trace_context",
    "reset_context",
]
