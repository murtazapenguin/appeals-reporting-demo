# START OF FILE: penguin/observability/context.py ---
import contextvars
from typing import Optional

_current_trace_id = contextvars.ContextVar("current_trace_id", default=None)
_current_span_id = contextvars.ContextVar("current_span_id", default=None)
_current_project_id = contextvars.ContextVar("current_project_id", default="default") # <--- ADDED

def get_current_project_id():
    return _current_project_id.get()

def set_project_id(project_id: str):
    """Global setter for the current execution context (e.g., at the start of a script)"""
    return _current_project_id.set(project_id)

def get_current_trace_id():
    return _current_trace_id.get()

def get_current_span_id():
    return _current_span_id.get()

def set_trace_context(trace_id: str, span_id: str, project_id: Optional[str] = None):
    t_token = _current_trace_id.set(trace_id)
    s_token = _current_span_id.set(span_id)
    p_token = None
    if project_id:
        p_token = _current_project_id.set(project_id)
    return t_token, s_token, p_token

def reset_context(t_token, s_token, p_token=None):
    _current_trace_id.reset(t_token)
    _current_span_id.reset(s_token)
    if p_token:
        _current_project_id.reset(p_token)
# END OF FILE: penguin/observability/context.py ---