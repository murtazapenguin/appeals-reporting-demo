"""
Penguin File Exporter

Exports trace data to JSONL files.
"""

import json
import logging
import threading
from pathlib import Path
from typing import Any, Optional

from .base import BaseExporter

logger = logging.getLogger("penguin.observability")


class FileExporter(BaseExporter):
    """
    Exports trace data to JSONL (JSON Lines) files.

    Thread-safe implementation with buffering support.
    """

    def __init__(
        self,
        filepath: str = "penguin_traces.jsonl",
        buffer_size: int = 10,
        auto_flush: bool = True,
    ):
        """
        Initialize file exporter.

        Args:
            filepath: Path to the output file
            buffer_size: Number of spans to buffer before writing
            auto_flush: Whether to auto-flush after each export
        """
        self.filepath = Path(filepath)
        self.buffer_size = buffer_size
        self.auto_flush = auto_flush

        self._buffer = []
        self._lock = threading.Lock()
        self._closed = False

        # Ensure parent directory exists
        self.filepath.parent.mkdir(parents=True, exist_ok=True)

    def export(self, span: Any) -> bool:
        """
        Export a span to the JSONL file.

        Args:
            span: Span object with .dict() or .json() method, or dict

        Returns:
            True if export succeeded
        """
        if self._closed:
            return False

        try:
            # Convert span to dict
            if hasattr(span, "model_dump"):
                # Pydantic v2
                data = span.model_dump()
            elif hasattr(span, "dict"):
                # Pydantic v1
                data = span.dict()
            elif isinstance(span, dict):
                data = span
            else:
                data = {"data": str(span)}

            with self._lock:
                self._buffer.append(data)

                if self.auto_flush or len(self._buffer) >= self.buffer_size:
                    self._flush_buffer()

            return True

        except Exception as e:
            logger.error(f"Failed to export span: {e}")
            return False

    def _flush_buffer(self) -> None:
        """Write buffered spans to file (must hold lock)."""
        if not self._buffer:
            return

        try:
            with open(self.filepath, "a", encoding="utf-8") as f:
                for data in self._buffer:
                    f.write(json.dumps(data, default=str) + "\n")
            self._buffer.clear()
        except Exception as e:
            logger.error(f"Failed to write to file: {e}")

    def flush(self) -> None:
        """Flush buffered data to file."""
        with self._lock:
            self._flush_buffer()

    def shutdown(self) -> None:
        """Shutdown exporter and flush remaining data."""
        self._closed = True
        self.flush()

    def read_all(self) -> list:
        """
        Read all spans from the file.

        Returns:
            List of span dictionaries
        """
        spans = []
        if self.filepath.exists():
            with open(self.filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            spans.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        return spans

    def clear(self) -> None:
        """Clear the trace file."""
        with self._lock:
            self._buffer.clear()
            if self.filepath.exists():
                self.filepath.unlink()
