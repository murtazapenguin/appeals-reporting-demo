"""
Penguin OTel File Exporter

OpenTelemetry SpanExporter that writes spans to JSONL files.
This consolidates tracing to use OTel for everything with file export.
"""

import json
import logging
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, Sequence

logger = logging.getLogger("penguin.observability")


class OTelFileExporter:
    """
    OpenTelemetry SpanExporter that writes spans to JSONL files.

    This replaces the legacy FileExporter by integrating directly with
    OpenTelemetry's span processor pipeline, ensuring all OTel span
    attributes (including thinking content) are captured.

    Implements the OTel SpanExporter protocol.
    """

    def __init__(
        self,
        filepath: str = "penguin_traces.jsonl",
        buffer_size: int = 10,
    ):
        """
        Initialize the OTel file exporter.

        Args:
            filepath: Path to the output JSONL file
            buffer_size: Number of spans to buffer before flushing
        """
        self.filepath = Path(filepath)
        self.buffer_size = buffer_size

        self._buffer = []
        self._lock = threading.Lock()
        self._shutdown = False

        # Ensure parent directory exists
        self.filepath.parent.mkdir(parents=True, exist_ok=True)

        # OTel imports (optional)
        try:
            from opentelemetry.sdk.trace.export import SpanExportResult
            self._SpanExportResult = SpanExportResult
            self._otel_available = True
        except ImportError:
            self._otel_available = False
            self._SpanExportResult = None

    def export(self, spans: Sequence) -> "SpanExportResult":
        """
        Export a batch of spans to the JSONL file.

        Args:
            spans: Sequence of ReadableSpan objects

        Returns:
            SpanExportResult.SUCCESS or SpanExportResult.FAILURE
        """
        if self._shutdown:
            return self._SpanExportResult.FAILURE if self._SpanExportResult else False

        try:
            with self._lock:
                for span in spans:
                    span_data = self._span_to_dict(span)
                    self._buffer.append(span_data)

                if len(self._buffer) >= self.buffer_size:
                    self._flush_buffer()

            return self._SpanExportResult.SUCCESS if self._SpanExportResult else True

        except Exception as e:
            logger.error(f"Failed to export spans: {e}")
            return self._SpanExportResult.FAILURE if self._SpanExportResult else False

    def _span_to_dict(self, span) -> dict:
        """
        Convert an OTel ReadableSpan to a dictionary for JSON export.

        Extracts all Gen-AI semantic convention attributes including
        thinking content, token usage, etc.
        """
        # Basic span info
        context = span.get_span_context()

        data = {
            "trace_id": format(context.trace_id, "032x"),
            "span_id": format(context.span_id, "016x"),
            "parent_span_id": format(span.parent.span_id, "016x") if span.parent else None,
            "name": span.name,
            "kind": str(span.kind.name) if span.kind else "INTERNAL",
            "start_time": self._timestamp_to_iso(span.start_time),
            "end_time": self._timestamp_to_iso(span.end_time),
            "duration_ms": (span.end_time - span.start_time) / 1_000_000 if span.end_time and span.start_time else 0,
            "status": {
                "code": span.status.status_code.name if span.status else "UNSET",
                "message": span.status.description if span.status else None,
            },
        }

        # Extract attributes into categories
        attributes = dict(span.attributes) if span.attributes else {}

        # Gen-AI attributes
        gen_ai = {}
        penguin = {}
        other = {}

        for key, value in attributes.items():
            if key.startswith("gen_ai."):
                # Map to shorter keys for readability
                short_key = key.replace("gen_ai.", "")
                gen_ai[short_key] = value
            elif key.startswith("penguin."):
                short_key = key.replace("penguin.", "")
                penguin[short_key] = value
            else:
                other[key] = value

        if gen_ai:
            data["gen_ai"] = gen_ai
        if penguin:
            data["penguin"] = penguin
        if other:
            data["attributes"] = other

        # Events (including exceptions)
        if span.events:
            data["events"] = [
                {
                    "name": event.name,
                    "timestamp": self._timestamp_to_iso(event.timestamp),
                    "attributes": dict(event.attributes) if event.attributes else {},
                }
                for event in span.events
            ]

        return data

    def _timestamp_to_iso(self, timestamp_ns: Optional[int]) -> Optional[str]:
        """Convert nanosecond timestamp to ISO format string."""
        if timestamp_ns is None:
            return None
        # OTel timestamps are in nanoseconds
        timestamp_s = timestamp_ns / 1_000_000_000
        return datetime.utcfromtimestamp(timestamp_s).isoformat() + "Z"

    def _flush_buffer(self) -> None:
        """Write buffered spans to file (must hold lock)."""
        if not self._buffer:
            return

        try:
            with open(self.filepath, "a", encoding="utf-8") as f:
                for data in self._buffer:
                    f.write(json.dumps(data, default=str) + "\n")
            self._buffer.clear()
        except Exception as e:
            logger.error(f"Failed to write spans to file: {e}")

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """
        Force flush all buffered spans.

        Args:
            timeout_millis: Timeout in milliseconds (unused, for interface compat)

        Returns:
            True if flush succeeded
        """
        with self._lock:
            self._flush_buffer()
        return True

    def shutdown(self) -> None:
        """Shutdown the exporter and flush remaining data."""
        self._shutdown = True
        self.force_flush()

    def read_all(self) -> list:
        """
        Read all spans from the file.

        Returns:
            List of span dictionaries
        """
        spans = []
        if self.filepath.exists():
            with open(self.filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            spans.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        return spans

    def clear(self) -> None:
        """Clear the trace file."""
        with self._lock:
            self._buffer.clear()
            if self.filepath.exists():
                self.filepath.unlink()
