"""
Penguin Composite Exporter

Exports trace data to multiple destinations.
"""

import logging
from typing import Any, List

from .base import BaseExporter

logger = logging.getLogger("penguin.observability")


class CompositeExporter(BaseExporter):
    """
    Exports trace data to multiple exporters.

    Useful for sending traces to both a file and OTLP endpoint,
    or to multiple observability backends.
    """

    def __init__(self, exporters: List[BaseExporter]):
        """
        Initialize composite exporter.

        Args:
            exporters: List of exporters to use
        """
        self._exporters = exporters

    def add(self, exporter: BaseExporter) -> "CompositeExporter":
        """
        Add an exporter to the composite.

        Args:
            exporter: Exporter to add

        Returns:
            Self for chaining
        """
        self._exporters.append(exporter)
        return self

    def export(self, span: Any) -> bool:
        """
        Export span to all exporters.

        Args:
            span: Span data to export

        Returns:
            True if at least one export succeeded
        """
        success = False
        for exporter in self._exporters:
            try:
                if exporter.export(span):
                    success = True
            except Exception as e:
                logger.error(f"Exporter {type(exporter).__name__} failed: {e}")
        return success

    def flush(self) -> None:
        """Flush all exporters."""
        for exporter in self._exporters:
            try:
                exporter.flush()
            except Exception as e:
                logger.error(f"Failed to flush {type(exporter).__name__}: {e}")

    def shutdown(self) -> None:
        """Shutdown all exporters."""
        for exporter in self._exporters:
            try:
                exporter.shutdown()
            except Exception as e:
                logger.error(f"Failed to shutdown {type(exporter).__name__}: {e}")
