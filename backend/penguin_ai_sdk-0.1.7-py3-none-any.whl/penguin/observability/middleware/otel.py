"""
Penguin OpenTelemetry Middleware

Middleware that creates and manages OpenTelemetry spans with Gen-AI attributes.
"""

import logging
from typing import Any, Optional

from .base import BaseMiddleware, MiddlewareContext
from ..attributes import GenAIAttributes, provider_to_system

logger = logging.getLogger("penguin.observability")


class OTelMiddleware(BaseMiddleware):
    """
    OpenTelemetry middleware for creating spans with Gen-AI semantic conventions.

    Creates OTel spans and populates them with standard Gen-AI attributes.
    Falls back to a no-op implementation if OpenTelemetry is not installed.
    """

    def __init__(
        self,
        tracer_name: str = "penguin",
        capture_prompts: bool = True,
        capture_completions: bool = True,
        max_content_length: int = 10000,
    ):
        """
        Initialize OTel middleware.

        Args:
            tracer_name: Name for the tracer
            capture_prompts: Whether to capture prompt content
            capture_completions: Whether to capture completion content
            max_content_length: Max length before truncating content
        """
        self.tracer_name = tracer_name
        self.capture_prompts = capture_prompts
        self.capture_completions = capture_completions
        self.max_content_length = max_content_length

        # Try to import OpenTelemetry
        try:
            from opentelemetry import trace, context as otel_context
            from opentelemetry.trace import Status, StatusCode, SpanContext, TraceFlags
            self._trace = trace
            self._otel_context = otel_context
            self._Status = Status
            self._StatusCode = StatusCode
            self._SpanContext = SpanContext
            self._TraceFlags = TraceFlags
            self._tracer = trace.get_tracer(tracer_name)
            self._otel_available = True
        except ImportError:
            self._otel_available = False
            logger.debug("OpenTelemetry not installed, spans will not be created")

        # Active spans tracking - maps span_id to (span, token) for context management
        self._active_spans = {}

    def _truncate(self, content: str) -> str:
        """Truncate content if too long."""
        if len(content) > self.max_content_length:
            return content[: self.max_content_length] + "...[truncated]"
        return content

    def before_execute(self, context: MiddlewareContext) -> MiddlewareContext:
        """Start an OTel span before execution."""
        if not self._otel_available:
            return context

        # Get current OTel context (for parent-child linking)
        current_ctx = self._otel_context.get_current()

        # Create span - OTel will automatically link to parent if one exists in context
        span = self._tracer.start_span(
            name=context.span_name,
            context=current_ctx,
            attributes={
                GenAIAttributes.SPAN_TYPE: context.span_type,
                GenAIAttributes.PROJECT_ID: context.project_id,
            }
        )

        # Set this span as current context so child spans link to it
        token = self._otel_context.attach(self._trace.set_span_in_context(span))

        # Update context with actual OTel trace_id and span_id
        span_context = span.get_span_context()
        if span_context.is_valid:
            # Format as hex string (OTel standard format)
            context.trace_id = format(span_context.trace_id, '032x')
            context.span_id = format(span_context.span_id, '016x')

        # Set provider/model attributes for LLM operations
        if context.provider:
            span.set_attribute(
                GenAIAttributes.SYSTEM,
                provider_to_system(context.provider)
            )
        if context.model:
            span.set_attribute(GenAIAttributes.REQUEST_MODEL, context.model)

        # Set request parameters
        params = context.request_params
        if "temperature" in params:
            span.set_attribute(
                GenAIAttributes.REQUEST_TEMPERATURE,
                params["temperature"]
            )
        if "max_tokens" in params:
            span.set_attribute(
                GenAIAttributes.REQUEST_MAX_TOKENS,
                params["max_tokens"]
            )
        if "top_p" in params:
            span.set_attribute(GenAIAttributes.REQUEST_TOP_P, params["top_p"])

        # Capture prompt if enabled
        if self.capture_prompts and context.inputs:
            prompt_str = str(context.inputs)
            span.set_attribute(
                GenAIAttributes.PROMPT,
                self._truncate(prompt_str)
            )

        # Store span and context token for later (using OTel span_id)
        self._active_spans[context.span_id] = (span, token)

        return context

    def after_execute(
        self,
        context: MiddlewareContext,
        result: Any
    ) -> MiddlewareContext:
        """Complete the OTel span after successful execution."""
        if not self._otel_available:
            return context

        span_data = self._active_spans.pop(context.span_id, None)
        if not span_data:
            return context

        span, token = span_data

        # Extract usage from result
        if hasattr(result, "usage") and result.usage:
            usage = result.usage
            span.set_attribute(
                GenAIAttributes.USAGE_INPUT_TOKENS,
                getattr(usage, "prompt_tokens", 0) or getattr(usage, "input_tokens", 0)
            )
            span.set_attribute(
                GenAIAttributes.USAGE_OUTPUT_TOKENS,
                getattr(usage, "completion_tokens", 0) or getattr(usage, "output_tokens", 0)
            )
            span.set_attribute(
                GenAIAttributes.USAGE_TOTAL_TOKENS,
                getattr(usage, "total_tokens", 0)
            )

            # Penguin-specific usage
            if getattr(usage, "thinking_tokens", None):
                span.set_attribute(
                    GenAIAttributes.THINKING_TOKENS,
                    usage.thinking_tokens
                )
            if getattr(usage, "cached_tokens", None):
                span.set_attribute(
                    GenAIAttributes.CACHED_TOKENS,
                    usage.cached_tokens
                )

        # Capture completion if enabled
        if self.capture_completions:
            completion = None
            if hasattr(result, "content"):
                completion = str(result.content)
            elif hasattr(result, "text"):
                completion = str(result.text)
            elif isinstance(result, str):
                completion = result

            if completion:
                span.set_attribute(
                    GenAIAttributes.COMPLETION,
                    self._truncate(completion)
                )

            # Capture thinking content if present
            if hasattr(result, "thinking") and result.thinking:
                span.set_attribute(
                    GenAIAttributes.THINKING_CONTENT,
                    self._truncate(str(result.thinking))
                )

        # Set finish reason
        if hasattr(result, "finish_reason"):
            span.set_attribute(
                GenAIAttributes.RESPONSE_FINISH_REASONS,
                [str(result.finish_reason)]
            )

        # Set response model
        if hasattr(result, "model"):
            span.set_attribute(GenAIAttributes.RESPONSE_MODEL, result.model)

        # Set success status
        span.set_status(self._Status(self._StatusCode.OK))
        span.end()

        # Detach context to restore parent span as current
        self._otel_context.detach(token)

        return context

    def on_error(
        self,
        context: MiddlewareContext,
        error: Exception
    ) -> MiddlewareContext:
        """Record error on the OTel span."""
        if not self._otel_available:
            return context

        span_data = self._active_spans.pop(context.span_id, None)
        if not span_data:
            return context

        span, token = span_data

        # Record exception
        span.record_exception(error)
        span.set_status(
            self._Status(self._StatusCode.ERROR, str(error))
        )
        span.end()

        # Detach context to restore parent span as current
        self._otel_context.detach(token)

        return context
