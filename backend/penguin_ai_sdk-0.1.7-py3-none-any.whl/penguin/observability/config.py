"""
Penguin Observability Configuration

Configuration for OpenTelemetry-based tracing and observability.
"""

import os
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class SamplerType(str, Enum):
    """Sampling strategies for traces."""
    ALWAYS_ON = "always_on"
    ALWAYS_OFF = "always_off"
    RATIO = "ratio"
    PARENT_BASED = "parent_based"


class ExporterType(str, Enum):
    """Available exporter types."""
    OTLP_HTTP = "otlp_http"
    OTLP_GRPC = "otlp_grpc"
    FILE = "file"
    CONSOLE = "console"
    NONE = "none"


class ExporterConfig(BaseModel):
    """Configuration for a single exporter."""
    type: ExporterType
    endpoint: Optional[str] = None  # For OTLP exporters
    filepath: Optional[str] = None  # For file exporter
    headers: dict = Field(default_factory=dict)  # For OTLP auth


class ObservabilityConfig(BaseModel):
    """
    Main observability configuration.

    Can be loaded from environment variables or created programmatically.

    Environment variables:
        OTEL_SERVICE_NAME: Service name for traces
        OTEL_SERVICE_VERSION: Service version
        OTEL_EXPORTER_OTLP_ENDPOINT: OTLP endpoint URL
        OTEL_EXPORTER_OTLP_HEADERS: Headers in format "key=value,key2=value2"
        PENGUIN_TRACE_SAMPLE_RATIO: Sampling ratio (0.0 to 1.0)
        PENGUIN_TRACE_FILE_PATH: Path for file exporter
    """
    # Service identification
    service_name: str = "penguin"
    service_version: str = "0.1.0"
    environment: str = "development"

    # Exporters
    exporters: List[ExporterConfig] = Field(default_factory=list)

    # Sampling
    sampler: SamplerType = SamplerType.ALWAYS_ON
    sample_ratio: float = 1.0

    # Context propagation
    propagate_context: bool = True

    # Gen-AI specific settings
    capture_prompts: bool = True  # Whether to capture full prompts
    capture_completions: bool = True  # Whether to capture full completions
    max_content_length: int = 10000  # Truncate content longer than this

    @classmethod
    def from_env(cls) -> "ObservabilityConfig":
        """
        Create configuration from environment variables.

        Returns:
            ObservabilityConfig instance
        """
        exporters = []

        # Check for OTLP endpoint
        otlp_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        if otlp_endpoint:
            headers = {}
            headers_str = os.environ.get("OTEL_EXPORTER_OTLP_HEADERS", "")
            if headers_str:
                for pair in headers_str.split(","):
                    if "=" in pair:
                        key, value = pair.split("=", 1)
                        headers[key.strip()] = value.strip()

            exporters.append(ExporterConfig(
                type=ExporterType.OTLP_HTTP,
                endpoint=otlp_endpoint,
                headers=headers
            ))

        # Check for file exporter
        file_path = os.environ.get("PENGUIN_TRACE_FILE_PATH")
        if file_path:
            exporters.append(ExporterConfig(
                type=ExporterType.FILE,
                filepath=file_path
            ))

        # If no exporters configured, default to file
        if not exporters:
            exporters.append(ExporterConfig(
                type=ExporterType.FILE,
                filepath="penguin_traces.jsonl"
            ))

        # Parse sample ratio
        sample_ratio_str = os.environ.get("PENGUIN_TRACE_SAMPLE_RATIO", "1.0")
        try:
            sample_ratio = float(sample_ratio_str)
        except ValueError:
            sample_ratio = 1.0

        return cls(
            service_name=os.environ.get("OTEL_SERVICE_NAME", "penguin"),
            service_version=os.environ.get("OTEL_SERVICE_VERSION", "0.1.0"),
            environment=os.environ.get("PENGUIN_ENVIRONMENT", "development"),
            exporters=exporters,
            sampler=SamplerType.RATIO if sample_ratio < 1.0 else SamplerType.ALWAYS_ON,
            sample_ratio=sample_ratio,
            capture_prompts=os.environ.get("PENGUIN_CAPTURE_PROMPTS", "true").lower() == "true",
            capture_completions=os.environ.get("PENGUIN_CAPTURE_COMPLETIONS", "true").lower() == "true",
        )

    @classmethod
    def default(cls) -> "ObservabilityConfig":
        """Create default configuration with file exporter."""
        return cls(
            exporters=[
                ExporterConfig(
                    type=ExporterType.FILE,
                    filepath="penguin_traces.jsonl"
                )
            ]
        )

    @classmethod
    def with_otlp(
        cls,
        endpoint: str,
        headers: Optional[dict] = None,
        service_name: str = "penguin",
        **kwargs
    ) -> "ObservabilityConfig":
        """
        Create configuration with OTLP exporter.

        Args:
            endpoint: OTLP endpoint URL
            headers: Optional headers for authentication
            service_name: Service name for traces
            **kwargs: Additional config options

        Returns:
            ObservabilityConfig instance
        """
        return cls(
            service_name=service_name,
            exporters=[
                ExporterConfig(
                    type=ExporterType.OTLP_HTTP,
                    endpoint=endpoint,
                    headers=headers or {}
                )
            ],
            **kwargs
        )


# Global configuration instance
_config: Optional[ObservabilityConfig] = None


def get_config() -> ObservabilityConfig:
    """Get the current observability configuration."""
    global _config
    if _config is None:
        _config = ObservabilityConfig.from_env()
    return _config


def set_config(config: ObservabilityConfig) -> None:
    """Set the observability configuration."""
    global _config
    _config = config


# ==================== Tracing Helper Functions ====================

def is_tracing_enabled() -> bool:
    """
    Check if tracing is enabled.

    Controlled by PENGUIN_ENABLE_TRACING environment variable.
    Default is False (opt-in).

    Returns:
        True if tracing is enabled
    """
    return os.environ.get("PENGUIN_ENABLE_TRACING", "false").lower() in ("true", "1", "yes")


def should_capture_content() -> bool:
    """
    Check if prompt/completion content should be captured.

    Controlled by PENGUIN_CAPTURE_CONTENT environment variable.
    Default is False for privacy.

    Returns:
        True if content capture is enabled
    """
    return os.environ.get("PENGUIN_CAPTURE_CONTENT", "false").lower() in ("true", "1", "yes")


def get_tracer(name: str = "penguin"):
    """
    Get an OpenTelemetry tracer if available.

    Args:
        name: Tracer name (default: "penguin")

    Returns:
        OpenTelemetry tracer if available, else a no-op tracer
    """
    if not is_tracing_enabled():
        return _NoOpTracer()

    try:
        from opentelemetry import trace
        return trace.get_tracer(name)
    except ImportError:
        return _NoOpTracer()


class _NoOpSpan:
    """No-op span for when tracing is disabled."""

    def set_attribute(self, key, value):
        pass

    def set_status(self, status):
        pass

    def record_exception(self, exception):
        pass

    def end(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class _NoOpTracer:
    """No-op tracer for when OpenTelemetry is not available."""

    def start_span(self, name, **kwargs):
        return _NoOpSpan()

    def start_as_current_span(self, name, **kwargs):
        return _NoOpSpan()
