import uuid
import time
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field

class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    unit: str = "tokens" # or "pages" for OCR


class Span(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    trace_id: str
    project_id: str = "default" 
    parent_id: Optional[str] = None
    name: str                   # e.g., "extract_hcc"
    type: str = "chain"         # llm, tool, chain, embedding, ocr
    
    start_time: float = Field(default_factory=time.time)
    end_time: Optional[float] = None
    duration_ms: float = 0.0
    
    status: str = "RUNNING"     # RUNNING, OK, ERROR
    status_message: Optional[str] = None
    
    # The Black Box
    inputs: Dict[str, Any] = {}
    outputs: Optional[Any] = None
    
    # Model info
    model_params: Dict[str, Any] = {} # model_name, temperature
    usage: Optional[TokenUsage] = None
    
    # Advanced (Phoenix-style)
    metadata: Dict[str, Any] = {} # prompt_id, user_id, tags
    evaluations: Dict[str, float] = {} # "accuracy": 0.9

    def end(self, status="OK", error=None):
        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000
        self.status = status
        self.status_message = str(error) if error else None