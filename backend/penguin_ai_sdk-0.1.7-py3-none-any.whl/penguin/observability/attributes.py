"""
Penguin Observability Attributes

Gen-AI Semantic Conventions for OpenTelemetry.
Based on OpenTelemetry Semantic Conventions for Generative AI.

See: https://opentelemetry.io/docs/specs/semconv/gen-ai/
"""


class GenAIAttributes:
    """
    OpenTelemetry semantic convention attributes for Gen-AI operations.

    These follow the official OpenTelemetry Gen-AI semantic conventions
    for consistent tracing across different AI/ML systems.
    """

    # ================== SYSTEM ATTRIBUTES ==================
    # Identifies the AI provider/system

    SYSTEM = "gen_ai.system"
    # Values: "openai", "anthropic", "google_ai", "aws_bedrock", etc.

    # ================== REQUEST ATTRIBUTES ==================
    # Attributes set on the request

    REQUEST_MODEL = "gen_ai.request.model"
    # The model name/ID used for the request

    REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    # Maximum tokens to generate

    REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    # Sampling temperature

    REQUEST_TOP_P = "gen_ai.request.top_p"
    # Nucleus sampling parameter

    REQUEST_TOP_K = "gen_ai.request.top_k"
    # Top-K sampling parameter

    REQUEST_STOP_SEQUENCES = "gen_ai.request.stop_sequences"
    # Stop sequences for generation

    REQUEST_FREQUENCY_PENALTY = "gen_ai.request.frequency_penalty"
    # Frequency penalty

    REQUEST_PRESENCE_PENALTY = "gen_ai.request.presence_penalty"
    # Presence penalty

    # ================== RESPONSE ATTRIBUTES ==================
    # Attributes set on the response

    RESPONSE_ID = "gen_ai.response.id"
    # Unique response identifier

    RESPONSE_MODEL = "gen_ai.response.model"
    # Actual model used (may differ from request)

    RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"
    # Array of finish reasons for each choice

    # ================== USAGE ATTRIBUTES ==================
    # Token usage metrics

    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    # Tokens in the prompt

    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
    # Tokens in the completion

    USAGE_TOTAL_TOKENS = "gen_ai.usage.total_tokens"
    # Total tokens used

    # ================== CONTENT ATTRIBUTES ==================
    # For capturing prompts and completions (optional, may contain PII)

    PROMPT = "gen_ai.prompt"
    # The full prompt text (may be truncated)

    COMPLETION = "gen_ai.completion"
    # The full completion text (may be truncated)

    # ================== TOOL ATTRIBUTES ==================
    # For function/tool calling

    TOOL_NAME = "gen_ai.tool.name"
    # Name of the tool being called

    TOOL_DESCRIPTION = "gen_ai.tool.description"
    # Description of the tool

    TOOL_CALL_ID = "gen_ai.tool.call_id"
    # Unique identifier for the tool call

    # ================== PENGUIN CUSTOM ATTRIBUTES ==================
    # Custom attributes specific to Penguin

    PROJECT_ID = "penguin.project_id"
    # Penguin project identifier

    SPAN_TYPE = "penguin.span_type"
    # Type of span: llm, tool, chain, ocr, vlm, embedding, vector_db

    THINKING_TOKENS = "penguin.thinking_tokens"
    # Tokens used for extended thinking (Gemini 2.0, Claude)

    THINKING_CONTENT = "penguin.thinking_content"
    # The actual thinking/reasoning content from extended thinking

    CACHED_TOKENS = "penguin.cached_tokens"
    # Cached tokens (Anthropic prompt caching)


class GenAISpanKind:
    """
    Span kinds for Gen-AI operations.

    Used to categorize different types of AI operations.
    """
    LLM = "llm"
    TOOL = "tool"
    CHAIN = "chain"
    EMBEDDING = "embedding"
    VECTOR_DB = "vector_db"
    OCR = "ocr"
    VLM = "vlm"
    RETRIEVAL = "retrieval"


class GenAISystem:
    """
    Known Gen-AI system identifiers.

    Used as values for gen_ai.system attribute.
    """
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE_AI = "google_ai"
    AWS_BEDROCK = "aws_bedrock"
    AZURE_OPENAI = "azure_openai"
    COHERE = "cohere"


def provider_to_system(provider: str) -> str:
    """
    Map provider name to Gen-AI system identifier.

    Args:
        provider: Provider name from client

    Returns:
        Standardized system identifier
    """
    mapping = {
        "openai": GenAISystem.OPENAI,
        "gemini": GenAISystem.GOOGLE_AI,
        "bedrock": GenAISystem.AWS_BEDROCK,
        "anthropic": GenAISystem.ANTHROPIC,
        "azure": GenAISystem.AZURE_OPENAI,
        "s3vectors": GenAISystem.AWS_BEDROCK,  # S3 Vectors is AWS
    }
    return mapping.get(provider.lower(), provider)
