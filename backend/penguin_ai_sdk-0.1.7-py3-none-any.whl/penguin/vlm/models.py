from typing import Any, Dict, Optional, List
from pydantic import BaseModel

class VLMResult(BaseModel):
    structured_data: Optional[Dict[str, Any]] = None
    raw_text: Optional[str] = None
    provider: str
    model_version: str
    metadata: Dict[str, Any] = {}