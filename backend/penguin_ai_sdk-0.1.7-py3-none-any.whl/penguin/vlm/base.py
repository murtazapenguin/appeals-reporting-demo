from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from .models import VLMResult

class BaseVLMProvider(ABC):
    @abstractmethod
    async def extract(
        self, 
        image_paths: List[str], 
        prompt: str, 
        response_schema: Optional[Dict[str, Any]] = None
    ) -> VLMResult:
        """
        Extract information from one or more images using a prompt and an optional schema.
        """
        pass