"""
Penguin AI Library

A provider-agnostic library for LLM interactions, tool management, and AI services.

Modules:
    - llm: Multi-provider LLM abstraction (Bedrock, Gemini, OpenAI)
    - tools: Universal tool/function calling system
    - services: High-level services (tool generation, etc.)
    - automl: Automated machine learning with hyperparameter optimization
    - embeddings: Text embeddings (AWS Bedrock Titan)
    - vector_db: Vector database (AWS S3 Vectors)
    - data_assets: Bundled datasets (ICD-10, etc.)
    - evals: LLM-based evaluation framework
    - observability: Tracing and logging
"""

__version__ = "0.1.4"


# Lazy imports for data assets (requires pandas)
def load_asset(*args, **kwargs):
    """Load a bundled data asset. Requires pandas."""
    from penguin.data_assets import load_asset as _load_asset
    return _load_asset(*args, **kwargs)


def list_assets(*args, **kwargs):
    """List available data assets. Requires pandas."""
    from penguin.data_assets import list_assets as _list_assets
    return _list_assets(*args, **kwargs)
