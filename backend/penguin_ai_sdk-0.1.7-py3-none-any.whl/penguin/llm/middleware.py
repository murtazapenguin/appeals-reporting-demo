"""
Penguin LLM Middleware Module

Provides middleware-wrapped LLM clients for automatic tracing.
All LLM calls go through the middleware chain when tracing is enabled.
"""

import time
import uuid
from typing import Any, AsyncGenerator, Dict, List, Optional, Type, Union

from pydantic import BaseModel

from .base import BaseChatCompletionClient
from .messages import Message
from .types import ChatCompletionResult, ChatCompletionChunk, ProviderCapabilities

from penguin.observability.middleware import MiddlewareChain, MiddlewareContext
from penguin.observability.context import set_trace_context


class MiddlewareWrappedClient:
    """
    Wraps an LLM client to route all calls through middleware.

    This enables automatic tracing for all LLM operations without
    modifying the underlying provider implementations.

    Usage:
        raw_client = GeminiChatClient(model="gemini-2.0-flash")
        chain = get_llm_middleware_chain()
        client = MiddlewareWrappedClient(raw_client, chain)

        # All calls now go through middleware
        result = await client.create(messages)
    """

    def __init__(
        self,
        client: BaseChatCompletionClient,
        middleware_chain: MiddlewareChain,
    ):
        """
        Initialize middleware-wrapped client.

        Args:
            client: The underlying LLM client
            middleware_chain: Middleware chain for processing requests
        """
        self._client = client
        self._chain = middleware_chain
        self._last_trace_id: Optional[str] = None

    @property
    def last_trace_id(self) -> Optional[str]:
        """Get the trace ID from the last LLM call."""
        return self._last_trace_id

    def _create_context(
        self,
        operation: str,
        messages: List[Message],
        **kwargs
    ) -> MiddlewareContext:
        """Create middleware context for an operation."""
        # Generate IDs
        trace_id = str(uuid.uuid4())
        span_id = str(uuid.uuid4())[:16]

        # Extract relevant parameters
        request_params = {}
        for key in ["temperature", "max_tokens", "top_p", "top_k"]:
            if key in kwargs:
                request_params[key] = kwargs[key]

        return MiddlewareContext(
            trace_id=trace_id,
            span_id=span_id,
            span_name=f"llm.{operation}",
            span_type="llm",
            provider=self._client.provider_name,
            model=self._client.model,
            inputs={"messages": [m.model_dump() if hasattr(m, 'model_dump') else str(m) for m in messages]},
            request_params=request_params,
            attributes={
                "operation": operation,
                "has_tools": kwargs.get("tools") is not None,
                "has_output_format": kwargs.get("output_format") is not None,
            }
        )

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Make a single LLM API call through middleware.

        Args:
            messages: Conversation messages
            tools: Tool definitions
            output_format: Structured output format
            **kwargs: Additional parameters

        Returns:
            ChatCompletionResult from the LLM
        """
        context = self._create_context("create", messages, tools=tools, output_format=output_format, **kwargs)

        try:
            async def _execute(*args, **kw):
                return await self._client.create(messages, tools=tools, output_format=output_format, **kwargs)

            result = await self._chain.execute(context, _execute)

            # Store trace_id AFTER execution (OTel middleware updates it in before_execute)
            self._last_trace_id = context.trace_id

            # Set trace context so get_current_trace_id() works
            set_trace_context(context.trace_id, context.span_id)

            return result
        except Exception:
            # Still capture trace_id on error
            self._last_trace_id = context.trace_id
            raise

    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Make a streaming LLM API call through middleware.

        For streaming, we handle the middleware phases manually:
        - before_execute at stream start
        - after_execute when stream completes
        - on_error if an exception occurs

        Args:
            messages: Conversation messages
            tools: Tool definitions
            output_format: Structured output format
            **kwargs: Additional parameters

        Yields:
            ChatCompletionChunk objects
        """
        context = self._create_context("create_stream", messages, tools=tools, output_format=output_format, **kwargs)
        context.start_time = time.time()

        # Phase 1: before_execute (OTel middleware updates trace_id here)
        context = self._chain.before_execute(context)

        # Store trace_id AFTER before_execute (OTel middleware updates it)
        self._last_trace_id = context.trace_id

        # Set trace context so get_current_trace_id() works
        set_trace_context(context.trace_id, context.span_id)

        # Track accumulated data for final context update
        accumulated_content = []
        accumulated_thinking = []
        accumulated_usage = None
        final_chunk = None

        try:
            async for chunk in self._client.create_stream(messages, tools=tools, output_format=output_format, **kwargs):
                # Accumulate content
                if chunk.delta_content:
                    accumulated_content.append(chunk.delta_content)

                # Accumulate thinking content
                if hasattr(chunk, 'delta_thinking') and chunk.delta_thinking:
                    accumulated_thinking.append(chunk.delta_thinking)

                # Track usage (usually in last chunk)
                if chunk.usage:
                    accumulated_usage = chunk.usage

                final_chunk = chunk
                yield chunk

            # Phase 2: after_execute (stream completed)
            context.end_time = time.time()
            context.status = "OK"

            # Update context with accumulated data
            if accumulated_usage:
                context.input_tokens = accumulated_usage.prompt_tokens
                context.output_tokens = accumulated_usage.completion_tokens
                context.total_tokens = accumulated_usage.total_tokens

            context.outputs = "".join(accumulated_content)

            # Create a result-like object for after_execute
            class StreamResult:
                def __init__(self, content, usage, finish_reason, model, tool_calls=None, thinking=None):
                    self.content = content
                    self.text = content  # Alias for compatibility
                    self.usage = usage
                    self.finish_reason = finish_reason
                    self.model = model
                    self.tool_calls = tool_calls
                    self.thinking = thinking

            result = StreamResult(
                content=context.outputs,
                usage=accumulated_usage,
                finish_reason=final_chunk.finish_reason if final_chunk else None,
                model=self._client.model,
                tool_calls=final_chunk.delta_tool_calls if final_chunk else None,
                thinking="".join(accumulated_thinking) if accumulated_thinking else None,
            )

            self._chain.after_execute(context, result)

        except Exception as e:
            # Phase 3: on_error
            context.end_time = time.time()
            context.status = "ERROR"
            context.error = str(e)
            self._chain.on_error(context, e)
            raise

    # ================== PROXY PROPERTIES ==================

    @property
    def provider_name(self) -> str:
        """Return the provider name."""
        return self._client.provider_name

    @property
    def model(self) -> str:
        """Return the model name."""
        return self._client.model

    @property
    def capabilities(self) -> ProviderCapabilities:
        """Return provider capabilities."""
        return self._client.capabilities

    @property
    def tracing_enabled(self) -> bool:
        """Check if tracing is enabled."""
        return self._client.tracing_enabled

    def __getattr__(self, name: str) -> Any:
        """Proxy any other attributes to the underlying client."""
        return getattr(self._client, name)


def get_llm_middleware_chain() -> MiddlewareChain:
    """
    Get the middleware chain for LLM operations.

    Returns a chain with OTelMiddleware when tracing is enabled,
    or an empty chain when disabled.

    Returns:
        MiddlewareChain configured for LLM tracing
    """
    from penguin.observability import is_tracing_enabled, OTelMiddleware

    chain = MiddlewareChain()

    if is_tracing_enabled():
        # Add OTel middleware for span creation
        chain.add(OTelMiddleware(
            tracer_name="penguin.llm",
            capture_prompts=True,
            capture_completions=True,
        ))

    return chain
