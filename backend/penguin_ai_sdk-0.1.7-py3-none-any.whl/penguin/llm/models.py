"""
Penguin LLM Model Registry

Centralized model definitions for all providers.
Adding a new model? Just add it to the MODELS dict below!
"""

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Set
from enum import Enum

logger = logging.getLogger(__name__)


class Provider(str, Enum):
    """Supported LLM providers."""
    BEDROCK = "bedrock"
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    GEMINI = "gemini"


@dataclass
class ModelInfo:
    """
    Model metadata and capabilities.

    Attributes:
        id: Friendly name (e.g., "claude-sonnet-4-5")
        provider: Which provider this model belongs to
        api_id: Actual API model ID sent to the provider
        supports_vision: Whether the model can process images
        supports_thinking: Whether the model supports extended thinking
        supports_tools: Whether the model supports function/tool calling
        max_tokens: Maximum output tokens
        context_window: Maximum context window size
        description: Human-readable description
        thinking_default: Whether thinking is enabled by default (Gemini 3.x models)
        thinking_disableable: Whether thinking can be disabled (False for Gemini 3 Pro)
    """
    id: str
    provider: Provider
    api_id: str
    supports_vision: bool = False
    supports_thinking: bool = False
    supports_tools: bool = True
    max_tokens: int = 8192
    context_window: int = 128000
    description: str = ""
    thinking_default: bool = False
    thinking_disableable: bool = True


# =============================================================================
# MODEL DEFINITIONS
# =============================================================================
# To add a new model, just add an entry here!
# The model will automatically be available in list_models() and the provider.

MODELS: Dict[str, ModelInfo] = {
    # =========================================================================
    # BEDROCK (Claude via AWS)
    # =========================================================================
    "claude-opus-4-5": ModelInfo(
        id="claude-opus-4-5",
        provider=Provider.BEDROCK,
        api_id="us.anthropic.claude-opus-4-5-20251101-v1:0",  # Cross-region inference profile
        supports_vision=True,
        supports_thinking=True,
        max_tokens=16384,
        context_window=200000,
        description="Claude Opus 4.5 - Most intelligent model with extended thinking",
    ),
    "claude-sonnet-4-5": ModelInfo(
        id="claude-sonnet-4-5",
        provider=Provider.BEDROCK,
        api_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=200000,
        description="Claude Sonnet 4.5 - Latest model with extended thinking",
    ),
    "claude-sonnet-4": ModelInfo(
        id="claude-sonnet-4",
        provider=Provider.BEDROCK,
        api_id="us.anthropic.claude-sonnet-4-20250514-v1:0",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=200000,
        description="Claude Sonnet 4",
    ),
    "claude-3-opus": ModelInfo(
        id="claude-3-opus",
        provider=Provider.BEDROCK,
        api_id="anthropic.claude-3-opus-20240229-v1:0",
        supports_vision=True,
        supports_thinking=False,
        max_tokens=4096,
        context_window=200000,
        description="Claude 3 Opus - Most capable Claude 3",
    ),
    "claude-3-5-sonnet": ModelInfo(
        id="claude-3-5-sonnet",
        provider=Provider.BEDROCK,
        api_id="anthropic.claude-3-5-sonnet-20241022-v2:0",
        supports_vision=True,
        supports_thinking=False,
        max_tokens=8192,
        context_window=200000,
        description="Claude 3.5 Sonnet",
    ),

    # =========================================================================
    # OPENAI
    # =========================================================================
    "gpt-4o": ModelInfo(
        id="gpt-4o",
        provider=Provider.OPENAI,
        api_id="gpt-4o",
        supports_vision=True,
        supports_thinking=False,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o - Multimodal flagship model",
    ),
    "gpt-4o-mini": ModelInfo(
        id="gpt-4o-mini",
        provider=Provider.OPENAI,
        api_id="gpt-4o-mini",
        supports_vision=True,
        supports_thinking=False,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o Mini - Faster and cheaper",
    ),
    "gpt-3.5-turbo": ModelInfo(
        id="gpt-3.5-turbo",
        provider=Provider.OPENAI,
        api_id="gpt-3.5-turbo",
        supports_vision=False,
        supports_thinking=False,
        max_tokens=4096,
        context_window=16385,
        description="GPT-3.5 Turbo - Fast and cost-effective",
    ),
    "o1": ModelInfo(
        id="o1",
        provider=Provider.OPENAI,
        api_id="o1",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=100000,
        context_window=200000,
        description="o1 - Advanced reasoning model",
    ),
    "o1-mini": ModelInfo(
        id="o1-mini",
        provider=Provider.OPENAI,
        api_id="o1-mini",
        supports_vision=False,
        supports_thinking=True,
        max_tokens=65536,
        context_window=128000,
        description="o1-mini - Faster reasoning model",
    ),

    # =========================================================================
    # AZURE OPENAI
    # =========================================================================
    # Note: api_id is the deployment name, which users configure in Azure
    "azure-gpt-4o": ModelInfo(
        id="azure-gpt-4o",
        provider=Provider.AZURE_OPENAI,
        api_id="gpt-4o",  # Default deployment name, can be overridden
        supports_vision=True,
        supports_thinking=False,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o via Azure OpenAI",
    ),
    "azure-gpt-4o-mini": ModelInfo(
        id="azure-gpt-4o-mini",
        provider=Provider.AZURE_OPENAI,
        api_id="gpt-4o-mini",  # Default deployment name
        supports_vision=True,
        supports_thinking=False,
        max_tokens=16384,
        context_window=128000,
        description="GPT-4o Mini via Azure OpenAI",
    ),

    # =========================================================================
    # GEMINI
    # =========================================================================
    # Thinking parameter behavior:
    # - Gemini 3.x: uses `thinking_level` ("minimal", "low", "medium", "high")
    # - Gemini 2.5.x: uses `thinking_budget` (0 to disable, -1 for dynamic)
    # - Gemini 2.0.x: No thinking support (deprecated March 3, 2026)
    # IMPORTANT: Do NOT use both thinking_level and thinking_budget together!

    # --- Gemini 3.x (Latest, uses thinking_level) ---
    "gemini-3-flash-preview": ModelInfo(
        id="gemini-3-flash-preview",
        provider=Provider.GEMINI,
        api_id="gemini-3-flash-preview",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 3 Flash Preview - thinking enabled by default",
        thinking_default=True,
        thinking_disableable=True,  # Can use thinking_level="minimal"
    ),
    # NOTE: "gemini-3-pro" does NOT exist - only the preview version is available
    "gemini-3-pro-preview": ModelInfo(
        id="gemini-3-pro-preview",
        provider=Provider.GEMINI,
        api_id="gemini-3-pro-preview",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 3 Pro Preview - thinking always enabled, cannot be disabled",
        thinking_default=True,
        thinking_disableable=False,  # Cannot disable thinking!
    ),

    # --- Gemini 2.5.x (Stable, uses thinking_budget) ---
    "gemini-2.5-pro": ModelInfo(
        id="gemini-2.5-pro",
        provider=Provider.GEMINI,
        api_id="gemini-2.5-pro",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.5 Pro - advanced reasoning, thinking enabled by default",
        thinking_default=True,
        thinking_disableable=False,  # Cannot disable (min budget 128)
    ),
    "gemini-2.5-flash": ModelInfo(
        id="gemini-2.5-flash",
        provider=Provider.GEMINI,
        api_id="gemini-2.5-flash",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.5 Flash - best price-performance with thinking",
        thinking_default=True,
        thinking_disableable=True,  # Can disable with budget=0
    ),
    "gemini-2.5-flash-lite": ModelInfo(
        id="gemini-2.5-flash-lite",
        provider=Provider.GEMINI,
        api_id="gemini-2.5-flash-lite",
        supports_vision=True,
        supports_thinking=True,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.5 Flash-Lite - fastest, thinking OFF by default",
        thinking_default=False,  # Thinking OFF by default
        thinking_disableable=True,
    ),

    # --- Gemini 2.0.x (DEPRECATED - retiring March 3, 2026) ---
    "gemini-2.0-flash": ModelInfo(
        id="gemini-2.0-flash",
        provider=Provider.GEMINI,
        api_id="gemini-2.0-flash",
        supports_vision=True,
        supports_thinking=False,
        max_tokens=8192,
        context_window=1000000,
        description="Gemini 2.0 Flash (DEPRECATED - retiring March 3, 2026)",
        thinking_default=False,
        thinking_disableable=True,
    ),
}


# =============================================================================
# DEFAULT MODELS PER PROVIDER
# =============================================================================

DEFAULT_MODELS: Dict[Provider, str] = {
    Provider.BEDROCK: "claude-sonnet-4-5",
    Provider.OPENAI: "gpt-4o",
    Provider.AZURE_OPENAI: "azure-gpt-4o",
    Provider.GEMINI: "gemini-2.5-flash",  # Stable, best price-performance
}


# =============================================================================
# API ID REVERSE LOOKUP
# =============================================================================
# Maps API model IDs back to friendly names for direct API ID usage

API_ID_TO_MODEL: Dict[str, str] = {
    model.api_id: model.id for model in MODELS.values()
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_model(model_id: str) -> Optional[ModelInfo]:
    """
    Get model info by ID (friendly name or API ID).

    Args:
        model_id: Model identifier (friendly name or raw API ID)

    Returns:
        ModelInfo or None if not found
    """
    # Try friendly name first
    if model_id in MODELS:
        return MODELS[model_id]

    # Try API ID lookup
    if model_id in API_ID_TO_MODEL:
        friendly_id = API_ID_TO_MODEL[model_id]
        return MODELS[friendly_id]

    return None


def list_models(provider: Optional[str] = None) -> List[ModelInfo]:
    """
    List all available models.

    Args:
        provider: Optional provider name to filter by ("bedrock", "openai", "gemini")

    Returns:
        List of ModelInfo objects

    Example:
        # List all models
        all_models = list_models()

        # List only Bedrock models
        bedrock_models = list_models("bedrock")
    """
    models = list(MODELS.values())
    if provider:
        try:
            provider_enum = Provider(provider)
            models = [m for m in models if m.provider == provider_enum]
        except ValueError:
            return []  # Invalid provider
    return models


def get_default_model(provider: str) -> str:
    """
    Get default model ID for a provider.

    Args:
        provider: Provider name ("bedrock", "openai", "gemini")

    Returns:
        Default model ID for the provider

    Raises:
        ValueError: If provider is not recognized
    """
    try:
        provider_enum = Provider(provider)
        default = DEFAULT_MODELS.get(provider_enum)
        if default:
            return default
        raise ValueError(f"No default model configured for provider: {provider}")
    except ValueError:
        valid_providers = ", ".join(p.value for p in Provider)
        raise ValueError(
            f"Unknown provider: '{provider}'. Valid providers: {valid_providers}"
        )


def resolve_model_id(model_id: str, provider: str) -> str:
    """
    Resolve friendly model ID to actual API model ID.

    Args:
        model_id: Friendly model name (e.g., "claude-sonnet-4-5") or raw API ID
        provider: Provider name

    Returns:
        API model ID to send to the provider

    Raises:
        ValueError: If model exists but belongs to a different provider

    Example:
        api_id = resolve_model_id("claude-sonnet-4-5", "bedrock")
        # Returns: "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    """
    # Look up model (handles both friendly names and API IDs)
    model = get_model(model_id)

    if model:
        try:
            provider_enum = Provider(provider)
            if model.provider == provider_enum:
                return model.api_id
            else:
                # Model exists but for different provider - this is likely an error
                raise ValueError(
                    f"Model '{model_id}' belongs to provider '{model.provider.value}', "
                    f"not '{provider}'. Did you mean to use a different model or provider?"
                )
        except ValueError as e:
            if "Model '" in str(e):
                raise  # Re-raise our mismatch error
            # Invalid provider string
            valid_providers = ", ".join(p.value for p in Provider)
            raise ValueError(
                f"Unknown provider: '{provider}'. Valid providers: {valid_providers}"
            )

    # Not in registry - assume it's already an API ID, but warn
    logger.warning(
        f"Model '{model_id}' not found in registry. Using as raw API ID. "
        f"Capabilities (vision, thinking) will use defaults. "
        f"Consider adding this model to penguin/llm/models.py"
    )
    return model_id


def get_vision_models(provider: Optional[str] = None) -> Set[str]:
    """
    Get set of model IDs that support vision.

    Args:
        provider: Optional provider name to filter by

    Returns:
        Set of model IDs with vision support
    """
    models = list_models(provider)
    return {m.id for m in models if m.supports_vision}


def get_thinking_models(provider: Optional[str] = None) -> Set[str]:
    """
    Get set of model IDs that support extended thinking.

    Args:
        provider: Optional provider name to filter by

    Returns:
        Set of model IDs with thinking support
    """
    models = list_models(provider)
    return {m.id for m in models if m.supports_thinking}


def get_model_capabilities(model_id: str) -> Dict[str, bool]:
    """
    Get capabilities for a specific model.

    Args:
        model_id: Model identifier

    Returns:
        Dict with capability flags

    Example:
        caps = get_model_capabilities("claude-sonnet-4-5")
        # Returns: {"vision": True, "thinking": True, "tools": True}
    """
    model = MODELS.get(model_id)
    if model:
        return {
            "vision": model.supports_vision,
            "thinking": model.supports_thinking,
            "tools": model.supports_tools,
        }
    return {"vision": False, "thinking": False, "tools": True}
