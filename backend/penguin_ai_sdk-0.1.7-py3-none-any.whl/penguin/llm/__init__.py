"""
Penguin LLM Module

Multi-provider LLM abstraction layer with unified interface.

Usage:
    from penguin.llm import create_client, UserMessage, SystemMessage, ChatSession

    # Create a client
    client = create_client("openai", model="gpt-4o")

    # Or auto-detect from environment
    client = create_client_from_env()

    # Make requests
    result = await client.create([
        SystemMessage("You are a helpful assistant."),
        UserMessage("Hello!")
    ])

    # Multi-turn conversation with ChatSession
    session = ChatSession(client, system_instruction="You are helpful.")
    response = await session.send("Hello!")
    response = await session.send("Tell me more.")  # History maintained
"""

# Factory functions
from .factory import (
    create_client,
    create_client_from_env,
    get_available_providers,
)

# Model registry
from .models import (
    ModelInfo,
    Provider,
    list_models,
    get_model,
    get_default_model,
    get_vision_models,
    get_thinking_models,
    get_model_capabilities,
)

# Middleware (for tracing)
from .middleware import (
    MiddlewareWrappedClient,
    get_llm_middleware_chain,
)

# Base classes
from .base import (
    BaseChatCompletionClient,
    ChatCompletionError,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
    ModelNotAvailableError,
    ContentFilterError,
)

# Message types
from .messages import (
    Message,
    SystemMessage,
    UserMessage,
    AssistantMessage,
    ToolMessage,
    ToolCall,
    MessageRole,
    AnyMessage,
    create_message,
)

# Response types
from .types import (
    ChatCompletionResult,
    ChatCompletionChunk,
    TokenUsage,
    ProviderCapabilities,
    FinishReason,
)

# Session management
from .session import ChatSession
from .registry import (
    ConversationRegistry,
    SessionSummary,
    # Convenience functions (no registry needed)
    list_sessions,
    get_session,
    delete_session,
    session_exists,
)

__all__ = [
    # Factory
    "create_client",
    "create_client_from_env",
    "get_available_providers",
    # Model registry
    "ModelInfo",
    "Provider",
    "list_models",
    "get_model",
    "get_default_model",
    "get_vision_models",
    "get_thinking_models",
    "get_model_capabilities",
    # Middleware
    "MiddlewareWrappedClient",
    "get_llm_middleware_chain",
    # Base
    "BaseChatCompletionClient",
    "ChatCompletionError",
    "RateLimitError",
    "AuthenticationError",
    "InvalidRequestError",
    "ModelNotAvailableError",
    "ContentFilterError",
    # Messages
    "Message",
    "SystemMessage",
    "UserMessage",
    "AssistantMessage",
    "ToolMessage",
    "ToolCall",
    "MessageRole",
    "AnyMessage",
    "create_message",
    # Types
    "ChatCompletionResult",
    "ChatCompletionChunk",
    "TokenUsage",
    "ProviderCapabilities",
    "FinishReason",
    # Session management
    "ChatSession",
    "ConversationRegistry",
    "SessionSummary",
    # Convenience functions
    "list_sessions",
    "get_session",
    "delete_session",
    "session_exists",
]
