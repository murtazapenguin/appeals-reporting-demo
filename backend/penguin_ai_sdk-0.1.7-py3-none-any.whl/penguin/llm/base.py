"""
Penguin LLM Base Module

Abstract base class for all LLM provider implementations.
Defines the interface that providers must implement for unified access.
"""

import json
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Any, AsyncGenerator, Dict, Generator, List, Optional, Type, TYPE_CHECKING, Union

from pydantic import BaseModel

from .messages import (
    Message,
    AssistantMessage,
    ToolMessage,
)
from .types import (
    ChatCompletionResult,
    ChatCompletionChunk,
    TokenUsage,
    ProviderCapabilities,
)

# Tracing support
from penguin.observability.config import is_tracing_enabled, should_capture_content, get_tracer
from penguin.observability.attributes import GenAIAttributes, GenAISpanKind

# Middleware support - import lazily to avoid circular imports
if TYPE_CHECKING:
    from penguin.middleware import MiddlewareChain, MiddlewareContext, BaseMiddleware


class BaseChatCompletionClient(ABC):
    """
    Abstract base class for LLM provider implementations.

    Provides unified interface for different LLM providers (OpenAI, Gemini, Claude)
    while abstracting away provider-specific API differences.

    All providers MUST implement:
    - _create_impl(): Single completion request (provider-specific)
    - _create_stream_impl(): Streaming completion request (provider-specific)

    The public create() method wraps _create_impl() with middleware processing.

    Middleware Support:
        client = create_client("bedrock", model="claude-sonnet-4-5")
        client.use(PromptInjectionMiddleware())
        client.use(OutputSafetyMiddleware())

        # All calls now go through middleware
        result = await client.create([UserMessage("Hello")])

    The three-step conversion pattern:
    1. _convert_messages(): Message -> Provider format
    2. _call_api(): Execute provider API
    3. _normalize_response(): Provider response -> ChatCompletionResult
    """

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        **kwargs: Any
    ):
        """
        Initialize the chat completion client.

        Args:
            model: Model identifier (e.g., "gpt-4", "gemini-2.0-flash")
            api_key: API key (falls back to environment variable)
            **kwargs: Provider-specific configuration
        """
        self.model = model
        self.api_key = api_key
        self.config = kwargs

        # Initialize middleware chain
        self._middleware: Optional["MiddlewareChain"] = None

    # ================== MIDDLEWARE SUPPORT ==================

    def use(self, middleware: Union["BaseMiddleware", List["BaseMiddleware"]]) -> "BaseChatCompletionClient":
        """
        Add middleware to this client.

        Middleware is executed in the order added for requests,
        and in reverse order for responses.

        Args:
            middleware: Single middleware instance OR list of middlewares to add

        Returns:
            Self for method chaining

        Example:
            # Single middleware
            client.use(PromptInjectionMiddleware())

            # Chain multiple calls
            client.use(PromptInjectionMiddleware()).use(OutputSafetyMiddleware())

            # Pass a list
            client.use([
                PromptInjectionMiddleware(),
                OutputSafetyMiddleware(),
                GuardrailMiddleware(max_input_length=5000)
            ])
        """
        if self._middleware is None:
            from penguin.middleware import MiddlewareChain
            self._middleware = MiddlewareChain()

        # Handle list of middlewares
        if isinstance(middleware, list):
            for mw in middleware:
                self._middleware.add(mw)
        else:
            self._middleware.add(middleware)
        return self

    @property
    def middleware(self) -> Optional["MiddlewareChain"]:
        """Get the middleware chain (may be None if no middleware added)."""
        return self._middleware

    @property
    def has_middleware(self) -> bool:
        """Check if any middleware is configured."""
        return self._middleware is not None and len(self._middleware) > 0

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name (e.g., 'openai', 'gemini', 'bedrock')."""
        pass

    @property
    @abstractmethod
    def capabilities(self) -> ProviderCapabilities:
        """Return provider capabilities."""
        pass

    # ================== PUBLIC API WITH MIDDLEWARE ==================

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Make a single LLM API call with middleware processing.

        This method wraps _create_impl() with middleware:
        1. Pre-process messages through middleware
        2. Call provider-specific _create_impl()
        3. Post-process result through middleware

        Args:
            messages: Conversation messages
            tools: Tool definitions in OpenAI function format
            output_format: Pydantic model OR JSON schema dict for structured output
            **kwargs: temperature, max_tokens, etc.

        Returns:
            Standardized ChatCompletionResult

        Raises:
            ChatCompletionError: If the API call fails
            SecurityViolation: If middleware blocks the request

        Example with middleware:
            client = create_client("openai", model="gpt-4")
            client.use(PromptInjectionMiddleware())

            # Blocked if injection detected
            result = await client.create([UserMessage("Hello")])

        Example with Pydantic output:
            class MovieReview(BaseModel):
                title: str
                rating: int

            result = await client.create(messages, output_format=MovieReview)
        """
        # If no middleware, call implementation directly
        if not self.has_middleware:
            return await self._create_impl(messages, tools, output_format, **kwargs)

        # Create middleware context
        from penguin.middleware import MiddlewareContext

        ctx = MiddlewareContext(
            operation="llm_call",
            messages=list(messages),
            client_name=self.provider_name,
            metadata={
                "model": self.model,
                "has_tools": tools is not None,
                "has_output_format": output_format is not None,
            }
        )

        # Pre-process with middleware
        ctx = await self._middleware.process_request(ctx)

        # Call provider implementation with potentially modified messages
        result = await self._create_impl(ctx.messages, tools, output_format, **kwargs)

        # Post-process with middleware
        result = await self._middleware.process_response(ctx, result)

        return result

    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Make a streaming LLM API call.

        Note: Middleware is applied to input messages only for streaming.
        Output filtering on streams would require buffering chunks.

        Args:
            messages: Conversation messages
            tools: Tool definitions in OpenAI function format
            output_format: Pydantic model OR JSON schema dict for structured output
            **kwargs: temperature, max_tokens, etc.

        Yields:
            ChatCompletionChunk objects

        Raises:
            ChatCompletionError: If the API call fails
            SecurityViolation: If middleware blocks the request
        """
        # Apply input middleware for streaming
        if self.has_middleware:
            from penguin.middleware import MiddlewareContext

            ctx = MiddlewareContext(
                operation="llm_call_stream",
                messages=list(messages),
                client_name=self.provider_name,
                metadata={"model": self.model, "streaming": True}
            )

            ctx = await self._middleware.process_request(ctx)
            messages = ctx.messages

        # Delegate to implementation
        async for chunk in self._create_stream_impl(messages, tools, output_format, **kwargs):
            yield chunk

    # ================== PROVIDER IMPLEMENTATION METHODS ==================

    @abstractmethod
    async def _create_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Provider-specific implementation of create().

        Providers MUST implement this method. It is called by create()
        after middleware pre-processing.

        Args:
            messages: Conversation messages (may be modified by middleware)
            tools: Tool definitions in OpenAI function format
            output_format: Pydantic model OR JSON schema dict for structured output
            **kwargs: temperature, max_tokens, etc.

        Returns:
            Standardized ChatCompletionResult
        """
        pass

    @abstractmethod
    async def _create_stream_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Provider-specific implementation of create_stream().

        Providers MUST implement this method. It is called by create_stream()
        after middleware pre-processing.

        Args:
            messages: Conversation messages (may be modified by middleware)
            tools: Tool definitions in OpenAI function format
            output_format: Pydantic model OR JSON schema dict for structured output
            **kwargs: temperature, max_tokens, etc.

        Yields:
            ChatCompletionChunk objects
        """
        pass
        # This is a generator, so yield is required
        if False:  # pragma: no cover
            yield

    # ================== CONVERSION HELPERS ==================

    @abstractmethod
    def _convert_messages(self, messages: List[Message]) -> Any:
        """
        Convert standardized messages to provider format.

        Each provider must implement this to handle their specific
        message format requirements.
        """
        pass

    @abstractmethod
    def _convert_tools(
        self,
        tools: Optional[List[Dict[str, Any]]]
    ) -> Any:
        """
        Convert OpenAI-format tools to provider format.

        OpenAI format is the standard:
        {
            "name": "function_name",
            "description": "...",
            "parameters": { JSON Schema }
        }
        """
        pass

    @abstractmethod
    def _normalize_response(self, response: Any) -> ChatCompletionResult:
        """Normalize provider response to ChatCompletionResult."""
        pass

    # ================== DEFAULT IMPLEMENTATIONS ==================

    def _normalize_usage(self, usage: Any) -> TokenUsage:
        """
        Normalize token usage to standard format.

        Default implementation returns empty usage.
        Providers should override with their specific parsing logic.
        """
        return TokenUsage()

    def _convert_messages_to_openai_format(
        self,
        messages: List[Message]
    ) -> List[Dict[str, Any]]:
        """
        Convert internal Message objects to OpenAI-compatible format.

        This helper can be used by providers that use OpenAI-like formats.
        """
        api_messages = []

        for msg in messages:
            api_msg: Dict[str, Any] = {
                "role": msg.role,
                "content": msg.content
            }

            # Handle assistant messages with tool calls
            if isinstance(msg, AssistantMessage) and msg.tool_calls:
                api_msg["tool_calls"] = [
                    {
                        "id": tc.call_id,
                        "type": "function",
                        "function": {
                            "name": tc.tool_name,
                            "arguments": json.dumps(tc.parameters)
                            if isinstance(tc.parameters, dict)
                            else tc.parameters,
                        },
                    }
                    for tc in msg.tool_calls
                ]

            # Handle tool result messages
            if isinstance(msg, ToolMessage):
                api_msg["tool_call_id"] = msg.tool_call_id

            api_messages.append(api_msg)

        return api_messages

    def _pydantic_to_json_schema(self, model: Type[BaseModel]) -> Dict[str, Any]:
        """
        Convert Pydantic model to JSON Schema.

        Works with both Pydantic v1 and v2.
        """
        if hasattr(model, "model_json_schema"):
            # Pydantic v2
            return model.model_json_schema()
        else:
            # Pydantic v1 (deprecated but supported)
            return model.schema()  # type: ignore

    def _add_additional_properties_false(self, schema: Dict[str, Any]) -> None:
        """
        Recursively add additionalProperties: false to object schemas.

        Required by OpenAI/Azure for strict mode JSON schema validation.
        Call this in provider-specific code where needed.
        """
        if isinstance(schema, dict):
            # Add to any object type
            if schema.get("type") == "object" or "properties" in schema:
                schema["additionalProperties"] = False

            # Process nested properties
            if "properties" in schema:
                for prop_schema in schema["properties"].values():
                    self._add_additional_properties_false(prop_schema)

            # Process $defs (Pydantic v2 uses this for nested models)
            if "$defs" in schema:
                for def_schema in schema["$defs"].values():
                    self._add_additional_properties_false(def_schema)

            # Process definitions (Pydantic v1)
            if "definitions" in schema:
                for def_schema in schema["definitions"].values():
                    self._add_additional_properties_false(def_schema)

            # Process array items
            if "items" in schema:
                self._add_additional_properties_false(schema["items"])

    def _normalize_schema(
        self,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]]
    ) -> tuple:
        """
        Normalize output_format to (schema_dict, schema_name).

        Args:
            output_format: Either a Pydantic model class or a raw JSON schema dict

        Returns:
            Tuple of (schema_dict, schema_name)
            - schema_dict: The JSON schema as a dict
            - schema_name: Name for the schema (class name or "structured_output")
        """
        if output_format is None:
            return None, None

        if isinstance(output_format, dict):
            # Raw JSON schema dict
            return output_format, output_format.get("title", "structured_output")

        # Pydantic model
        try:
            schema = self._pydantic_to_json_schema(output_format)
            return schema, output_format.__name__
        except Exception:
            # Fallback - treat as dict if it looks like one
            if hasattr(output_format, "get"):
                return output_format, "structured_output"
            raise ValueError(f"output_format must be a Pydantic model or dict, got {type(output_format)}")

    # ================== TRACING HELPERS ==================

    @contextmanager
    def _create_llm_span(
        self,
        operation: str = "create",
        **extra_attributes
    ) -> Generator:
        """
        Create an OpenTelemetry span for LLM operations.

        Usage:
            with self._create_llm_span() as span:
                result = await self._call_api(...)
                span.set_attribute("gen_ai.usage.input_tokens", result.usage.prompt_tokens)
                return result

        Args:
            operation: Operation name (default: "create")
            **extra_attributes: Additional span attributes

        Yields:
            OpenTelemetry span (or no-op span if tracing disabled)
        """
        tracer = get_tracer("penguin.llm")
        with tracer.start_as_current_span(f"llm.{operation}") as span:
            # Set standard attributes
            span.set_attribute(GenAIAttributes.SPAN_TYPE, GenAISpanKind.LLM)
            span.set_attribute(GenAIAttributes.REQUEST_MODEL, self.model)
            span.set_attribute(GenAIAttributes.SYSTEM, self.provider_name)

            # Set extra attributes
            for key, value in extra_attributes.items():
                span.set_attribute(key, value)

            yield span

    def _record_llm_result(self, span, result: ChatCompletionResult) -> None:
        """
        Record LLM result attributes on a span.

        Args:
            span: OpenTelemetry span
            result: Chat completion result
        """
        if result.usage:
            span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, result.usage.prompt_tokens)
            span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, result.usage.completion_tokens)
            span.set_attribute(GenAIAttributes.USAGE_TOTAL_TOKENS, result.usage.total_tokens)

        span.set_attribute("gen_ai.response.finish_reason", result.finish_reason or "unknown")

        if result.tool_calls:
            span.set_attribute("gen_ai.response.tool_calls", len(result.tool_calls))

        # Capture content if enabled
        if should_capture_content() and result.content:
            content = result.content[:10000]
            span.set_attribute(GenAIAttributes.COMPLETION, content)

    @property
    def tracing_enabled(self) -> bool:
        """Check if tracing is enabled."""
        return is_tracing_enabled()


# ================== EXCEPTIONS ==================

class ChatCompletionError(Exception):
    """Base exception for chat completion errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
    ):
        self.provider = provider
        self.status_code = status_code
        self.response_data = response_data
        super().__init__(message)


class RateLimitError(ChatCompletionError):
    """Rate limit exceeded."""
    pass


class AuthenticationError(ChatCompletionError):
    """Authentication failed."""
    pass


class InvalidRequestError(ChatCompletionError):
    """Invalid request parameters."""
    pass


class ModelNotAvailableError(ChatCompletionError):
    """Requested model not available."""
    pass


class ContentFilterError(ChatCompletionError):
    """Content was filtered by safety systems."""
    pass
