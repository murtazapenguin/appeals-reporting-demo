"""
Penguin LLM Providers

Provider-specific implementations of BaseChatCompletionClient.

Available providers:
- GeminiChatClient: Google Gemini (Gemini 2.0, 1.5)
- OpenAIChatClient: OpenAI GPT (GPT-4o, GPT-4, GPT-3.5)
- AzureOpenAIChatClient: Azure OpenAI (GPT-4o, GPT-4)
- BedrockClaudeChatClient: AWS Bedrock Claude (Claude 3.5, 3)

Usage:
    from penguin.llm.providers import OpenAIChatClient

    # Direct instantiation
    client = OpenAIChatClient(model="gpt-4o")

    # Or use factory (recommended)
    from penguin.llm import create_client
    client = create_client("openai", model="gpt-4o")

Note: Providers are lazily imported to avoid requiring all dependencies.
Use the factory create_client() for automatic lazy loading.
"""

# Lazy imports to avoid requiring all provider dependencies
# Each provider is only imported when accessed

__all__ = [
    # Primary names
    "GeminiChatClient",
    "OpenAIChatClient",
    "AzureOpenAIChatClient",
    "BedrockClaudeChatClient",
    # Backward compatibility aliases
    "GeminiLLMProvider",
    "OpenAILLMProvider",
    "BedrockLLMProvider",
]


def __getattr__(name):
    """Lazy import providers on first access."""
    if name in ("GeminiChatClient", "GeminiLLMProvider"):
        from .gemini import GeminiChatClient, GeminiLLMProvider
        return GeminiChatClient if name == "GeminiChatClient" else GeminiLLMProvider

    if name in ("OpenAIChatClient", "OpenAILLMProvider"):
        from .openai import OpenAIChatClient, OpenAILLMProvider
        return OpenAIChatClient if name == "OpenAIChatClient" else OpenAILLMProvider

    if name == "AzureOpenAIChatClient":
        from .azure_openai import AzureOpenAIChatClient
        return AzureOpenAIChatClient

    if name in ("BedrockClaudeChatClient", "BedrockLLMProvider"):
        from .bedrock import BedrockClaudeChatClient, BedrockLLMProvider
        return BedrockClaudeChatClient if name == "BedrockClaudeChatClient" else BedrockLLMProvider

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
