"""
Penguin AWS Bedrock Claude LLM Provider

AWS Bedrock Claude implementation of BaseChatCompletionClient.
"""

import asyncio
import json
import os
import re
from typing import Any, AsyncGenerator, Dict, List, Optional, Type

from pydantic import BaseModel

# Try to import json_repair for robust JSON parsing
try:
    from json_repair import repair_json
    HAS_JSON_REPAIR = True
except ImportError:
    HAS_JSON_REPAIR = False

from ..base import (
    BaseChatCompletionClient,
    ChatCompletionError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
)
from ..messages import (
    Message,
    SystemMessage,
    AssistantMessage,
    ToolMessage,
    ToolCall,
)
from ..types import (
    ChatCompletionResult,
    ChatCompletionChunk,
    TokenUsage,
    ProviderCapabilities,
    FinishReason,
)
from ..models import resolve_model_id, get_model


class BedrockClaudeChatClient(BaseChatCompletionClient):
    """
    AWS Bedrock Claude chat completion client.

    Supports:
    - Claude Sonnet 4.5, Claude Sonnet 4, Claude 3 Opus, Claude 3 Haiku
    - Structured output via JSON
    - Tool/function calling
    - Streaming responses

    Uses AWS credentials from environment or boto3 credential chain.
    """

    def __init__(
        self,
        model: str = "claude-sonnet-4-5",
        region_name: Optional[str] = None,
        profile_name: Optional[str] = None,
        read_timeout: int = 600,
        connect_timeout: int = 60,
        max_retries: int = 3,
        **kwargs: Any
    ):
        """
        Initialize Bedrock Claude client.

        Args:
            model: Model identifier (e.g., "claude-3-5-sonnet")
            region_name: AWS region (falls back to AWS_DEFAULT_REGION)
            profile_name: AWS profile name for credentials
            read_timeout: Read timeout in seconds (default: 600 = 10 min)
            connect_timeout: Connection timeout in seconds (default: 60)
            max_retries: Max retry attempts (default: 3)
            **kwargs: Additional configuration
        """
        # Lazy import boto3 - gives clear error if not installed
        try:
            import boto3
            from botocore.config import Config as BotoConfig
        except ImportError:
            raise ImportError(
                "boto3 is required for Bedrock. "
                "Install with: pip install penguin-ai-sdk[bedrock]"
            )

        region_name = region_name or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")

        super().__init__(model=model, api_key=None, **kwargs)

        # Resolve model ID using centralized registry
        self.model_id = resolve_model_id(model, "bedrock")
        self._friendly_model = model

        # Create boto3 session with timeout config
        session_kwargs = {"region_name": region_name}
        if profile_name:
            session_kwargs["profile_name"] = profile_name

        # Configure timeouts and retries
        boto_config = BotoConfig(
            read_timeout=read_timeout,
            connect_timeout=connect_timeout,
            retries={"max_attempts": max_retries, "mode": "adaptive"}
        )

        try:
            session = boto3.Session(**session_kwargs)
            self.client = session.client("bedrock-runtime", config=boto_config)
        except Exception as e:
            raise AuthenticationError(
                f"Failed to create Bedrock client: {e}",
                provider="bedrock"
            )

    @property
    def provider_name(self) -> str:
        return "bedrock"

    @property
    def capabilities(self) -> ProviderCapabilities:
        # Get capabilities from centralized model registry
        model_info = get_model(self._friendly_model)
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tool_calls=True,
            supports_vision=model_info.supports_vision if model_info else False,
            supports_thinking=model_info.supports_thinking if model_info else False,
            supports_structured_output=True,
            supports_system_message=True,
            max_context_tokens=model_info.context_window if model_info else 200000,
            max_output_tokens=model_info.max_tokens if model_info else 8192,
        )

    # ================== MESSAGE CONVERSION ==================

    def _convert_messages(self, messages: List[Message]) -> tuple:
        """
        Convert Penguin messages to Anthropic/Bedrock format.

        Returns:
            Tuple of (messages list, system string or None)
        """
        anthropic_messages = []
        system_content = None

        for msg in messages:
            if isinstance(msg, SystemMessage):
                system_content = msg.content
                continue

            if isinstance(msg, AssistantMessage):
                content = []
                # Thinking block must come FIRST when present (required for Claude extended thinking)
                if msg.thinking:
                    thinking_block = {"type": "thinking", "thinking": msg.thinking}
                    # Include signature if available in metadata (required for multi-turn with thinking)
                    # This is handled internally - users don't need to know about it
                    thinking_sig = msg.metadata.get("thinking_signature") if msg.metadata else None
                    if thinking_sig:
                        thinking_block["signature"] = thinking_sig
                    content.append(thinking_block)
                if msg.content:
                    content.append({"type": "text", "text": msg.content})
                if msg.tool_calls:
                    for tc in msg.tool_calls:
                        content.append({
                            "type": "tool_use",
                            "id": tc.call_id,
                            "name": tc.tool_name,
                            "input": tc.parameters
                        })
                anthropic_messages.append({
                    "role": "assistant",
                    "content": content if content else [{"type": "text", "text": ""}]
                })

            elif isinstance(msg, ToolMessage):
                # Tool results in Anthropic format
                anthropic_messages.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": msg.tool_call_id,
                        "content": msg.content,
                        "is_error": msg.is_error
                    }]
                })

            else:
                # User message
                anthropic_messages.append({
                    "role": "user",
                    "content": [{"type": "text", "text": msg.content or ""}]
                })

        return anthropic_messages, system_content

    def _convert_tools(
        self,
        tools: Optional[List[Dict[str, Any]]]
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Convert OpenAI-format tools to Anthropic format.

        Anthropic uses:
        {
            "name": "...",
            "description": "...",
            "input_schema": { JSON Schema with type field }
        }
        """
        if not tools:
            return None

        anthropic_tools = []
        for tool in tools:
            # Handle both flat format and nested OpenAI format
            if "type" in tool and tool["type"] == "function":
                func = tool["function"]
                schema = func.get("parameters", {})
            else:
                # Flat format (Anthropic) - schema is in "input_schema" not "parameters"
                func = tool
                schema = tool.get("input_schema") or tool.get("parameters", {})

            # Ensure schema has required 'type' field
            if "type" not in schema:
                schema = {"type": "object", **schema}

            anthropic_tools.append({
                "name": func.get("name", ""),
                "description": func.get("description", ""),
                "input_schema": schema
            })

        return anthropic_tools

    # ================== RESPONSE NORMALIZATION ==================

    def _normalize_response(self, response: Dict[str, Any]) -> ChatCompletionResult:
        """Normalize Bedrock response to standard format."""
        content = None
        tool_calls = None
        thinking = None
        thinking_signature = None  # Internal - Claude requires this for multi-turn thinking

        # Parse content blocks
        content_blocks = response.get("content", [])
        text_parts = []

        for block in content_blocks:
            block_type = block.get("type")

            if block_type == "text":
                text_parts.append(block.get("text", ""))

            elif block_type == "tool_use":
                if tool_calls is None:
                    tool_calls = []
                tool_calls.append(ToolCall(
                    call_id=block.get("id", ""),
                    tool_name=block.get("name", ""),
                    parameters=block.get("input", {})
                ))

            elif block_type == "thinking":
                thinking = block.get("thinking", "")
                # Capture signature - required for multi-turn with thinking
                thinking_signature = block.get("signature")

        content = "\n".join(text_parts) if text_parts else None

        # Parse finish reason
        stop_reason = response.get("stop_reason", "end_turn")
        finish_reason = self._map_finish_reason(stop_reason)

        # Parse usage
        usage = self._normalize_usage(response.get("usage", {}))

        # Store thinking_signature in metadata for internal use
        metadata = {}
        if thinking_signature:
            metadata["thinking_signature"] = thinking_signature

        return ChatCompletionResult(
            content=content,
            tool_calls=tool_calls,
            thinking=thinking,
            finish_reason=finish_reason,
            usage=usage,
            model=self.model_id,
            provider=self.provider_name,
            raw_response=response,
            metadata=metadata,
        )

    def _map_finish_reason(self, stop_reason: str) -> FinishReason:
        """Map Anthropic stop reason to standard format."""
        mapping = {
            "end_turn": FinishReason.STOP,
            "stop_sequence": FinishReason.STOP,
            "max_tokens": FinishReason.LENGTH,
            "tool_use": FinishReason.TOOL_CALLS,
        }
        return mapping.get(stop_reason, FinishReason.STOP)

    def _normalize_usage(self, usage: Dict[str, Any]) -> TokenUsage:
        """Normalize Anthropic usage to standard format."""
        return TokenUsage(
            prompt_tokens=usage.get("input_tokens", 0),
            completion_tokens=usage.get("output_tokens", 0),
            total_tokens=usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
            cached_tokens=usage.get("cache_read_input_tokens"),
        )

    def _extract_and_parse_json(self, content: str) -> Optional[Dict[str, Any]]:
        """
        Extract and parse JSON from LLM response content.

        Handles:
        - Plain JSON
        - JSON wrapped in markdown code blocks (```json ... ```)
        - Malformed JSON (using json_repair if available)

        Args:
            content: Raw content from LLM response

        Returns:
            Parsed JSON dict if successful, None otherwise
        """
        if not content:
            return None

        # Step 1: Try to extract JSON from markdown code blocks
        # Matches ```json ... ``` or ``` ... ```
        code_block_pattern = r"```(?:json)?\s*([\s\S]*?)```"
        matches = re.findall(code_block_pattern, content, re.IGNORECASE)

        # Use the first code block if found, otherwise use original content
        json_str = matches[0].strip() if matches else content.strip()

        # Step 2: Try direct JSON parsing
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            pass

        # Step 3: Try json_repair if available
        if HAS_JSON_REPAIR:
            try:
                repaired = repair_json(json_str, return_objects=True)
                if isinstance(repaired, dict):
                    return repaired
            except Exception:
                pass

        # Step 4: Try to find JSON object in the string (fallback)
        # Look for content between first { and last }
        try:
            start_idx = json_str.find('{')
            end_idx = json_str.rfind('}')
            if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
                potential_json = json_str[start_idx:end_idx + 1]
                return json.loads(potential_json)
        except json.JSONDecodeError:
            pass

        # Step 5: Try json_repair on extracted portion
        if HAS_JSON_REPAIR:
            try:
                start_idx = json_str.find('{')
                end_idx = json_str.rfind('}')
                if start_idx != -1 and end_idx != -1:
                    potential_json = json_str[start_idx:end_idx + 1]
                    repaired = repair_json(potential_json, return_objects=True)
                    if isinstance(repaired, dict):
                        return repaired
            except Exception:
                pass

        return None

    # ================== API CALLS ==================

    async def _create_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        thinking: bool = False,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Execute Bedrock Claude API call (implementation).

        Args:
            messages: Conversation messages
            tools: Tool definitions
            output_format: Pydantic model for structured output
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            thinking: Enable extended thinking (Claude 3.5+)
            **kwargs: Additional parameters
        """
        anthropic_messages, system_content = self._convert_messages(messages)

        # Build request body
        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "messages": anthropic_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        if system_content:
            request_body["system"] = system_content

        # Tools
        converted_tools = self._convert_tools(tools)
        if converted_tools:
            request_body["tools"] = converted_tools

        # Extended thinking
        if thinking and self.capabilities.supports_thinking:
            # budget_tokens must be >= 1024 and less than max_tokens
            # Use 80% of max_tokens for thinking, with min 1024 and max 10000
            thinking_budget = max(1024, min(int(max_tokens * 0.8), 10000))
            # Ensure max_tokens is at least thinking_budget + some buffer for response
            if max_tokens < thinking_budget + 500:
                max_tokens = thinking_budget + 1000
                request_body["max_tokens"] = max_tokens
            request_body["thinking"] = {
                "type": "enabled",
                "budget_tokens": thinking_budget
            }
            # Claude requires temperature=1 when thinking is enabled
            request_body["temperature"] = 1

        # Structured output via system prompt (supports both Pydantic models and raw schema dicts)
        if output_format:
            schema, _ = self._normalize_schema(output_format)
            schema_prompt = f"\n\nRespond with valid JSON matching this schema:\n{json.dumps(schema, indent=2)}"
            if system_content:
                request_body["system"] = system_content + schema_prompt
            else:
                request_body["system"] = schema_prompt

        # Run sync boto3 call in executor
        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(
                None,
                lambda: self.client.invoke_model(
                    modelId=self.model_id,
                    body=json.dumps(request_body),
                    contentType="application/json",
                    accept="application/json"
                )
            )

            response_body = json.loads(response["body"].read())
            result = self._normalize_response(response_body)

            # Parse structured output if requested
            if output_format and result.content:
                parsed = self._extract_and_parse_json(result.content)
                if parsed is not None:
                    result.content = parsed

            return result

        except self.client.exceptions.ThrottlingException as e:
            raise RateLimitError(
                message=str(e),
                provider=self.provider_name
            )
        except self.client.exceptions.ValidationException as e:
            raise InvalidRequestError(
                message=str(e),
                provider=self.provider_name
            )
        except Exception as e:
            raise ChatCompletionError(
                message=str(e),
                provider=self.provider_name
            )

    async def _create_stream_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        thinking: bool = False,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Execute streaming Bedrock Claude API call (implementation).

        Yields ChatCompletionChunk objects with incremental content.
        """
        anthropic_messages, system_content = self._convert_messages(messages)

        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "messages": anthropic_messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        if system_content:
            request_body["system"] = system_content

        converted_tools = self._convert_tools(tools)
        if converted_tools:
            request_body["tools"] = converted_tools

        # Extended thinking
        if thinking and self.capabilities.supports_thinking:
            # budget_tokens must be >= 1024 and less than max_tokens
            # Use 80% of max_tokens for thinking, with min 1024 and max 10000
            thinking_budget = max(1024, min(int(max_tokens * 0.8), 10000))
            # Ensure max_tokens is at least thinking_budget + some buffer for response
            if max_tokens < thinking_budget + 500:
                max_tokens = thinking_budget + 1000
                request_body["max_tokens"] = max_tokens
            request_body["thinking"] = {
                "type": "enabled",
                "budget_tokens": thinking_budget
            }
            # Claude requires temperature=1 when thinking is enabled
            request_body["temperature"] = 1

        loop = asyncio.get_event_loop()

        try:
            # Use streaming endpoint
            response = await loop.run_in_executor(
                None,
                lambda: self.client.invoke_model_with_response_stream(
                    modelId=self.model_id,
                    body=json.dumps(request_body),
                    contentType="application/json",
                    accept="application/json"
                )
            )

            chunk_index = 0
            accumulated_tool_calls: Dict[int, Dict[str, Any]] = {}
            current_tool_index = 0
            in_thinking_block = False

            # Process streaming response
            for event in response["body"]:
                if "chunk" in event:
                    chunk_data = json.loads(event["chunk"]["bytes"])
                    event_type = chunk_data.get("type")

                    delta_content = None
                    delta_tool_calls = None
                    delta_thinking = None
                    finish_reason = None
                    usage = None

                    if event_type == "content_block_delta":
                        delta = chunk_data.get("delta", {})
                        delta_type = delta.get("type")

                        if delta_type == "text_delta":
                            delta_content = delta.get("text", "")

                        elif delta_type == "thinking_delta":
                            # Extended thinking content
                            delta_thinking = delta.get("thinking", "")

                        elif delta_type == "input_json_delta":
                            # Tool input streaming
                            if current_tool_index not in accumulated_tool_calls:
                                accumulated_tool_calls[current_tool_index] = {
                                    "id": "",
                                    "name": "",
                                    "input": ""
                                }
                            accumulated_tool_calls[current_tool_index]["input"] += delta.get("partial_json", "")

                    elif event_type == "content_block_start":
                        block = chunk_data.get("content_block", {})
                        if block.get("type") == "tool_use":
                            accumulated_tool_calls[current_tool_index] = {
                                "id": block.get("id", ""),
                                "name": block.get("name", ""),
                                "input": ""
                            }

                    elif event_type == "content_block_stop":
                        current_tool_index += 1

                    elif event_type == "message_delta":
                        delta = chunk_data.get("delta", {})
                        stop_reason = delta.get("stop_reason")

                        if stop_reason:
                            finish_reason = self._map_finish_reason(stop_reason)

                            # Emit complete tool calls
                            if finish_reason == FinishReason.TOOL_CALLS and accumulated_tool_calls:
                                delta_tool_calls = []
                                for tc_data in accumulated_tool_calls.values():
                                    try:
                                        params = json.loads(tc_data["input"]) if tc_data["input"] else {}
                                    except json.JSONDecodeError:
                                        params = {"raw": tc_data["input"]}

                                    delta_tool_calls.append(ToolCall(
                                        call_id=tc_data["id"],
                                        tool_name=tc_data["name"],
                                        parameters=params
                                    ))

                        # Usage in final delta
                        usage_data = delta.get("usage", {})
                        if usage_data:
                            usage = TokenUsage(
                                prompt_tokens=usage_data.get("input_tokens", 0),
                                completion_tokens=usage_data.get("output_tokens", 0),
                                total_tokens=(
                                    usage_data.get("input_tokens", 0) +
                                    usage_data.get("output_tokens", 0)
                                ),
                            )

                    elif event_type == "message_stop":
                        # Final message
                        if finish_reason is None:
                            finish_reason = FinishReason.STOP

                    yield ChatCompletionChunk(
                        delta_content=delta_content,
                        delta_tool_calls=delta_tool_calls,
                        delta_thinking=delta_thinking,
                        finish_reason=finish_reason,
                        usage=usage,
                        model=self.model_id,
                        provider=self.provider_name,
                        chunk_index=chunk_index,
                    )
                    chunk_index += 1

        except self.client.exceptions.ThrottlingException as e:
            raise RateLimitError(
                message=str(e),
                provider=self.provider_name
            )
        except Exception as e:
            raise ChatCompletionError(
                message=str(e),
                provider=self.provider_name
            )


# Backward compatibility alias
BedrockLLMProvider = BedrockClaudeChatClient
