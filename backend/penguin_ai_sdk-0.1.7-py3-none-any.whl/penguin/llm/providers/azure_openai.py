"""
Penguin Azure OpenAI LLM Provider

Azure OpenAI implementation using the Azure-specific client.
"""

import json
import os
from typing import Any, AsyncGenerator, Dict, List, Optional, Type

from openai import AsyncAzureOpenAI
from pydantic import BaseModel

from ..base import (
    BaseChatCompletionClient,
    ChatCompletionError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
    ContentFilterError,
)
from ..messages import (
    Message,
    ToolCall,
)
from ..types import (
    ChatCompletionResult,
    ChatCompletionChunk,
    TokenUsage,
    ProviderCapabilities,
    FinishReason,
)
from ..models import get_model


class AzureOpenAIChatClient(BaseChatCompletionClient):
    """
    Azure OpenAI chat completion client.

    Uses Azure-specific endpoints and authentication.

    Environment Variables:
        AZURE_OPENAI_API_KEY: Azure subscription key
        AZURE_OPENAI_ENDPOINT: Azure endpoint URL
        AZURE_OPENAI_DEPLOYMENT: Deployment name (used as model)
        AZURE_OPENAI_API_VERSION: API version (default: 2024-12-01-preview)

    Example:
        >>> client = AzureOpenAIChatClient(
        ...     deployment="gpt-4o",
        ...     azure_endpoint="https://your-resource.openai.azure.com/",
        ...     api_key="your-key"
        ... )
    """

    def __init__(
        self,
        model: Optional[str] = None,
        deployment: Optional[str] = None,
        api_key: Optional[str] = None,
        azure_endpoint: Optional[str] = None,
        api_version: Optional[str] = None,
        **kwargs: Any
    ):
        """
        Initialize Azure OpenAI client.

        Args:
            model: Model identifier from registry (e.g., "azure-gpt-4o")
            deployment: Azure deployment name (overrides model's api_id)
            api_key: API key (falls back to AZURE_OPENAI_API_KEY env var)
            azure_endpoint: Azure endpoint URL (falls back to AZURE_OPENAI_ENDPOINT)
            api_version: API version (falls back to AZURE_OPENAI_API_VERSION or default)
            **kwargs: Additional configuration
        """
        # Get credentials from env vars if not provided
        api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
        azure_endpoint = azure_endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
        api_version = api_version or os.environ.get(
            "AZURE_OPENAI_API_VERSION", "2024-12-01-preview"
        )

        if not api_key:
            raise AuthenticationError(
                "AZURE_OPENAI_API_KEY environment variable is required",
                provider="azure_openai"
            )
        if not azure_endpoint:
            raise AuthenticationError(
                "AZURE_OPENAI_ENDPOINT environment variable is required",
                provider="azure_openai"
            )

        # Determine deployment name
        # Priority: deployment param > AZURE_OPENAI_DEPLOYMENT env > model's api_id
        self.deployment = deployment or os.environ.get("AZURE_OPENAI_DEPLOYMENT")

        if not self.deployment:
            # Try to get from model registry
            if model:
                model_info = get_model(model)
                if model_info:
                    self.deployment = model_info.api_id
            if not self.deployment:
                raise InvalidRequestError(
                    "Deployment name required. Set AZURE_OPENAI_DEPLOYMENT env var, "
                    "pass deployment parameter, or use a model from the registry.",
                    provider="azure_openai"
                )

        # Use deployment as the model identifier for the base class
        super().__init__(model=model or f"azure-{self.deployment}", api_key=api_key, **kwargs)

        self.client = AsyncAzureOpenAI(
            api_key=api_key,
            azure_endpoint=azure_endpoint,
            api_version=api_version,
        )

    @property
    def provider_name(self) -> str:
        return "azure_openai"

    @property
    def capabilities(self) -> ProviderCapabilities:
        model_info = get_model(self.model)
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tool_calls=True,
            supports_vision=model_info.supports_vision if model_info else True,
            supports_thinking=model_info.supports_thinking if model_info else False,
            supports_structured_output=True,
            supports_system_message=True,
            max_context_tokens=model_info.context_window if model_info else 128000,
            max_output_tokens=model_info.max_tokens if model_info else 16384,
        )

    def _convert_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """Convert Penguin messages to OpenAI format."""
        return self._convert_messages_to_openai_format(messages)

    def _convert_tools(
        self,
        tools: Optional[List[Dict[str, Any]]]
    ) -> Optional[List[Dict[str, Any]]]:
        """Convert tools to OpenAI format."""
        if not tools:
            return None

        openai_tools = []
        for tool in tools:
            if "type" in tool and tool["type"] == "function":
                openai_tools.append(tool)
            else:
                schema = tool.get("input_schema") or tool.get("parameters", {})
                openai_tools.append({
                    "type": "function",
                    "function": {
                        "name": tool.get("name", ""),
                        "description": tool.get("description", ""),
                        "parameters": schema,
                    }
                })
        return openai_tools

    def _normalize_response(self, response: Any) -> ChatCompletionResult:
        """Normalize Azure OpenAI response to standard format."""
        choice = response.choices[0] if response.choices else None

        content = None
        tool_calls = None

        if choice and choice.message:
            msg = choice.message
            content = msg.content

            if msg.tool_calls:
                tool_calls = []
                for tc in msg.tool_calls:
                    try:
                        params = json.loads(tc.function.arguments) if tc.function.arguments else {}
                    except json.JSONDecodeError:
                        params = {"raw": tc.function.arguments}

                    tool_calls.append(ToolCall(
                        call_id=tc.id,
                        tool_name=tc.function.name,
                        parameters=params
                    ))

        finish_reason = self._map_finish_reason(choice)
        usage = self._normalize_usage(response.usage)

        return ChatCompletionResult(
            content=content,
            tool_calls=tool_calls,
            thinking=None,
            finish_reason=finish_reason,
            usage=usage,
            model=response.model,
            provider=self.provider_name,
            raw_response=response,
        )

    def _map_finish_reason(self, choice: Any) -> FinishReason:
        """Map OpenAI finish reason to standard format."""
        if not choice:
            return FinishReason.ERROR

        reason = getattr(choice, 'finish_reason', None)
        if reason:
            mapping = {
                "stop": FinishReason.STOP,
                "length": FinishReason.LENGTH,
                "tool_calls": FinishReason.TOOL_CALLS,
                "content_filter": FinishReason.CONTENT_FILTER,
            }
            return mapping.get(reason, FinishReason.STOP)
        return FinishReason.STOP

    def _normalize_usage(self, usage: Any) -> TokenUsage:
        """Normalize usage to standard format."""
        if not usage:
            return TokenUsage()
        return TokenUsage(
            prompt_tokens=getattr(usage, 'prompt_tokens', 0) or 0,
            completion_tokens=getattr(usage, 'completion_tokens', 0) or 0,
            total_tokens=getattr(usage, 'total_tokens', 0) or 0,
        )

    async def _create_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Execute Azure OpenAI API call (implementation).

        Args:
            messages: Conversation messages
            tools: Tool definitions
            output_format: Pydantic model for structured output
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            **kwargs: Additional parameters
        """
        api_messages = self._convert_messages(messages)

        request_params = {
            "model": self.deployment,  # Azure uses deployment name
            "messages": api_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if "seed" in kwargs:
            request_params["seed"] = kwargs["seed"]
        if "top_p" in kwargs:
            request_params["top_p"] = kwargs["top_p"]

        converted_tools = self._convert_tools(tools)
        if converted_tools:
            request_params["tools"] = converted_tools

        if output_format:
            schema, schema_name = self._normalize_schema(output_format)
            # Azure OpenAI strict mode requires additionalProperties: false
            self._add_additional_properties_false(schema)
            request_params["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": schema_name,
                    "schema": schema,
                    "strict": True,
                }
            }

        try:
            response = await self.client.chat.completions.create(**request_params)
            result = self._normalize_response(response)

            if output_format and result.content:
                try:
                    parsed = json.loads(result.content)
                    result.content = parsed
                except json.JSONDecodeError:
                    pass

            return result

        except Exception as e:
            self._handle_error(e)

    async def _create_stream_impl(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[Type[BaseModel]] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """Execute streaming Azure OpenAI API call (implementation)."""
        api_messages = self._convert_messages(messages)

        request_params = {
            "model": self.deployment,
            "messages": api_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }

        if "seed" in kwargs:
            request_params["seed"] = kwargs["seed"]

        converted_tools = self._convert_tools(tools)
        if converted_tools:
            request_params["tools"] = converted_tools

        try:
            stream = await self.client.chat.completions.create(**request_params)

            chunk_index = 0
            accumulated_tool_calls: Dict[int, Dict[str, Any]] = {}

            async for chunk in stream:
                delta_content = None
                delta_tool_calls = None
                finish_reason = None
                usage = None

                if chunk.choices:
                    choice = chunk.choices[0]
                    delta = choice.delta

                    if delta and delta.content:
                        delta_content = delta.content

                    if delta and delta.tool_calls:
                        for tc_delta in delta.tool_calls:
                            idx = tc_delta.index
                            if idx not in accumulated_tool_calls:
                                accumulated_tool_calls[idx] = {
                                    "id": "",
                                    "name": "",
                                    "arguments": ""
                                }

                            if tc_delta.id:
                                accumulated_tool_calls[idx]["id"] = tc_delta.id
                            if tc_delta.function:
                                if tc_delta.function.name:
                                    accumulated_tool_calls[idx]["name"] = tc_delta.function.name
                                if tc_delta.function.arguments:
                                    accumulated_tool_calls[idx]["arguments"] += tc_delta.function.arguments

                    if choice.finish_reason:
                        finish_reason = self._map_finish_reason(choice)

                        if finish_reason == FinishReason.TOOL_CALLS and accumulated_tool_calls:
                            delta_tool_calls = []
                            for tc_data in accumulated_tool_calls.values():
                                try:
                                    params = json.loads(tc_data["arguments"]) if tc_data["arguments"] else {}
                                except json.JSONDecodeError:
                                    params = {"raw": tc_data["arguments"]}

                                delta_tool_calls.append(ToolCall(
                                    call_id=tc_data["id"],
                                    tool_name=tc_data["name"],
                                    parameters=params
                                ))

                if chunk.usage:
                    usage = TokenUsage(
                        prompt_tokens=chunk.usage.prompt_tokens or 0,
                        completion_tokens=chunk.usage.completion_tokens or 0,
                        total_tokens=chunk.usage.total_tokens or 0,
                    )

                yield ChatCompletionChunk(
                    delta_content=delta_content,
                    delta_tool_calls=delta_tool_calls,
                    delta_thinking=None,
                    finish_reason=finish_reason,
                    usage=usage,
                    model=self.model,
                    provider=self.provider_name,
                    chunk_index=chunk_index,
                )
                chunk_index += 1

        except Exception as e:
            self._handle_error(e)

    def _handle_error(self, e: Exception) -> None:
        """Handle Azure OpenAI API errors."""
        from openai import (
            APIError,
            RateLimitError as OpenAIRateLimitError,
            AuthenticationError as OpenAIAuthError,
            BadRequestError,
        )

        error_msg = str(e)

        if isinstance(e, OpenAIRateLimitError):
            raise RateLimitError(
                message=error_msg,
                provider=self.provider_name
            )
        elif isinstance(e, OpenAIAuthError):
            raise AuthenticationError(
                message=error_msg,
                provider=self.provider_name
            )
        elif isinstance(e, BadRequestError):
            if "content_filter" in error_msg.lower():
                raise ContentFilterError(
                    message=error_msg,
                    provider=self.provider_name
                )
            raise InvalidRequestError(
                message=error_msg,
                provider=self.provider_name
            )
        elif isinstance(e, APIError):
            raise ChatCompletionError(
                message=error_msg,
                provider=self.provider_name,
                status_code=getattr(e, 'status_code', None)
            )
        else:
            raise ChatCompletionError(
                message=error_msg,
                provider=self.provider_name
            )
