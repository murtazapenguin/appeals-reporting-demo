"""
Penguin LLM Session Module

Manages multi-turn conversations with LLM providers.
"""

import uuid
import json
import logging
from datetime import datetime
from typing import Any, AsyncGenerator, Dict, List, Optional, Type, Union

from pydantic import BaseModel

from .base import BaseChatCompletionClient
from .messages import (
    Message,
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolMessage,
    ToolCall,
)
from .types import ChatCompletionResult, ChatCompletionChunk

# Type alias for tools parameter - can be ToolExecutor, list of tools, or raw dicts
ToolsInput = Any  # Will be Union[ToolExecutor, List[BaseTool], List[Dict], None] at runtime

logger = logging.getLogger("penguin.llm.session")


class ChatSession:
    """
    Manages multi-turn conversations with any LLM provider.

    Features:
    - Automatic conversation history management
    - Extended thinking support (for models that support it)
    - Streaming response support
    - Tool call handling
    - Session metadata tracking

    Example:
        ```python
        from penguin.llm import create_client, ChatSession

        client = create_client("gemini", model="gemini-2.0-flash")
        session = ChatSession(client, system_instruction="You are helpful.")

        # Multi-turn conversation
        response1 = await session.send("What is Python?")
        response2 = await session.send("Give me an example.")

        # Access history
        print(len(session.history))  # 4 messages
        ```
    """

    def __init__(
        self,
        client: BaseChatCompletionClient,
        system_instruction: Optional[str] = None,
        session_id: Optional[str] = None,
    ):
        """
        Initialize a chat session.

        Args:
            client: LLM client to use for API calls
            system_instruction: Optional system prompt for the conversation
            session_id: Optional custom session ID (auto-generated if not provided)
        """
        self.session_id = session_id or str(uuid.uuid4())
        self.client = client
        self.system_instruction = system_instruction
        self.history: List[Message] = []
        self.created_at = datetime.utcnow()
        self.metadata: Dict[str, Any] = {
            "model": client.model,
            "provider": client.provider_name,
        }

        logger.info(f"Started new ChatSession: {self.session_id}")

    @property
    def model(self) -> str:
        """Get the model being used."""
        return self.client.model

    @property
    def provider(self) -> str:
        """Get the provider name."""
        return self.client.provider_name

    @property
    def message_count(self) -> int:
        """Get the number of messages in history."""
        return len(self.history)

    async def send(
        self,
        content: str,
        tools: Optional[ToolsInput] = None,
        output_format: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Send a message and get a response, updating history automatically.

        Args:
            content: The user message to send
            tools: Optional tools for function calling. Can be:
                   - ToolExecutor: Automatically converted to provider format
                   - List[BaseTool]: List of tool objects, auto-converted
                   - List[Dict]: Raw provider format (backwards compatible)
            output_format: Optional Pydantic model or JSON schema for structured output
            **kwargs: Additional arguments passed to client.create()
                      (e.g., temperature, max_tokens, thinking=True)

        Returns:
            ChatCompletionResult with the assistant's response

        Example:
            ```python
            # Simple message
            response = await session.send("Hello!")

            # With tools (ToolExecutor - recommended)
            executor = ToolExecutor([get_weather, calculate])
            response = await session.send("What's the weather?", tools=executor)

            # With tools (list of tools)
            response = await session.send("What's the weather?", tools=[get_weather])

            # With structured output
            response = await session.send(
                "Extract the person's name",
                output_format=PersonInfo
            )

            # With extended thinking
            response = await session.send(
                "Solve this step by step",
                thinking=True
            )
            ```
        """
        # Build messages including history
        messages = self._build_messages(content)

        # Convert tools to provider format if needed
        tools_for_provider = self._convert_tools(tools)

        # Make API call
        result = await self.client.create(
            messages=messages,
            tools=tools_for_provider,
            output_format=output_format,
            **kwargs,
        )

        # Update history with user message and assistant response
        self._append_user_message(content)
        self._append_assistant_response(result)

        return result

    async def send_stream(
        self,
        content: str,
        tools: Optional[ToolsInput] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Send a message and stream the response, updating history after completion.

        Args:
            content: The user message to send
            tools: Optional tools for function calling (ToolExecutor, List[BaseTool], or List[Dict])
            **kwargs: Additional arguments passed to client.create_stream()

        Yields:
            ChatCompletionChunk objects as they arrive

        Example:
            ```python
            async for chunk in session.send_stream("Tell me a story"):
                print(chunk.delta_content, end="", flush=True)
            ```
        """
        # Build messages including history
        messages = self._build_messages(content)

        # Convert tools to provider format if needed
        tools_for_provider = self._convert_tools(tools)

        # Append user message before streaming starts
        self._append_user_message(content)

        # Track accumulated content for history
        full_content: List[str] = []
        thinking_content: List[str] = []
        tool_calls: List[ToolCall] = []

        # Stream the response
        async for chunk in self.client.create_stream(
            messages=messages,
            tools=tools_for_provider,
            **kwargs,
        ):
            # Accumulate content
            if chunk.delta_content:
                full_content.append(chunk.delta_content)
            if chunk.delta_thinking:
                thinking_content.append(chunk.delta_thinking)
            if chunk.delta_tool_calls:
                tool_calls.extend(chunk.delta_tool_calls)

            yield chunk

        # After stream completes, update history
        self._append_assistant_response_from_stream(
            content="".join(full_content) if full_content else None,
            thinking="".join(thinking_content) if thinking_content else None,
            tool_calls=tool_calls if tool_calls else None,
        )

    def add_tool_result(
        self,
        tool_call_id: str,
        tool_name: str,
        result: Any,
        is_error: bool = False,
    ) -> None:
        """
        Add a tool execution result to the conversation history.

        Call this after executing a tool that was requested by the assistant.

        Args:
            tool_call_id: The ID of the tool call being responded to
            tool_name: The name of the tool that was executed
            result: The result from the tool (will be JSON-serialized if not a string)
            is_error: Whether the result represents an error

        Example:
            ```python
            response = await session.send("What's the weather?", tools=[weather_tool])

            if response.has_tool_calls:
                for tc in response.tool_calls:
                    result = execute_tool(tc.tool_name, tc.parameters)
                    session.add_tool_result(tc.call_id, tc.tool_name, result)

                # Continue conversation with tool results
                final = await session.send("")
            ```
        """
        # Serialize result if needed
        if isinstance(result, str):
            content = result
        else:
            try:
                content = json.dumps(result)
            except (TypeError, ValueError):
                content = str(result)

        self.history.append(
            ToolMessage(
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                content=content,
                is_error=is_error,
            )
        )

    def add_message(self, message: Message) -> None:
        """
        Manually add a message to the conversation history.

        Args:
            message: The message to add (UserMessage, AssistantMessage, etc.)
        """
        self.history.append(message)

    def clear_history(self) -> None:
        """Clear the conversation history."""
        self.history.clear()
        logger.debug(f"Cleared history for session {self.session_id}")

    def get_history(self) -> List[Dict[str, Any]]:
        """
        Get the conversation history as a list of dictionaries.

        Returns:
            List of message dictionaries
        """
        return [msg.model_dump() for msg in self.history]

    def get_last_assistant_message(self) -> Optional[AssistantMessage]:
        """
        Get the most recent assistant message from history.

        Returns:
            The last AssistantMessage, or None if no assistant messages exist
        """
        for msg in reversed(self.history):
            if isinstance(msg, AssistantMessage):
                return msg
        return None

    def _build_messages(self, user_content: str) -> List[Message]:
        """
        Build the complete message list for an API call.

        Combines system instruction, history, and the new user message.

        Args:
            user_content: The new user message content

        Returns:
            Complete list of messages for the API call
        """
        messages: List[Message] = []

        # Add system instruction if present
        if self.system_instruction:
            messages.append(SystemMessage(self.system_instruction))

        # Add conversation history
        messages.extend(self.history)

        # Add the new user message
        messages.append(UserMessage(user_content))

        return messages

    def _convert_tools(self, tools: Optional[ToolsInput]) -> Optional[List[Dict[str, Any]]]:
        """
        Convert tools to provider format.

        Accepts:
        - None: Returns None
        - ToolExecutor: Calls to_provider_format() with current provider
        - List[BaseTool]: Converts each tool to provider format
        - List[Dict]: Returns as-is (already in provider format)

        Args:
            tools: Tools in any supported format

        Returns:
            Tools in provider-specific format, or None
        """
        if tools is None:
            return None

        # Import here to avoid circular imports
        from ..tools.executor import ToolExecutor
        from ..tools.base import BaseTool

        # Handle ToolExecutor
        if isinstance(tools, ToolExecutor):
            return tools.to_provider_format(self.client.provider_name)

        # Handle list
        if isinstance(tools, list) and len(tools) > 0:
            # Check if it's a list of BaseTool objects
            if isinstance(tools[0], BaseTool):
                # Create temporary executor to convert
                temp_executor = ToolExecutor(tools)
                return temp_executor.to_provider_format(self.client.provider_name)
            # Otherwise assume it's already in provider format (List[Dict])
            return tools

        return None

    def _append_user_message(self, content: str) -> None:
        """Append a user message to history."""
        self.history.append(UserMessage(content))

    def _append_assistant_response(self, result: ChatCompletionResult) -> None:
        """Append an assistant response to history from a ChatCompletionResult."""
        self.history.append(
            AssistantMessage(
                content=result.text if result.content else None,
                tool_calls=result.tool_calls,
                thinking=result.thinking,
            )
        )

    def _append_assistant_response_from_stream(
        self,
        content: Optional[str] = None,
        thinking: Optional[str] = None,
        tool_calls: Optional[List[ToolCall]] = None,
    ) -> None:
        """Append an assistant response to history from accumulated stream data."""
        self.history.append(
            AssistantMessage(
                content=content,
                tool_calls=tool_calls,
                thinking=thinking,
            )
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize the session to a dictionary.

        Useful for persistence.

        Returns:
            Dictionary representation of the session
        """
        return {
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
            "system_instruction": self.system_instruction,
            "model": self.model,
            "provider": self.provider,
            "history": self.get_history(),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(
        cls,
        data: Dict[str, Any],
        client: BaseChatCompletionClient,
    ) -> "ChatSession":
        """
        Restore a session from a dictionary.

        Args:
            data: Dictionary from to_dict()
            client: LLM client to use for future API calls

        Returns:
            Restored ChatSession instance
        """
        session = cls(
            client=client,
            system_instruction=data.get("system_instruction"),
            session_id=data.get("session_id"),
        )

        # Restore created_at
        if "created_at" in data:
            session.created_at = datetime.fromisoformat(data["created_at"])

        # Restore history
        for msg_data in data.get("history", []):
            role = msg_data.get("role")
            if role == "user":
                session.history.append(UserMessage(msg_data.get("content", "")))
            elif role == "assistant":
                # Convert tool_calls dicts back to ToolCall objects
                tool_calls_data = msg_data.get("tool_calls")
                tool_calls = None
                if tool_calls_data:
                    tool_calls = [
                        ToolCall(
                            call_id=tc.get("call_id", ""),
                            tool_name=tc.get("tool_name", ""),
                            parameters=tc.get("parameters", {})
                        )
                        for tc in tool_calls_data
                    ]
                session.history.append(
                    AssistantMessage(
                        content=msg_data.get("content"),
                        tool_calls=tool_calls,
                        thinking=msg_data.get("thinking"),
                    )
                )
            elif role == "tool":
                session.history.append(
                    ToolMessage(
                        tool_call_id=msg_data.get("tool_call_id", ""),
                        tool_name=msg_data.get("tool_name", ""),
                        content=msg_data.get("content", ""),
                        is_error=msg_data.get("is_error", False),
                    )
                )
            elif role == "system":
                # System messages are handled via system_instruction
                pass

        # Restore metadata
        session.metadata = data.get("metadata", {})

        return session

    def __repr__(self) -> str:
        return (
            f"ChatSession(id={self.session_id[:8]}..., "
            f"model={self.model}, messages={len(self.history)})"
        )
