# START OF FILE: penguin/llm/schema.py ---
import json
import logging
from typing import Any, Dict, Optional, Union
from .base import BaseChatCompletionClient
from .messages import UserMessage

logger = logging.getLogger("penguin.llm.schema")

class SmartSchemaGenerator:
    def __init__(self, llm_provider: Optional[BaseChatCompletionClient] = None):
        self.llm = llm_provider

    def _generate_deterministic_schema(self, sample: Any) -> Dict[str, Any]:
        """The standard recursive logic for valid Python structures."""
        if isinstance(sample, bool): return {"type": "BOOLEAN"}
        if isinstance(sample, int) and not isinstance(sample, bool): return {"type": "INTEGER"}
        if isinstance(sample, float): return {"type": "NUMBER"}
        if isinstance(sample, str): return {"type": "STRING"}
        
        if isinstance(sample, list):
            items_schema = self._generate_deterministic_schema(sample[0]) if sample else {"type": "STRING"}
            return {"type": "ARRAY", "items": items_schema}
        
        if isinstance(sample, dict):
            properties = {k: self._generate_deterministic_schema(v) for k, v in sample.items()}
            return {
                "type": "OBJECT",
                "properties": properties,
                "required": list(properties.keys())
            }
        return {"type": "STRING"}

    async def get_schema(self, user_input: Union[str, Dict[str, Any]]) -> Dict[str, Any]:
        """
        Main entry point. Automatically decides between code-based parsing 
        and LLM-based inference.
        """
        # --- PHASE 1: Try Deterministic Parsing ---
        try:
            # If it's a string, try to load it as JSON first
            if isinstance(user_input, str):
                sample_data = json.loads(user_input)
            else:
                sample_data = user_input
            
            logger.info("Deterministic schema generation successful.")
            return self._generate_deterministic_schema(sample_data)
        
        except Exception as e:
            logger.warning(f"Deterministic parsing failed, falling back to LLM inference: {e}")
            if not self.llm:
                raise ValueError("LLM provider required for schema inference fallback.")
            
            return await self._infer_from_llm(user_input)

    async def _infer_from_llm(self, messy_input: str) -> Dict[str, Any]:
        """Uses Gemini to architect a valid schema from broken or descriptive input."""
        prompt = f"""
        TASK: Convert the following 'User Input' into a strict Google Gemini JSON Schema.
        
        USER INPUT:
        {messy_input}

        RULES:
        1. The input might be BROKEN JSON (missing commas, quotes) or a TEXTUAL DESCRIPTION.
        2. Analyze the INTENT. If they mention "rank" is a number, use INTEGER. If "is_active" is true, use BOOLEAN.
        3. Output ONLY a valid JSON Schema object compatible with OpenAPI 3.0 / Gemini `response_schema`.
        4. Do NOT include markdown code blocks. Just the raw JSON.
        5. Include 'required' fields for all properties identified.

        SCHEMA FORMAT EXAMPLE:
        {{
            "type": "OBJECT",
            "properties": {{
                "field_name": {{"type": "STRING"}}
            }},
            "required": ["field_name"]
        }}
        """

        # We use a strict schema for the LLM's own response to ensure we get a valid schema back!
        # This is "Recursive Structured Output"
        schema_of_schema = {
            "type": "OBJECT",
            "properties": {
                "type": {"type": "STRING"},
                "properties": {"type": "OBJECT"},
                "required": {"type": "ARRAY", "items": {"type": "STRING"}}
            }
        }

        response = await self.llm.create(
            [UserMessage(prompt)],
            thinking=True  # Thinking helps it "fix" the broken JSON logic
        )

        return response.content

# END OF FILE: penguin/llm/schema.py ---