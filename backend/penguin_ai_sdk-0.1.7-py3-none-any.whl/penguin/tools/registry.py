"""
Penguin Tool Registry Module

Persistent tool registry that stores tools across sessions.
Supports add, delete, create, and automatic loading of persisted tools.
"""

import json
import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .base import BaseTool
from .function_tool import FunctionTool
from .executor import ToolExecutor

logger = logging.getLogger(__name__)


class ToolRegistry:
    """
    Persistent tool registry - add/delete/create tools that persist across sessions.

    Tools are stored in ~/.penguin/tools/ as JSON files.
    Dynamic tools (created from code strings) store their source code
    and are re-compiled on load.

    Features:
    - Add/delete tools with automatic persistence
    - Create tools from functions or code strings
    - Load persisted tools on initialization
    - Convert all tools to provider format
    - Get ToolExecutor for execution

    Example:
        registry = ToolRegistry()

        # Add a decorated tool
        @tool
        def calculate(expr: str) -> float:
            return eval(expr)
        registry.add(calculate)

        # Create from code string
        registry.create_from_code(
            "fetch_data",
            "Fetch data from API",
            '''
def fetch_data(url: str) -> str:
    import requests
    return requests.get(url).text
            '''
        )

        # Use with LLM
        tools = registry.to_provider_format("bedrock")
        executor = registry.get_executor()
    """

    DEFAULT_PATH = Path.home() / ".penguin" / "tools"

    def __init__(self, storage_path: Optional[Path] = None):
        """
        Initialize registry with optional custom storage path.

        Args:
            storage_path: Path to store tool definitions (default: ~/.penguin/tools/)
        """
        self.storage_path = storage_path or self.DEFAULT_PATH
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self._tools: Dict[str, BaseTool] = {}
        self._load_persisted_tools()

    # ================== CRUD Operations ==================

    def add(self, tool: BaseTool, persist: bool = True) -> None:
        """
        Add a tool to the registry.

        Args:
            tool: Tool to add
            persist: Whether to persist to disk (default: True)
        """
        self._tools[tool.name] = tool
        if persist:
            self._save_tool(tool)
        logger.info(f"Added tool: {tool.name}")

    def delete(self, name: str) -> bool:
        """
        Delete a tool from registry and disk.

        Args:
            name: Tool name to delete

        Returns:
            True if tool was found and deleted, False otherwise
        """
        if name in self._tools:
            del self._tools[name]
            tool_file = self.storage_path / f"{name}.json"
            if tool_file.exists():
                tool_file.unlink()
            logger.info(f"Deleted tool: {name}")
            return True
        return False

    def get(self, name: str) -> Optional[BaseTool]:
        """
        Get a tool by name.

        Args:
            name: Tool name

        Returns:
            Tool if found, None otherwise
        """
        return self._tools.get(name)

    def list(self) -> List[str]:
        """
        List all tool names.

        Returns:
            List of tool names
        """
        return list(self._tools.keys())

    def list_tools(self) -> List[BaseTool]:
        """
        Get all tools.

        Returns:
            List of all registered tools
        """
        return list(self._tools.values())

    def clear(self, delete_files: bool = False) -> None:
        """
        Clear all tools from registry.

        Args:
            delete_files: Also delete persisted files
        """
        if delete_files:
            for name in list(self._tools.keys()):
                tool_file = self.storage_path / f"{name}.json"
                if tool_file.exists():
                    tool_file.unlink()
        self._tools.clear()
        logger.info("Cleared all tools")

    # ================== Tool Creation ==================

    def create_from_function(
        self,
        func: Callable[..., Any],
        name: Optional[str] = None,
        description: Optional[str] = None,
        persist: bool = True
    ) -> FunctionTool:
        """
        Create and register a tool from a function.

        Note: Functions cannot be fully persisted (only metadata).
        Use create_from_code() for full persistence.

        Args:
            func: Function to wrap
            name: Override function name
            description: Override description
            persist: Whether to persist metadata

        Returns:
            Created FunctionTool
        """
        tool = FunctionTool(func, name=name, description=description)
        self.add(tool, persist=persist)
        return tool

    def create_from_code(
        self,
        name: str,
        description: str,
        code: str,
        persist: bool = True
    ) -> FunctionTool:
        """
        Create tool from Python code string.

        The code must define a function with the given name.
        The code is stored and re-compiled on load.

        Args:
            name: Function name (must match function defined in code)
            description: Tool description
            code: Python code defining the function
            persist: Whether to persist to disk

        Returns:
            Created FunctionTool

        Raises:
            ValueError: If code doesn't define the expected function
        """
        # Compile and extract function
        namespace: Dict[str, Any] = {}
        try:
            exec(code, namespace)
        except Exception as e:
            raise ValueError(f"Failed to compile code: {e}")

        func = namespace.get(name)
        if not func or not callable(func):
            raise ValueError(f"Code must define a callable function named '{name}'")

        tool = FunctionTool(func, name=name, description=description)
        self._tools[name] = tool

        # Save with source code for persistence
        if persist:
            self._save_tool_code(name, code, description)

        logger.info(f"Created tool from code: {name}")
        return tool

    # ================== Persistence ==================

    def _save_tool(self, tool: BaseTool) -> None:
        """Save tool metadata to JSON (without source code)."""
        meta = {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.parameters,
            "type": type(tool).__name__,
        }
        path = self.storage_path / f"{tool.name}.json"
        path.write_text(json.dumps(meta, indent=2))

    def _save_tool_code(self, name: str, code: str, description: str) -> None:
        """Save tool with source code (for dynamic tools)."""
        meta = {
            "name": name,
            "description": description,
            "code": code,
            "type": "DynamicTool",
        }
        path = self.storage_path / f"{name}.json"
        path.write_text(json.dumps(meta, indent=2))

    def _load_persisted_tools(self) -> None:
        """Load all persisted tools from disk."""
        for tool_file in self.storage_path.glob("*.json"):
            try:
                data = json.loads(tool_file.read_text())

                # Only load dynamic tools (those with source code)
                if data.get("type") == "DynamicTool" and "code" in data:
                    namespace: Dict[str, Any] = {}
                    exec(data["code"], namespace)
                    func = namespace.get(data["name"])
                    if func and callable(func):
                        tool = FunctionTool(
                            func,
                            name=data["name"],
                            description=data.get("description", "")
                        )
                        self._tools[tool.name] = tool
                        logger.debug(f"Loaded persisted tool: {tool.name}")

            except Exception as e:
                logger.warning(f"Failed to load tool from {tool_file}: {e}")

    # ================== LLM Integration ==================

    def to_provider_format(self, provider: str) -> List[Dict[str, Any]]:
        """
        Convert all tools to provider-specific format.

        Args:
            provider: Provider name ("openai", "gemini", "bedrock")

        Returns:
            List of tools in provider format
        """
        return [t.to_provider_format(provider) for t in self._tools.values()]

    def get_executor(self) -> ToolExecutor:
        """
        Get a ToolExecutor with all registered tools.

        Returns:
            ToolExecutor instance
        """
        return ToolExecutor(list(self._tools.values()))

    # ================== Utilities ==================

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:
        return f"<ToolRegistry path={self.storage_path} tools={list(self._tools.keys())}>"
