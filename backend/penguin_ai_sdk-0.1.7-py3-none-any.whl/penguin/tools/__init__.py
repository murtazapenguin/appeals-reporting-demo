"""
Penguin Tools Module

Provider-agnostic tool system for LLM function calling.

Features:
- @tool decorator for easy function-to-tool conversion
- Automatic JSON Schema generation from type hints
- Provider-specific format conversion (OpenAI, Gemini, Bedrock/Claude)
- Persistent tool registry for add/delete/create operations
- Async-first execution with parallel support

Quick Start:
    from penguin.tools import tool, ToolExecutor

    @tool
    def get_weather(city: str) -> str:
        '''Get weather for a city.'''
        return f"Weather in {city}: Sunny"

    # Use with any LLM provider
    executor = ToolExecutor([get_weather])
    tools = executor.to_provider_format("bedrock")

Persistent Registry:
    from penguin.tools import ToolRegistry

    registry = ToolRegistry()
    registry.add(get_weather)
    registry.create_from_code("calc", "Calculator", "def calc(x: int) -> int: return x * 2")
    print(registry.list())  # ['get_weather', 'calc']
"""

from .types import ToolResult, ToolDefinition
from .base import BaseTool
from .function_tool import FunctionTool, tool
from .executor import ToolExecutor
from .registry import ToolRegistry
from .schema import SchemaGenerator

__all__ = [
    # Types
    "ToolResult",
    "ToolDefinition",
    # Base
    "BaseTool",
    # Function Tool
    "FunctionTool",
    "tool",
    # Execution
    "ToolExecutor",
    "ToolRegistry",
    # Schema
    "SchemaGenerator",
]
