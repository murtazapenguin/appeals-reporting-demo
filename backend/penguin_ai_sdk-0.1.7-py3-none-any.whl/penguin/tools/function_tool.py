"""
Penguin FunctionTool Module

Wraps Python functions as tools with automatic schema generation.
Provides the @tool decorator for easy tool creation.
"""

import asyncio
import time
from typing import Any, Callable, Dict, Optional, Union

from .base import BaseTool
from .types import ToolResult
from .schema import SchemaGenerator


class FunctionTool(BaseTool):
    """
    Wraps a Python function as a tool with auto-generated schema.

    Features:
    - Automatic JSON Schema generation from type hints
    - Supports both sync and async functions
    - Extracts description from docstring
    - Measures execution time

    Example:
        def get_weather(city: str) -> str:
            '''Get weather for a city.'''
            return f"Weather in {city}: Sunny"

        tool = FunctionTool(get_weather)
        result = await tool.execute(city="NYC")
    """

    def __init__(
        self,
        func: Callable[..., Any],
        name: Optional[str] = None,
        description: Optional[str] = None,
    ):
        """
        Initialize FunctionTool from a Python function.

        Args:
            func: The function to wrap
            name: Override function name (defaults to func.__name__)
            description: Override description (defaults to docstring)
        """
        self._func = func
        self._name = name or func.__name__
        self._description = description or self._extract_description(func)
        self._parameters = SchemaGenerator.from_function(func)
        self._is_async = asyncio.iscoroutinefunction(func)

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def parameters(self) -> Dict[str, Any]:
        return self._parameters

    @property
    def is_async(self) -> bool:
        """Whether the wrapped function is async."""
        return self._is_async

    async def execute(self, **kwargs: Any) -> ToolResult:
        """
        Execute the wrapped function.

        Args:
            **kwargs: Parameters to pass to the function

        Returns:
            ToolResult with the function's return value or error
        """
        start = time.perf_counter()

        try:
            if self._is_async:
                result = await self._func(**kwargs)
            else:
                # Run sync function in executor to avoid blocking
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, lambda: self._func(**kwargs))

            execution_time = (time.perf_counter() - start) * 1000

            return ToolResult(
                call_id="",  # Will be filled by executor
                tool_name=self.name,
                content=result,
                success=True,
                execution_time_ms=execution_time,
            )

        except Exception as e:
            execution_time = (time.perf_counter() - start) * 1000

            return ToolResult(
                call_id="",
                tool_name=self.name,
                content=None,
                success=False,
                error=f"{type(e).__name__}: {str(e)}",
                execution_time_ms=execution_time,
            )

    def _extract_description(self, func: Callable[..., Any]) -> str:
        """Extract description from function docstring."""
        doc = func.__doc__ or ""
        # Get first paragraph (before Args:, Returns:, etc.)
        lines = []
        for line in doc.strip().split("\n"):
            stripped = line.strip()
            if stripped.lower() in ("args:", "returns:", "raises:", "yields:", "example:", "examples:"):
                break
            if stripped:
                lines.append(stripped)
            elif lines:
                # Empty line after content means end of summary
                break
        return " ".join(lines) if lines else f"Execute {func.__name__}"

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Allow calling the tool like the original function."""
        return self._func(*args, **kwargs)


def tool(
    func: Optional[Callable[..., Any]] = None,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
) -> Union[FunctionTool, Callable[[Callable[..., Any]], FunctionTool]]:
    """
    Decorator to create a tool from a function.

    Can be used with or without parentheses:

    Usage:
        @tool
        def get_weather(city: str) -> str:
            '''Get weather for a city.'''
            return f"Weather in {city}: Sunny"

        @tool(name="custom_name", description="Custom description")
        def my_func(x: int) -> int:
            return x * 2

        # Async functions work too
        @tool
        async def fetch_data(url: str) -> dict:
            '''Fetch data from URL.'''
            ...

    Args:
        func: The function to wrap (when used without parentheses)
        name: Override the function name
        description: Override the description

    Returns:
        FunctionTool instance or decorator function
    """
    def decorator(f: Callable[..., Any]) -> FunctionTool:
        return FunctionTool(f, name=name, description=description)

    # Called with parentheses: @tool() or @tool(name="...")
    if func is None:
        return decorator

    # Called without parentheses: @tool
    return decorator(func)
