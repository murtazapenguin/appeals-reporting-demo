"""
Core middleware infrastructure for Penguin.

Provides the base classes and chain execution for middleware that can
intercept and process LLM calls at both client and agent levels.

Example:
    from penguin.middleware import BaseMiddleware, MiddlewareChain, MiddlewareContext

    class MyMiddleware(BaseMiddleware):
        async def process_request(self, context):
            # Modify or validate before LLM call
            return context

        async def process_response(self, context, result):
            # Modify or validate after LLM call
            return result

    chain = MiddlewareChain()
    chain.add(MyMiddleware())
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union


@dataclass
class MiddlewareContext:
    """
    Context passed through the middleware chain.

    Contains information about the current operation and allows middleware
    to share state and metadata.

    Attributes:
        operation: Type of operation ("llm_call", "agent_iteration", "tool_call")
        messages: Current message list being processed
        metadata: Arbitrary metadata that can be modified by middleware
        client_name: Name of the LLM provider (e.g., "bedrock", "openai")
        agent_name: Name of the agent (if applicable)
        iteration: Current iteration number (for agent loops)
    """

    operation: str
    messages: List[Any]
    metadata: Dict[str, Any] = field(default_factory=dict)
    client_name: Optional[str] = None
    agent_name: Optional[str] = None
    iteration: Optional[int] = None


class BaseMiddleware(ABC):
    """
    Abstract base class for all middleware.

    Middleware intercepts LLM operations and can:
    - Validate and modify input messages before LLM call
    - Validate and modify output after LLM call
    - Block operations by raising exceptions
    - Add metadata for observability

    Subclasses must implement process_request and process_response.
    """

    @property
    def name(self) -> str:
        """Middleware name for logging and debugging."""
        return self.__class__.__name__

    @abstractmethod
    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """
        Process before LLM call.

        Called before the LLM receives the messages. Can modify the context
        or raise an exception to block the operation.

        Args:
            context: The middleware context containing messages and metadata

        Returns:
            The (potentially modified) context

        Raises:
            Any exception to block the LLM call
        """
        return context

    @abstractmethod
    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """
        Process after LLM call.

        Called after the LLM returns a response. Can modify the result
        or raise an exception to reject the response.

        Args:
            context: The middleware context (same instance from process_request)
            result: The LLM response

        Returns:
            The (potentially modified) result
        """
        return result

    async def process_error(
        self, context: MiddlewareContext, error: Exception
    ) -> None:
        """
        Handle errors from the LLM call or other middleware.

        Override this method to implement error recovery or logging.
        By default, re-raises the error.

        Args:
            context: The middleware context
            error: The exception that occurred

        Raises:
            The original error by default
        """
        raise error


class MiddlewareChain:
    """
    Executes a chain of middleware in order.

    Request processing runs middleware in order (first added runs first).
    Response processing runs middleware in reverse order (last added runs first).

    Example:
        chain = MiddlewareChain()
        chain.add(SecurityMiddleware())
        chain.add(LoggingMiddleware())

        # Request flow: SecurityMiddleware -> LoggingMiddleware -> LLM
        # Response flow: LoggingMiddleware -> SecurityMiddleware -> User
    """

    def __init__(self, middlewares: Optional[List[BaseMiddleware]] = None):
        """
        Initialize the middleware chain.

        Args:
            middlewares: Optional list of middleware to add initially
        """
        self.middlewares: List[BaseMiddleware] = list(middlewares or [])

    def add(self, middleware: Union[BaseMiddleware, List[BaseMiddleware]]) -> "MiddlewareChain":
        """
        Add middleware to the chain.

        Args:
            middleware: Single middleware instance OR list of middlewares to add

        Returns:
            Self for method chaining

        Example:
            # Single middleware
            chain.add(SecurityMiddleware())

            # List of middlewares
            chain.add([SecurityMiddleware(), LoggingMiddleware()])
        """
        if isinstance(middleware, list):
            for mw in middleware:
                self.middlewares.append(mw)
        else:
            self.middlewares.append(middleware)
        return self

    def use(self, middleware: Union[BaseMiddleware, List[BaseMiddleware]]) -> "MiddlewareChain":
        """
        Alias for add(). Add middleware to the chain.

        Args:
            middleware: Single middleware instance OR list of middlewares to add

        Returns:
            Self for method chaining
        """
        return self.add(middleware)

    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """
        Run all middleware process_request methods in order.

        Args:
            context: The initial context

        Returns:
            The processed context after all middleware

        Raises:
            Any exception raised by middleware
        """
        for mw in self.middlewares:
            context = await mw.process_request(context)
        return context

    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """
        Run all middleware process_response methods in reverse order.

        Args:
            context: The context from the request phase
            result: The LLM response

        Returns:
            The processed result after all middleware

        Raises:
            Any exception raised by middleware
        """
        for mw in reversed(self.middlewares):
            result = await mw.process_response(context, result)
        return result

    async def process_error(
        self, context: MiddlewareContext, error: Exception
    ) -> None:
        """
        Run all middleware process_error methods in reverse order.

        Args:
            context: The context from the request phase
            error: The exception that occurred

        Raises:
            The error (possibly modified by middleware)
        """
        for mw in reversed(self.middlewares):
            try:
                await mw.process_error(context, error)
            except Exception as e:
                error = e
        raise error

    def __len__(self) -> int:
        """Return the number of middleware in the chain."""
        return len(self.middlewares)

    def __bool__(self) -> bool:
        """Return True if the chain has any middleware."""
        return len(self.middlewares) > 0

    def __iter__(self):
        """Iterate over middleware in the chain."""
        return iter(self.middlewares)

    def __repr__(self) -> str:
        """String representation of the chain."""
        names = [mw.name for mw in self.middlewares]
        return f"MiddlewareChain({names})"
