"""
Security middleware for prompt injection and jailbreak prevention.

Provides real-time detection and blocking of:
- Prompt injection attempts
- Jailbreak/role manipulation
- System prompt extraction
- Delimiter injection attacks
- Unsafe output content

Example:
    from penguin.middleware import PromptInjectionMiddleware, OutputSafetyMiddleware

    # Block injection attempts
    client.use(PromptInjectionMiddleware())

    # Filter unsafe output
    client.use(OutputSafetyMiddleware())
"""

import re
from typing import Any, List, Optional, Tuple

from .base import BaseMiddleware, MiddlewareContext


class SecurityViolation(Exception):
    """
    Raised when a security check fails.

    Attributes:
        message: Human-readable description of the violation
        pattern: The regex pattern that matched (if applicable)
        category: Category of violation (e.g., "instruction_override", "role_manipulation")
        severity: Severity level ("low", "medium", "high")
    """

    def __init__(
        self,
        message: str,
        pattern: Optional[str] = None,
        category: Optional[str] = None,
        severity: str = "high",
    ):
        self.message = message
        self.pattern = pattern
        self.category = category
        self.severity = severity
        super().__init__(message)

    def __repr__(self) -> str:
        return (
            f"SecurityViolation(message={self.message!r}, "
            f"category={self.category!r}, severity={self.severity!r})"
        )


class PromptInjectionMiddleware(BaseMiddleware):
    """
    Detects and blocks prompt injection attempts.

    Scans input messages for patterns commonly used in prompt injection
    and jailbreak attacks. Can either block (raise exception) or log
    detections based on configuration.

    Default patterns detect:
    - Instruction override attempts ("ignore previous instructions")
    - Role manipulation ("pretend you are", "you are now")
    - Mode switching ("developer mode", "DAN mode")
    - System prompt extraction ("show your instructions")
    - Delimiter injection ([INST], <|im_start|>)

    Example:
        middleware = PromptInjectionMiddleware(
            block_on_detection=True,
            additional_patterns=[
                (r"my custom pattern", "custom_category"),
            ]
        )
    """

    # Default patterns - designed to catch clear injection attempts
    # while minimizing false positives on legitimate requests.
    # Use additional_patterns for stricter rules if needed.
    DEFAULT_PATTERNS: List[Tuple[str, str]] = [
        # Instruction override - explicit attempts to override system instructions
        # These patterns require clear intent to bypass instructions
        (
            r"ignore\s+(all\s+)?(your\s+)?(|original|system)\s+(instructions|prompts|rules|guidelines)",
            "instruction_override",
        ),
        (
            r"disregard\s+(all\s+)?(your\s+)?(|original|system)\s+(instructions|rules)",
            "instruction_override",
        ),
        (
            r"override\s+(all\s+)?(your|the)\s+(system\s+)?(instructions|rules|guidelines|constraints)",
            "instruction_override",
        ),

        # Role manipulation - specific jailbreak patterns only
        # Removed generic "act as" and "imagine" which are used in legitimate roleplay
        (r"you\s+are\s+now\s+(an?\s+)?(evil|unfiltered|unrestricted|uncensored)", "role_manipulation"),
        (r"pretend\s+(you\s+are|to\s+be)\s+(an?\s+)?(evil|unfiltered|unrestricted|jailbroken)", "role_manipulation"),
        (r"from\s+now\s+on,?\s+you\s+(have\s+no|don't\s+have\s+any)\s+(restrictions|limits|rules)", "role_manipulation"),

        # Mode switching - only specific jailbreak modes
        # Removed generic "enter X mode" which catches legitimate requests
        (r"\b(jailbreak|jailbroken)\s*(mode)?", "mode_switch"),
        (r"\bDAN\s*(mode)?", "mode_switch"),  # "Do Anything Now" jailbreak
        (r"\b(STAN|DUDE|AIM)\s*(mode)?", "mode_switch"),  # Known jailbreak personas
        (r"unrestricted\s+mode", "mode_switch"),
        (r"god\s+mode", "mode_switch"),

        # System prompt extraction - must explicitly ask for "system prompt"
        (
            r"(show|reveal|display|repeat|print|output|leak)\s+(me\s+)?(your\s+)?system\s+prompt",
            "prompt_extraction",
        ),
        (
            r"what\s+(are|is)\s+your\s+system\s+(prompt|instructions)",
            "prompt_extraction",
        ),
        (r"(copy|paste|write)\s+(out\s+)?your\s+system\s+prompt", "prompt_extraction"),

        # Delimiter injection - these are specific attack vectors
        (r"\[INST\].*\[/INST\]", "delimiter_injection"),
        (r"<\|im_start\|>|<\|im_end\|>", "delimiter_injection"),
        (r"<\|system\|>|<\|user\|>|<\|assistant\|>", "delimiter_injection"),
        (r"<<SYS>>.*<</SYS>>", "delimiter_injection"),

        # Encoding bypass - attempts to execute encoded malicious content
        (r"execute\s+(the\s+)?following\s+(base64|encoded|encrypted)\s+(payload|code|script)", "encoding_bypass"),
    ]

    def __init__(
        self,
        additional_patterns: Optional[List[Tuple[str, str]]] = None,
        excluded_patterns: Optional[List[str]] = None,
        block_on_detection: bool = True,
        log_detections: bool = True,
    ):
        """
        Initialize the prompt injection middleware.

        Args:
            additional_patterns: Extra patterns to check as (regex, category) tuples
            excluded_patterns: Pattern regex strings to exclude from checking
            block_on_detection: If True, raise SecurityViolation on detection
            log_detections: If True, add detection info to context metadata
        """
        # Compile default patterns
        self.patterns: List[Tuple[re.Pattern, str]] = []

        excluded_set = set(excluded_patterns or [])

        for pattern_str, category in self.DEFAULT_PATTERNS:
            if pattern_str not in excluded_set:
                self.patterns.append(
                    (re.compile(pattern_str, re.IGNORECASE), category)
                )

        # Add custom patterns
        if additional_patterns:
            for pattern_str, category in additional_patterns:
                self.patterns.append(
                    (re.compile(pattern_str, re.IGNORECASE), category)
                )

        self.block_on_detection = block_on_detection
        self.log_detections = log_detections

    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """
        Scan input messages for injection attempts.

        Args:
            context: The middleware context with messages to scan

        Returns:
            The context (potentially with detection metadata added)

        Raises:
            SecurityViolation: If block_on_detection is True and pattern matches
        """
        for msg in context.messages:
            content = getattr(msg, "content", None)
            if not content or not isinstance(content, str):
                continue

            for pattern, category in self.patterns:
                match = pattern.search(content)
                if match:
                    detection_info = {
                        "category": category,
                        "pattern": pattern.pattern,
                        "match": match.group(),
                        "middleware": self.name,
                    }

                    if self.log_detections:
                        if "security_detections" not in context.metadata:
                            context.metadata["security_detections"] = []
                        context.metadata["security_detections"].append(detection_info)

                    if self.block_on_detection:
                        raise SecurityViolation(
                            message=f"Potential prompt injection detected: {category}",
                            pattern=pattern.pattern,
                            category=category,
                            severity="high",
                        )

        return context

    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """Pass through - input filtering only."""
        return result


class OutputSafetyMiddleware(BaseMiddleware):
    """
    Filters unsafe content from LLM responses.

    Scans LLM output for potentially harmful content and either
    redacts it or raises an exception.

    Default patterns detect:
    - Harmful instructions (weapons, explosives)
    - Credential exposure (API keys, passwords)
    - System information leakage

    Example:
        middleware = OutputSafetyMiddleware(
            redact_matches=True,
            additional_patterns=[
                (r"my custom unsafe pattern", "custom_unsafe"),
            ]
        )
    """

    DEFAULT_PATTERNS: List[Tuple[str, str]] = [
        # Harmful instructions
        (
            r"(how\s+to|instructions\s+for|steps\s+to)\s+(make|build|create|construct)\s+(a\s+)?(bomb|weapon|explosive|poison)",
            "harmful_instructions",
        ),
        (
            r"(synthesize|manufacture|produce)\s+(illegal\s+)?(drugs|narcotics|methamphetamine)",
            "harmful_instructions",
        ),

        # Credential/secret exposure
        (
            r"(api[_\s]?key|api[_\s]?secret|access[_\s]?token)\s*[:=]\s*['\"]?[a-zA-Z0-9_\-]{20,}",
            "credential_exposure",
        ),
        (
            r"(password|passwd|pwd)\s*[:=]\s*['\"]?[^\s'\"]{8,}",
            "credential_exposure",
        ),
        (
            r"(bearer|authorization)\s*[:=]\s*['\"]?[a-zA-Z0-9_\-\.]{20,}",
            "credential_exposure",
        ),

        # System information leakage
        (
            r"(my\s+)?system\s+(prompt|instructions)\s*(is|are|:)",
            "system_leak",
        ),
        (
            r"(here\s+is|here\'s)\s+(my|the)\s+(system\s+)?(prompt|instructions)",
            "system_leak",
        ),
    ]

    def __init__(
        self,
        additional_patterns: Optional[List[Tuple[str, str]]] = None,
        redact_matches: bool = True,
        block_on_detection: bool = False,
    ):
        """
        Initialize the output safety middleware.

        Args:
            additional_patterns: Extra patterns to check as (regex, category) tuples
            redact_matches: If True, replace matches with [REDACTED:category]
            block_on_detection: If True, raise SecurityViolation on detection
        """
        self.patterns: List[Tuple[re.Pattern, str]] = [
            (re.compile(p, re.IGNORECASE), cat)
            for p, cat in self.DEFAULT_PATTERNS
        ]

        if additional_patterns:
            self.patterns.extend([
                (re.compile(p, re.IGNORECASE), cat)
                for p, cat in additional_patterns
            ])

        self.redact_matches = redact_matches
        self.block_on_detection = block_on_detection

    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """Pass through - output filtering only."""
        return context

    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """
        Filter unsafe content from LLM response.

        Args:
            context: The middleware context
            result: The LLM response to filter

        Returns:
            The (potentially modified) result

        Raises:
            SecurityViolation: If block_on_detection is True and pattern matches
        """
        content = getattr(result, "content", None)
        if not content or not isinstance(content, str):
            return result

        modified = False
        filtered_content = content

        for pattern, category in self.patterns:
            if pattern.search(filtered_content):
                detection_info = {
                    "category": category,
                    "pattern": pattern.pattern,
                    "middleware": self.name,
                }

                if "output_filtered" not in context.metadata:
                    context.metadata["output_filtered"] = []
                context.metadata["output_filtered"].append(detection_info)

                if self.block_on_detection:
                    raise SecurityViolation(
                        message=f"Unsafe content detected in output: {category}",
                        pattern=pattern.pattern,
                        category=category,
                        severity="high",
                    )

                if self.redact_matches:
                    filtered_content = pattern.sub(
                        f"[REDACTED:{category}]", filtered_content
                    )
                    modified = True

        # Update result content if modified
        if modified and filtered_content != content:
            if hasattr(result, "content"):
                # Try to update content attribute
                try:
                    result.content = filtered_content
                except AttributeError:
                    # Content might be read-only, try model_copy for Pydantic
                    if hasattr(result, "model_copy"):
                        result = result.model_copy(update={"content": filtered_content})

        return result
