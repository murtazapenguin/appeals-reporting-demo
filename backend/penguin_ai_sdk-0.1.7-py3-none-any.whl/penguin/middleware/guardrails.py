"""
Guardrail middleware for enforcing business rules and constraints.

Provides configurable guardrails for:
- Input length limits
- Blocked patterns
- Custom validation functions
- Tool restrictions (for agent-level use)

Example:
    from penguin.middleware import GuardrailMiddleware

    # Enforce input limits and custom validation
    agent.use(GuardrailMiddleware(
        max_input_length=5000,
        custom_validators=[validate_claim_id],
    ))
"""

import re
from typing import Any, Callable, List, Optional, Set

from .base import BaseMiddleware, MiddlewareContext


class GuardrailViolation(Exception):
    """
    Raised when a guardrail check fails.

    Attributes:
        message: Human-readable description of the violation
        guardrail: Name of the guardrail that failed
        details: Additional details about the violation
    """

    def __init__(
        self,
        message: str,
        guardrail: str,
        details: Optional[dict] = None,
    ):
        self.message = message
        self.guardrail = guardrail
        self.details = details or {}
        super().__init__(message)

    def __repr__(self) -> str:
        return f"GuardrailViolation(guardrail={self.guardrail!r}, message={self.message!r})"


class GuardrailMiddleware(BaseMiddleware):
    """
    Enforces configurable guardrails on agent operations.

    Provides multiple guardrail types:
    - max_input_length: Limit total input character count
    - blocked_patterns: Regex patterns to block in input
    - blocked_tools: Tool names to block (for agent-level middleware)
    - custom_validators: Callable functions for custom validation

    Example:
        def validate_claim_id(context):
            '''Ensure claim-related queries include claim ID.'''
            content = " ".join(getattr(m, "content", "") for m in context.messages)
            if "claim" in content.lower() and not re.search(r"CLM-\\d+", content):
                raise GuardrailViolation(
                    "Claim queries must include claim ID",
                    guardrail="claim_id_required"
                )

        middleware = GuardrailMiddleware(
            max_input_length=10000,
            blocked_tools=["execute_shell", "run_code"],
            custom_validators=[validate_claim_id],
        )
    """

    def __init__(
        self,
        max_input_length: Optional[int] = None,
        blocked_patterns: Optional[List[str]] = None,
        blocked_tools: Optional[List[str]] = None,
        custom_validators: Optional[List[Callable[[MiddlewareContext], None]]] = None,
        max_message_count: Optional[int] = None,
    ):
        """
        Initialize the guardrail middleware.

        Args:
            max_input_length: Maximum total character count for all messages
            blocked_patterns: Regex patterns to block in input
            blocked_tools: Tool names to block (for agent-level use)
            custom_validators: Callables that raise exceptions on validation failure
            max_message_count: Maximum number of messages allowed
        """
        self.max_input_length = max_input_length
        self.max_message_count = max_message_count
        self.blocked_tools: Set[str] = set(blocked_tools or [])
        self.custom_validators = custom_validators or []

        # Compile blocked patterns
        self.blocked_patterns: List[re.Pattern] = []
        if blocked_patterns:
            for pattern in blocked_patterns:
                self.blocked_patterns.append(re.compile(pattern, re.IGNORECASE))

    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """
        Apply guardrails to input.

        Args:
            context: The middleware context with messages to validate

        Returns:
            The validated context

        Raises:
            GuardrailViolation: If any guardrail check fails
        """
        # Check message count
        if self.max_message_count is not None:
            if len(context.messages) > self.max_message_count:
                raise GuardrailViolation(
                    f"Message count exceeds limit: {len(context.messages)} > {self.max_message_count}",
                    guardrail="max_message_count",
                    details={
                        "actual": len(context.messages),
                        "limit": self.max_message_count,
                    },
                )

        # Check input length
        if self.max_input_length is not None:
            total_length = sum(
                len(getattr(msg, "content", "") or "")
                for msg in context.messages
            )
            if total_length > self.max_input_length:
                raise GuardrailViolation(
                    f"Input exceeds max length: {total_length} > {self.max_input_length}",
                    guardrail="max_input_length",
                    details={
                        "actual": total_length,
                        "limit": self.max_input_length,
                    },
                )

        # Check blocked patterns
        for msg in context.messages:
            content = getattr(msg, "content", None)
            if not content or not isinstance(content, str):
                continue

            for pattern in self.blocked_patterns:
                match = pattern.search(content)
                if match:
                    raise GuardrailViolation(
                        f"Input matches blocked pattern: {pattern.pattern}",
                        guardrail="blocked_pattern",
                        details={
                            "pattern": pattern.pattern,
                            "match": match.group(),
                        },
                    )

        # Run custom validators
        for validator in self.custom_validators:
            # Validators should raise GuardrailViolation on failure
            validator(context)

        return context

    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """
        Apply guardrails to output (pass through by default).

        Override this method to add output guardrails.

        Args:
            context: The middleware context
            result: The LLM response

        Returns:
            The result (unmodified)
        """
        return result


class ToolBlockingMiddleware(BaseMiddleware):
    """
    Blocks specific tools from being called by agents.

    This middleware is specifically designed for agent-level use
    to prevent certain tools from being invoked.

    Example:
        agent.use(ToolBlockingMiddleware(
            blocked_tools=["execute_shell", "delete_file"],
            on_blocked="raise"  # or "skip"
        ))
    """

    def __init__(
        self,
        blocked_tools: List[str],
        on_blocked: str = "raise",
    ):
        """
        Initialize the tool blocking middleware.

        Args:
            blocked_tools: List of tool names to block
            on_blocked: Action when blocked tool is called:
                - "raise": Raise GuardrailViolation
                - "skip": Silently skip the tool call
        """
        self.blocked_tools: Set[str] = set(blocked_tools)
        self.on_blocked = on_blocked

    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """
        Check if any blocked tools are being requested.

        Note: This checks the metadata for tool_call information.
        The actual tool blocking depends on agent implementation.
        """
        # Check if tool information is in metadata
        tool_name = context.metadata.get("tool_name")
        if tool_name and tool_name in self.blocked_tools:
            if self.on_blocked == "raise":
                raise GuardrailViolation(
                    f"Tool '{tool_name}' is blocked by guardrails",
                    guardrail="blocked_tool",
                    details={"tool_name": tool_name},
                )
            elif self.on_blocked == "skip":
                context.metadata["skip_tool_call"] = True

        return context

    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """Pass through - tool blocking is input-only."""
        return result


class RateLimitMiddleware(BaseMiddleware):
    """
    Simple rate limiting middleware.

    Tracks call counts and enforces limits. For production use,
    consider using a distributed rate limiter like Redis.

    Example:
        client.use(RateLimitMiddleware(
            max_calls_per_minute=60,
        ))
    """

    def __init__(
        self,
        max_calls_per_minute: int = 60,
    ):
        """
        Initialize the rate limit middleware.

        Args:
            max_calls_per_minute: Maximum calls allowed per minute
        """
        import time

        self.max_calls = max_calls_per_minute
        self.call_times: List[float] = []
        self._time = time  # For testing

    async def process_request(
        self, context: MiddlewareContext
    ) -> MiddlewareContext:
        """
        Check and enforce rate limit.

        Args:
            context: The middleware context

        Returns:
            The context if within rate limit

        Raises:
            GuardrailViolation: If rate limit exceeded
        """
        import asyncio

        now = self._time.time()

        # Remove calls outside the 60-second window
        self.call_times = [t for t in self.call_times if now - t < 60]

        # Check if we've hit the limit
        if len(self.call_times) >= self.max_calls:
            # Calculate wait time
            oldest_call = self.call_times[0]
            wait_time = 60 - (now - oldest_call)

            if wait_time > 0:
                # Option: raise immediately or wait
                raise GuardrailViolation(
                    f"Rate limit exceeded. Try again in {wait_time:.1f} seconds",
                    guardrail="rate_limit",
                    details={
                        "max_calls_per_minute": self.max_calls,
                        "retry_after_seconds": wait_time,
                    },
                )

        # Record this call
        self.call_times.append(now)
        return context

    async def process_response(
        self, context: MiddlewareContext, result: Any
    ) -> Any:
        """Pass through - rate limiting is input-only."""
        return result
