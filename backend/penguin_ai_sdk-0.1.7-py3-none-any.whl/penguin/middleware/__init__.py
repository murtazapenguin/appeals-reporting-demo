"""
Penguin Middleware

Real-time security, compliance, and guardrails for LLM operations.
Works at both client and agent levels.

Client-Level Usage (protects ALL LLM calls):
    from penguin.llm import create_client
    from penguin.middleware import PromptInjectionMiddleware

    client = create_client("bedrock", model="claude-sonnet-4-5")
    client.use(PromptInjectionMiddleware())

    # All calls now protected
    result = await client.create([UserMessage("Hello")])

Agent-Level Usage (business rules for specific agents):
    from penguin.agents import Agent
    from penguin.middleware import GuardrailMiddleware

    agent = Agent(client=client, tools=[...])
    agent.use(GuardrailMiddleware(max_input_length=5000))

Factory Functions:
    from penguin.middleware import create_security_middleware

    # Pre-configured security chain
    client = create_client("bedrock", model="claude-sonnet-4-5")
    for mw in create_security_middleware().middlewares:
        client.use(mw)
"""

from typing import List, Optional, Tuple

# Base classes
from .base import (
    BaseMiddleware,
    MiddlewareChain,
    MiddlewareContext,
)

# Security middleware
from .security import (
    PromptInjectionMiddleware,
    OutputSafetyMiddleware,
    SecurityViolation,
)

# Guardrail middleware
from .guardrails import (
    GuardrailMiddleware,
    GuardrailViolation,
    ToolBlockingMiddleware,
    RateLimitMiddleware,
)


def create_security_middleware(
    block_injections: bool = True,
    filter_output: bool = True,
    additional_injection_patterns: Optional[List[Tuple[str, str]]] = None,
    additional_output_patterns: Optional[List[Tuple[str, str]]] = None,
) -> MiddlewareChain:
    """
    Create a pre-configured security middleware chain.

    This is the recommended way to add security to your LLM client.
    It includes prompt injection detection and output safety filtering.

    Args:
        block_injections: Include PromptInjectionMiddleware (default: True)
        filter_output: Include OutputSafetyMiddleware (default: True)
        additional_injection_patterns: Extra patterns for injection detection
        additional_output_patterns: Extra patterns for output filtering

    Returns:
        MiddlewareChain with configured security middleware

    Example:
        # Apply to client
        security = create_security_middleware()
        client = create_client("bedrock", model="claude-sonnet-4-5")
        for mw in security.middlewares:
            client.use(mw)

        # Or use with create_client middleware param (if supported)
        client = create_client(
            "bedrock",
            model="claude-sonnet-4-5",
            middleware=create_security_middleware()
        )
    """
    chain = MiddlewareChain()

    if block_injections:
        chain.add(PromptInjectionMiddleware(
            additional_patterns=additional_injection_patterns,
            block_on_detection=True,
            log_detections=True,
        ))

    if filter_output:
        chain.add(OutputSafetyMiddleware(
            additional_patterns=additional_output_patterns,
            redact_matches=True,
            block_on_detection=False,
        ))

    return chain


def create_guardrail_middleware(
    max_input_length: Optional[int] = None,
    max_message_count: Optional[int] = None,
    blocked_patterns: Optional[List[str]] = None,
    blocked_tools: Optional[List[str]] = None,
    max_calls_per_minute: Optional[int] = None,
) -> MiddlewareChain:
    """
    Create a pre-configured guardrail middleware chain.

    Useful for agent-level business rules and constraints.

    Args:
        max_input_length: Maximum total input character count
        max_message_count: Maximum number of messages
        blocked_patterns: Regex patterns to block
        blocked_tools: Tool names to block
        max_calls_per_minute: Rate limit (calls per minute)

    Returns:
        MiddlewareChain with configured guardrail middleware

    Example:
        guardrails = create_guardrail_middleware(
            max_input_length=10000,
            blocked_tools=["execute_shell"],
            max_calls_per_minute=30
        )

        agent = Agent(client=client, tools=[...])
        for mw in guardrails.middlewares:
            agent.use(mw)
    """
    chain = MiddlewareChain()

    # Add guardrail middleware if any options specified
    if any([max_input_length, max_message_count, blocked_patterns]):
        chain.add(GuardrailMiddleware(
            max_input_length=max_input_length,
            max_message_count=max_message_count,
            blocked_patterns=blocked_patterns,
        ))

    # Add tool blocking if specified
    if blocked_tools:
        chain.add(ToolBlockingMiddleware(
            blocked_tools=blocked_tools,
            on_blocked="raise",
        ))

    # Add rate limiting if specified
    if max_calls_per_minute:
        chain.add(RateLimitMiddleware(
            max_calls_per_minute=max_calls_per_minute,
        ))

    return chain


__all__ = [
    # Base classes
    "BaseMiddleware",
    "MiddlewareChain",
    "MiddlewareContext",

    # Security middleware
    "PromptInjectionMiddleware",
    "OutputSafetyMiddleware",
    "SecurityViolation",

    # Guardrail middleware
    "GuardrailMiddleware",
    "GuardrailViolation",
    "ToolBlockingMiddleware",
    "RateLimitMiddleware",

    # Factory functions
    "create_security_middleware",
    "create_guardrail_middleware",
]
