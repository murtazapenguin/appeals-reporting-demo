"""
Training Engine for AutoML_test
=================================

This module implements the core optimization engine using Optuna.
It handles hyperparameter tuning, cross-validation, and model selection.

Key Components:
- AutoMLTrainer: Main training class that orchestrates optimization
- _objective: Optuna objective function for a single trial
- optimize: Runs the full optimization study
- get_best_model: Retrieves and retrains the best model

The trainer integrates with:
- config.py: For configuration settings
- model_zoo.py: For model creation and hyperparameter spaces
- evaluator.py: For metric calculation (will be created in Task 4)
"""

import warnings
from typing import Dict, Any, Optional, List, Tuple
import numpy as np
import pandas as pd
import optuna
from optuna.samplers import TPESampler, RandomSampler
from sklearn.model_selection import cross_val_score, StratifiedKFold, KFold
from sklearn.preprocessing import StandardScaler

from .config import AutoMLConfig, TaskType, MetricType
from .model_zoo import get_model, get_available_models, requires_scaling
from .exceptions import (
    InvalidDataShapeError,
    InsufficientDataError,
    InvalidMetricError,
    ModelFitError,
    CrossValidationError,
    OptimizationError,
    ModelNotTrainedError,
    ConfigurationError,
    validate_and_raise,
    wrap_exception,
    handle_errors
)

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)


class AutoMLTrainer:
    """
    Main training engine for AutoML_test.

    This class orchestrates the hyperparameter optimization process using Optuna.
    It tries different models and hyperparameters to find the best performing model.

    Attributes:
        config: AutoMLConfig instance with settings
        X: Feature matrix (numpy array or pandas DataFrame)
        y: Target vector (numpy array or pandas Series)
        study: Optuna study object (created during optimization)
        best_model: Best model found (retrained on full data)
        best_params: Best hyperparameters found
        best_score: Best cross-validation score achieved
        optimization_history: List of all trial results

    Example:
        >>> config = AutoMLConfig(task_type='classification', ...)
        >>> trainer = AutoMLTrainer(config, X_train, y_train)
        >>> results = trainer.optimize()
        >>> best_model = trainer.get_best_model()
    """

    def __init__(
        self,
        config: AutoMLConfig,
        X: np.ndarray,
        y: np.ndarray
    ):
        """
        Initialize the trainer.

        Args:
            config: AutoMLConfig instance
            X: Feature matrix (n_samples, n_features)
            y: Target vector (n_samples,)

        Raises:
            ValueError: If X and y have incompatible shapes
        """
        self.config = config
        self.X = np.array(X) if not isinstance(X, np.ndarray) else X
        self.y = np.array(y) if not isinstance(y, np.ndarray) else y

        # Validate data shapes
        if len(self.X) != len(self.y):
            raise InvalidDataShapeError(
                expected_shape=f"{len(self.X)} samples in both X and y",
                actual_shape=(len(self.X), len(self.y))
            )

        # Validate sufficient data
        min_samples = max(10, config.optuna_config.cv_folds + 1)
        if len(self.X) < min_samples:
            raise InsufficientDataError(
                min_samples=min_samples,
                actual_samples=len(self.X)
            )

        # Initialize results storage
        self.study: Optional[optuna.Study] = None
        self.best_model = None
        self.best_params: Dict[str, Any] = {}
        self.best_score: float = 0.0
        self.optimization_history: List[Dict[str, Any]] = []

        # Prepare data scalers (one per model if needed)
        self.scalers: Dict[str, StandardScaler] = {}

        print(f"Initialized AutoMLTrainer")
        print(f"  Task: {config.task_type}")
        print(f"  Models to try: {config.models}")
        print(f"  Primary metric: {config.primary_metric}")
        print(f"  Data shape: {self.X.shape}")
        print(f"  Optuna trials: {config.optuna_config.n_trials}")

    def _get_scorer_name(self, metric: MetricType) -> str:
        """
        Convert MetricType to sklearn scorer name.

        Args:
            metric: MetricType enum value

        Returns:
            Scorer name compatible with cross_val_score

        Raises:
            ValueError: If metric is not supported
        """
        scorer_map = {
            # Classification metrics - basic
            MetricType.PRECISION: 'precision',
            MetricType.RECALL: 'recall',
            MetricType.F1: 'f1',
            MetricType.AUC: 'roc_auc',
            MetricType.ACCURACY: 'accuracy',

            # Classification metrics - weighted/macro/micro variants
            MetricType.F1_WEIGHTED: 'f1_weighted',
            MetricType.F1_MACRO: 'f1_macro',
            MetricType.F1_MICRO: 'f1_micro',
            MetricType.PRECISION_WEIGHTED: 'precision_weighted',
            MetricType.PRECISION_MACRO: 'precision_macro',
            MetricType.RECALL_WEIGHTED: 'recall_weighted',
            MetricType.RECALL_MACRO: 'recall_macro',

            # Regression metrics
            MetricType.MSE: 'neg_mean_squared_error',
            MetricType.MAE: 'neg_mean_absolute_error',
            MetricType.RMSE: 'neg_root_mean_squared_error',
            MetricType.R2: 'r2'
        }

        validate_and_raise(
            metric in scorer_map,
            InvalidMetricError,
            f"Unsupported metric: {metric}",
            details={"metric": str(metric), "supported_metrics": list(scorer_map.keys())}
        )

        scorer_name = scorer_map[metric]

        # Fix for multi-class AUC: sklearn requires 'roc_auc_ovr' or 'roc_auc_ovo' for multi-class
        if metric == MetricType.AUC and self.config.task_type == TaskType.CLASSIFICATION:
            n_classes = len(np.unique(self.y))
            if n_classes > 2:
                scorer_name = 'roc_auc_ovr'  # One-vs-Rest for multi-class

        # For multi-class classification, use weighted/macro variants by default
        if self.config.task_type == TaskType.CLASSIFICATION:
            n_classes = len(np.unique(self.y))
            if n_classes > 2:
                # Map to weighted variants for multi-class
                if metric == MetricType.PRECISION:
                    scorer_name = 'precision_weighted'
                elif metric == MetricType.RECALL:
                    scorer_name = 'recall_weighted'
                elif metric == MetricType.F1:
                    scorer_name = 'f1_weighted'

        return scorer_name

    def _get_cv_splitter(self):
        """
        Get the appropriate cross-validation splitter.

        Returns:
            Cross-validation splitter (StratifiedKFold for classification, KFold for regression)
        """
        n_folds = self.config.optuna_config.cv_folds

        if self.config.task_type == TaskType.CLASSIFICATION:
            # Stratified maintains class distribution in each fold
            return StratifiedKFold(
                n_splits=n_folds,
                shuffle=True,
                random_state=self.config.random_state
            )
        else:
            # Regular KFold for regression
            return KFold(
                n_splits=n_folds,
                shuffle=True,
                random_state=self.config.random_state
            )

    def _scale_features(self, model_name: str) -> Tuple[np.ndarray, StandardScaler]:
        """
        Scale features if required by the model.

        Args:
            model_name: Name of the model

        Returns:
            Tuple of (scaled features, scaler object)
        """
        if requires_scaling(model_name):
            if model_name not in self.scalers:
                self.scalers[model_name] = StandardScaler()
                X_scaled = self.scalers[model_name].fit_transform(self.X)
            else:
                X_scaled = self.scalers[model_name].transform(self.X)
            return X_scaled, self.scalers[model_name]
        else:
            return self.X, None

    def _objective(self, trial: optuna.Trial) -> float:
        """
        Optuna objective function for a single trial.

        This function is called by Optuna for each trial. It:
        1. Suggests which model to try
        2. Gets the model with hyperparameters from the zoo
        3. Performs cross-validation
        4. Returns the score to Optuna

        Args:
            trial: Optuna trial object

        Returns:
            Cross-validation score (higher is better for Optuna)

        Note:
            For metrics where lower is better (MSE, MAE), we return the negative
            score so Optuna maximizes correctly.
        """
        # Step 1: Select model to try
        model_name = trial.suggest_categorical('model', self.config.models)

        # Step 2: Get model instance with hyperparameters
        try:
            model = get_model(model_name, self.config.task_type, trial)
        except Exception as e:
            # If model creation fails, return worst possible score
            error_msg = f"Error creating model {model_name}: {e}"
            print(error_msg)
            trial.set_user_attr('error', error_msg)
            return float('-inf')

        # Step 3: Scale features if needed
        X_train, scaler = self._scale_features(model_name)

        # Step 4: Get scorer for primary metric
        scorer = self._get_scorer_name(self.config.primary_metric)

        # Step 5: Get CV splitter
        cv_splitter = self._get_cv_splitter()

        # Step 6: Perform cross-validation
        try:
            scores = cross_val_score(
                model,
                X_train,
                self.y,
                cv=cv_splitter,
                scoring=scorer,
                n_jobs=self.config.optuna_config.n_jobs,
                error_score='raise'
            )

            # Calculate mean score
            mean_score = np.mean(scores)
            std_score = np.std(scores)

            # Store trial information
            trial.set_user_attr('model_name', model_name)
            trial.set_user_attr('cv_scores', scores.tolist())
            trial.set_user_attr('cv_std', float(std_score))

            # For sklearn scorers that return negative values, the sign is already correct
            # (cross_val_score already handles this)
            return mean_score

        except Exception as e:
            # If cross-validation fails, return worst possible score
            error_msg = f"Error during CV for {model_name}: {e}"
            print(error_msg)
            trial.set_user_attr('error', error_msg)
            return float('-inf')

    def optimize(self) -> Dict[str, Any]:
        """
        Run the full Optuna optimization study.

        This is the main entry point for training. It:
        1. Creates an Optuna study
        2. Runs the optimization for n_trials
        3. Extracts the best model and parameters
        4. Stores optimization history

        Returns:
            Dictionary with optimization results containing:
            - best_model_name: Name of best model
            - best_params: Best hyperparameters
            - best_score: Best CV score
            - best_score_std: Standard deviation of best CV score
            - n_trials: Number of trials completed
            - optimization_history: List of all trial results

        Example:
            >>> trainer = AutoMLTrainer(config, X, y)
            >>> results = trainer.optimize()
            >>> print(f"Best model: {results['best_model_name']}")
            >>> print(f"Best score: {results['best_score']:.4f}")
        """
        print("\n" + "=" * 60)
        print("Starting Hyperparameter Optimization")
        print("=" * 60)

        # Step 1: Select sampler
        if self.config.optuna_config.sampler == 'tpe':
            sampler = TPESampler(seed=self.config.random_state)
        elif self.config.optuna_config.sampler == 'random':
            sampler = RandomSampler(seed=self.config.random_state)
        else:
            sampler = TPESampler(seed=self.config.random_state)

        # Step 2: Create study
        self.study = optuna.create_study(
            direction=self.config.optuna_config.direction,
            sampler=sampler
        )

        # Step 3: Set verbosity
        if self.config.optuna_config.verbosity == 0:
            optuna.logging.set_verbosity(optuna.logging.WARNING)
        elif self.config.optuna_config.verbosity == 1:
            optuna.logging.set_verbosity(optuna.logging.INFO)
        else:
            optuna.logging.set_verbosity(optuna.logging.DEBUG)

        # Step 4: Run optimization
        self.study.optimize(
            self._objective,
            n_trials=self.config.optuna_config.n_trials,
            timeout=self.config.optuna_config.timeout,
            n_jobs=1,  # Parallelization is handled within CV
            show_progress_bar=self.config.optuna_config.show_progress_bar
        )

        # Step 5: Extract best results
        best_trial = self.study.best_trial
        self.best_params = best_trial.params
        self.best_score = best_trial.value
        best_model_name = best_trial.user_attrs['model_name']
        best_cv_std = best_trial.user_attrs['cv_std']

        # Step 6: Build optimization history
        self.optimization_history = []
        for trial in self.study.trials:
            if trial.state == optuna.trial.TrialState.COMPLETE:
                self.optimization_history.append({
                    'trial_number': trial.number,
                    'model_name': trial.user_attrs.get('model_name', 'unknown'),
                    'score': trial.value,
                    'params': trial.params
                })

        # Step 7: Print summary
        print("\n" + "=" * 60)
        print("Optimization Complete!")
        print("=" * 60)
        print(f"Best Model: {best_model_name}")
        print(f"Best Score: {self.best_score:.4f} ± {best_cv_std:.4f}")
        print(f"Best Parameters: {self.best_params}")
        print(f"Total Trials: {len(self.study.trials)}")
        print("=" * 60)

        return {
            'best_model_name': best_model_name,
            'best_params': self.best_params,
            'best_score': self.best_score,
            'best_score_std': best_cv_std,
            'n_trials': len(self.study.trials),
            'optimization_history': self.optimization_history
        }

    def get_best_model(self):
        """
        Get the best model retrained on full training data.

        This method:
        1. Takes the best hyperparameters from optimization
        2. Creates a fresh model instance
        3. Retrains on the FULL training dataset (no CV split)
        4. Returns the trained model

        Returns:
            Trained model instance (sklearn-compatible)

        Raises:
            RuntimeError: If optimize() hasn't been called yet

        Example:
            >>> trainer = AutoMLTrainer(config, X, y)
            >>> trainer.optimize()
            >>> best_model = trainer.get_best_model()
            >>> predictions = best_model.predict(X_test)
        """
        validate_and_raise(
            self.study is not None,
            OptimizationError,
            "No optimization has been run yet. Call optimize() first.",
            details={"operation": "get_best_model"}
        )

        print("\nRetraining best model on full dataset...")

        # Get best trial info
        best_trial = self.study.best_trial
        best_model_name = best_trial.user_attrs['model_name']

        # Create a fresh model with best parameters
        # We use a FixedTrial to recreate the exact same model
        fixed_trial = optuna.trial.FixedTrial(self.best_params)
        best_model = get_model(best_model_name, self.config.task_type, fixed_trial)

        # Scale features if needed
        X_train, scaler = self._scale_features(best_model_name)

        # Train on full data
        best_model.fit(X_train, self.y)

        # Store the model and scaler
        self.best_model = best_model
        if scaler is not None:
            self.best_model._scaler = scaler  # Attach scaler to model for later use

        print(f"✓ Best model ({best_model_name}) retrained on full dataset")

        return self.best_model

    def get_optimization_summary(self) -> pd.DataFrame:
        """
        Get a summary of all optimization trials as a DataFrame.

        Returns:
            DataFrame with columns: trial_number, model_name, score, params

        Raises:
            OptimizationError: If optimize() hasn't been called yet
        """
        validate_and_raise(
            len(self.optimization_history) > 0,
            OptimizationError,
            "No optimization history available. Call optimize() first.",
            details={"operation": "get_optimization_summary"}
        )

        return pd.DataFrame(self.optimization_history)

    def get_feature_importance(self, feature_names: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Get feature importance from the best model (if available).

        Args:
            feature_names: Optional list of feature names

        Returns:
            DataFrame with feature names and importance scores

        Raises:
            ModelNotTrainedError: If best model not available
            ConfigurationError: If model doesn't support feature importance
        """
        if self.best_model is None:
            raise ModelNotTrainedError("get_feature_importance")

        validate_and_raise(
            hasattr(self.best_model, 'feature_importances_'),
            ConfigurationError,
            f"Model {type(self.best_model).__name__} does not support feature importance",
            details={"model_type": type(self.best_model).__name__}
        )

        importances = self.best_model.feature_importances_

        if feature_names is None:
            feature_names = [f"feature_{i}" for i in range(len(importances))]

        return pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    from sklearn.datasets import make_classification, make_regression
    from .config import create_quick_config

    print("=" * 60)
    print("AutoML_test Trainer Test")
    print("=" * 60)

    # Test 1: Classification
    print("\n1. Testing Classification:")
    X_cls, y_cls = make_classification(
        n_samples=200,
        n_features=10,
        n_informative=8,
        n_redundant=2,
        random_state=42
    )

    config_cls = create_quick_config(
        task='classification',
        models=['random_forest', 'logistic_regression'],
        metric='accuracy',
        n_trials=5  # Small number for quick test
    )

    trainer_cls = AutoMLTrainer(config_cls, X_cls, y_cls)
    results_cls = trainer_cls.optimize()
    best_model_cls = trainer_cls.get_best_model()

    print(f"\n   ✓ Best model: {results_cls['best_model_name']}")
    print(f"   ✓ Best score: {results_cls['best_score']:.4f}")

    # Test 2: Regression
    print("\n2. Testing Regression:")
    X_reg, y_reg = make_regression(
        n_samples=200,
        n_features=10,
        n_informative=8,
        random_state=42
    )

    config_reg = create_quick_config(
        task='regression',
        models=['random_forest', 'ridge'],
        metric='r2',
        n_trials=5
    )

    trainer_reg = AutoMLTrainer(config_reg, X_reg, y_reg)
    results_reg = trainer_reg.optimize()
    best_model_reg = trainer_reg.get_best_model()

    print(f"\n   ✓ Best model: {results_reg['best_model_name']}")
    print(f"   ✓ Best score: {results_reg['best_score']:.4f}")

    # Test 3: Get optimization summary
    print("\n3. Testing Optimization Summary:")
    summary = trainer_cls.get_optimization_summary()
    print(f"   ✓ Summary shape: {summary.shape}")
    print(f"   ✓ Columns: {list(summary.columns)}")

    print("\n" + "=" * 60)
    print("Trainer working correctly!")
    print("=" * 60)
