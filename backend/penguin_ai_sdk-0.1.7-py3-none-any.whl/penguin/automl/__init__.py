"""
AutoML_test: A Glass-Box AutoML Library for Feature Data Engineers
====================================================================

A transparent, interpretable AutoML library that helps FDEs train, evaluate,
explain, and register models on pre-processed data.

Core Features:
- Multiple model support (Random Forest, XGBoost, Linear models, etc.)
- Hyperparameter optimization via Optuna
- Comprehensive metrics (Classification & Regression)
- Model interpretability via SHAP
- Model lifecycle management

Author: AutoML_test Team
Version: 0.1.0

Example:
    >>> from penguin.automl import FDEAutoML, train_test_split
    >>>
    >>> # Manual split
    >>> X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    >>> automl = FDEAutoML(task='classification')
    >>> automl.fit(X_train, y_train)
    >>>
    >>> # Or automatic split
    >>> automl = FDEAutoML(task='classification')
    >>> automl.fit(X, y, test_size=0.2)
    >>> predictions = automl.predict(X_test)
"""

__version__ = "0.1.0"
__author__ = "AutoML_test Team"

# Import main interface
from .core import FDEAutoML

# Import model discovery functions
from .model_zoo import (
    get_available_models,
    is_model_available,
    requires_scaling
)

# Import sklearn utilities for convenience
from sklearn.model_selection import train_test_split

# Export main classes and utilities
__all__ = [
    'FDEAutoML',
    'train_test_split',
    'get_available_models',
    'is_model_available',
    'requires_scaling',
    'list_models',  # Alias for get_available_models
    'get_model_info'
]


def list_models():
    """
    List all available ML models in AutoML.

    Similar to penguin.llm.get_available_providers(), this function returns
    a list of all models that can be used with FDEAutoML.

    Returns:
        List of model names (e.g., ['random_forest', 'xgboost', 'logistic_regression'])

    Example:
        >>> from penguin.automl import list_models
        >>> models = list_models()
        >>> print(models)
        ['random_forest', 'decision_tree', 'logistic_regression', ...]
    """
    return get_available_models()


def get_model_info(model_name: str = None):
    """
    Get detailed information about available models.

    If model_name is provided, returns info about that specific model.
    If model_name is None, returns info about all models.

    Args:
        model_name: Optional name of specific model to get info about

    Returns:
        Dictionary with model information including:
        - supports_classification: bool
        - supports_regression: bool
        - requires_scaling: bool
        - description: str

    Example:
        >>> from penguin.automl import get_model_info
        >>>
        >>> # Get info about all models
        >>> all_info = get_model_info()
        >>>
        >>> # Get info about specific model
        >>> rf_info = get_model_info('random_forest')
        >>> print(rf_info['supports_classification'])  # True
    """
    from .model_zoo import MODEL_REGISTRY

    # Model descriptions
    descriptions = {
        'random_forest': 'Ensemble of decision trees with bagging',
        'decision_tree': 'Single decision tree classifier/regressor',
        'logistic_regression': 'Linear model for classification',
        'linear_regression': 'Linear model for regression',
        'ridge': 'Linear regression with L2 regularization',
        'lasso': 'Linear regression with L1 regularization',
        'svm': 'Support Vector Machine',
        'knn': 'K-Nearest Neighbors',
        'xgboost': 'Gradient boosting with XGBoost (requires xgboost)',
        'lightgbm': 'Gradient boosting with LightGBM (requires lightgbm)',
        'catboost': 'Gradient boosting with CatBoost (requires catboost)'
    }

    def _get_info_for_model(name: str) -> dict:
        """Helper to get info for a single model."""
        if name not in MODEL_REGISTRY:
            raise ValueError(
                f"Model '{name}' not available. "
                f"Available models: {', '.join(get_available_models())}"
            )

        model_info = MODEL_REGISTRY[name]
        return {
            'name': name,
            'supports_classification': model_info.classifier_class is not None,
            'supports_regression': model_info.regressor_class is not None,
            'requires_scaling': model_info.requires_scaling,
            'description': descriptions.get(name, 'No description available'),
            'classifier_class': model_info.classifier_class.__name__ if model_info.classifier_class else None,
            'regressor_class': model_info.regressor_class.__name__ if model_info.regressor_class else None,
        }

    # Return info for specific model or all models
    if model_name:
        return _get_info_for_model(model_name)
    else:
        return {name: _get_info_for_model(name) for name in get_available_models()}
