"""
Evaluation Module for AutoML_test
===================================

This module provides comprehensive model evaluation capabilities.
It calculates task-specific metrics and generates evaluation reports.

Key Components:
- ModelEvaluator: Main evaluation class
- evaluate_classification: Classification-specific evaluation
- evaluate_regression: Regression-specific evaluation
- calculate_metric: Individual metric calculation

Supported Metrics:
- Classification: Precision, Recall, F1, AUC, Accuracy
- Regression: MAE, MSE, RMSE, R²
"""

from typing import Dict, Any, Optional, Union
import numpy as np
import pandas as pd
from sklearn.metrics import (
    # Classification metrics
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,

    # Regression metrics
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from .config import TaskType, MetricType


class ModelEvaluator:
    """
    Comprehensive model evaluation class.

    This class provides methods to evaluate both classification and regression
    models, calculating multiple metrics and generating detailed reports.

    Attributes:
        task_type: Type of ML task (classification or regression)

    Example:
        >>> evaluator = ModelEvaluator(TaskType.CLASSIFICATION)
        >>> results = evaluator.evaluate(y_true, y_pred, y_proba)
        >>> print(results['accuracy'])
    """

    def __init__(self, task_type: TaskType):
        """
        Initialize the evaluator.

        Args:
            task_type: TaskType enum (CLASSIFICATION or REGRESSION)
        """
        self.task_type = task_type

    def calculate_metric(
        self,
        metric: MetricType,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: Optional[np.ndarray] = None
    ) -> float:
        """
        Calculate a single metric.

        Args:
            metric: MetricType enum value
            y_true: True labels/values
            y_pred: Predicted labels/values
            y_proba: Predicted probabilities (for classification only)

        Returns:
            Metric value as float

        Raises:
            ValueError: If metric is not supported or inappropriate for task
        """
        # Classification metrics
        if metric == MetricType.ACCURACY:
            return accuracy_score(y_true, y_pred)

        elif metric == MetricType.PRECISION:
            # Use 'binary' for binary classification, 'weighted' for multiclass
            n_classes = len(np.unique(y_true))
            average = 'binary' if n_classes == 2 else 'weighted'
            return precision_score(y_true, y_pred, average=average, zero_division=0)

        elif metric == MetricType.RECALL:
            n_classes = len(np.unique(y_true))
            average = 'binary' if n_classes == 2 else 'weighted'
            return recall_score(y_true, y_pred, average=average, zero_division=0)

        elif metric == MetricType.F1:
            n_classes = len(np.unique(y_true))
            average = 'binary' if n_classes == 2 else 'weighted'
            return f1_score(y_true, y_pred, average=average, zero_division=0)

        elif metric == MetricType.F1_WEIGHTED:
            return f1_score(y_true, y_pred, average='weighted', zero_division=0)

        elif metric == MetricType.F1_MACRO:
            return f1_score(y_true, y_pred, average='macro', zero_division=0)

        elif metric == MetricType.F1_MICRO:
            return f1_score(y_true, y_pred, average='micro', zero_division=0)

        elif metric == MetricType.PRECISION_WEIGHTED:
            return precision_score(y_true, y_pred, average='weighted', zero_division=0)

        elif metric == MetricType.PRECISION_MACRO:
            return precision_score(y_true, y_pred, average='macro', zero_division=0)

        elif metric == MetricType.RECALL_WEIGHTED:
            return recall_score(y_true, y_pred, average='weighted', zero_division=0)

        elif metric == MetricType.RECALL_MACRO:
            return recall_score(y_true, y_pred, average='macro', zero_division=0)

        elif metric == MetricType.AUC:
            if y_proba is None:
                raise ValueError("AUC requires predicted probabilities (y_proba)")

            n_classes = len(np.unique(y_true))
            if n_classes == 2:
                # Binary classification: use positive class probabilities
                if y_proba.ndim == 2:
                    y_proba = y_proba[:, 1]
                return roc_auc_score(y_true, y_proba)
            else:
                # Multiclass: use one-vs-rest with weighted average
                return roc_auc_score(y_true, y_proba, multi_class='ovr', average='weighted')

        # Regression metrics
        elif metric == MetricType.MAE:
            return mean_absolute_error(y_true, y_pred)

        elif metric == MetricType.MSE:
            return mean_squared_error(y_true, y_pred)

        elif metric == MetricType.RMSE:
            return np.sqrt(mean_squared_error(y_true, y_pred))

        elif metric == MetricType.R2:
            return r2_score(y_true, y_pred)

        else:
            raise ValueError(f"Unsupported metric: {metric}")

    def evaluate_classification(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: Optional[np.ndarray] = None
    ) -> Dict[str, Any]:
        """
        Comprehensive classification evaluation.

        Args:
            y_true: True labels
            y_pred: Predicted labels
            y_proba: Predicted probabilities (optional, needed for AUC)

        Returns:
            Dictionary containing:
            - accuracy: Overall accuracy
            - precision: Precision score
            - recall: Recall score
            - f1: F1 score
            - auc: AUC-ROC score (if y_proba provided)
            - confusion_matrix: Confusion matrix as 2D array
            - classification_report: Detailed per-class metrics
            - n_classes: Number of classes
            - class_distribution: Distribution of true labels

        Example:
            >>> evaluator = ModelEvaluator(TaskType.CLASSIFICATION)
            >>> results = evaluator.evaluate_classification(y_true, y_pred, y_proba)
            >>> print(f"Accuracy: {results['accuracy']:.4f}")
            >>> print(f"Confusion Matrix:\n{results['confusion_matrix']}")
        """
        results = {}

        # Basic metrics
        results['accuracy'] = accuracy_score(y_true, y_pred)

        # Determine if binary or multiclass
        n_classes = len(np.unique(y_true))
        results['n_classes'] = n_classes
        average = 'binary' if n_classes == 2 else 'weighted'

        # Precision, Recall, F1
        results['precision'] = precision_score(y_true, y_pred, average=average, zero_division=0)
        results['recall'] = recall_score(y_true, y_pred, average=average, zero_division=0)
        results['f1'] = f1_score(y_true, y_pred, average=average, zero_division=0)

        # AUC (if probabilities provided)
        if y_proba is not None:
            try:
                if n_classes == 2:
                    # Binary: use positive class probability
                    if y_proba.ndim == 2:
                        y_proba_pos = y_proba[:, 1]
                    else:
                        y_proba_pos = y_proba
                    results['auc'] = roc_auc_score(y_true, y_proba_pos)
                else:
                    # Multiclass: one-vs-rest
                    results['auc'] = roc_auc_score(y_true, y_proba, multi_class='ovr', average='weighted')
            except Exception as e:
                results['auc'] = None
                results['auc_error'] = str(e)
        else:
            results['auc'] = None

        # Confusion Matrix
        results['confusion_matrix'] = confusion_matrix(y_true, y_pred)

        # Classification Report (detailed per-class metrics)
        results['classification_report'] = classification_report(y_true, y_pred, output_dict=True)

        # Class distribution
        unique, counts = np.unique(y_true, return_counts=True)
        results['class_distribution'] = dict(zip(unique.tolist(), counts.tolist()))

        return results

    def evaluate_regression(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray
    ) -> Dict[str, Any]:
        """
        Comprehensive regression evaluation.

        Args:
            y_true: True values
            y_pred: Predicted values

        Returns:
            Dictionary containing:
            - mae: Mean Absolute Error
            - mse: Mean Squared Error
            - rmse: Root Mean Squared Error
            - r2: R-squared score
            - residuals: Array of residuals (actual - predicted)
            - residuals_mean: Mean of residuals (should be ~0)
            - residuals_std: Standard deviation of residuals
            - residuals_min: Minimum residual
            - residuals_max: Maximum residual
            - target_mean: Mean of true values
            - target_std: Standard deviation of true values

        Example:
            >>> evaluator = ModelEvaluator(TaskType.REGRESSION)
            >>> results = evaluator.evaluate_regression(y_true, y_pred)
            >>> print(f"MAE: {results['mae']:.4f}")
            >>> print(f"R²: {results['r2']:.4f}")
        """
        results = {}

        # Error-based metrics
        results['mae'] = mean_absolute_error(y_true, y_pred)
        results['mse'] = mean_squared_error(y_true, y_pred)
        results['rmse'] = np.sqrt(results['mse'])
        results['r2'] = r2_score(y_true, y_pred)

        # Residual analysis
        residuals = y_true - y_pred
        results['residuals'] = residuals
        results['residuals_mean'] = np.mean(residuals)
        results['residuals_std'] = np.std(residuals)
        results['residuals_min'] = np.min(residuals)
        results['residuals_max'] = np.max(residuals)

        # Target statistics (for context)
        results['target_mean'] = np.mean(y_true)
        results['target_std'] = np.std(y_true)

        # Additional useful metrics
        results['mape'] = np.mean(np.abs((y_true - y_pred) / (y_true + 1e-10))) * 100  # Mean Absolute Percentage Error
        results['max_error'] = np.max(np.abs(residuals))

        return results

    def evaluate(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: Optional[np.ndarray] = None
    ) -> Dict[str, Any]:
        """
        Main evaluation method that dispatches to task-specific evaluators.

        Args:
            y_true: True labels/values
            y_pred: Predicted labels/values
            y_proba: Predicted probabilities (for classification)

        Returns:
            Dictionary of evaluation results

        Example:
            >>> evaluator = ModelEvaluator(TaskType.CLASSIFICATION)
            >>> results = evaluator.evaluate(y_true, y_pred, y_proba)
        """
        if self.task_type == TaskType.CLASSIFICATION:
            return self.evaluate_classification(y_true, y_pred, y_proba)
        elif self.task_type == TaskType.REGRESSION:
            return self.evaluate_regression(y_true, y_pred)
        else:
            raise ValueError(f"Unsupported task type: {self.task_type}")

    def format_results(self, results: Dict[str, Any]) -> str:
        """
        Format evaluation results as a human-readable string.

        Args:
            results: Dictionary of evaluation results

        Returns:
            Formatted string representation

        Example:
            >>> evaluator = ModelEvaluator(TaskType.CLASSIFICATION)
            >>> results = evaluator.evaluate(y_true, y_pred, y_proba)
            >>> print(evaluator.format_results(results))
        """
        lines = []
        lines.append("=" * 60)
        lines.append("Model Evaluation Results")
        lines.append("=" * 60)

        if self.task_type == TaskType.CLASSIFICATION:
            lines.append(f"\nTask Type: Classification")
            lines.append(f"Number of Classes: {results.get('n_classes', 'N/A')}")
            lines.append(f"\nOverall Metrics:")
            lines.append(f"  Accuracy:  {results.get('accuracy', 0):.4f}")
            lines.append(f"  Precision: {results.get('precision', 0):.4f}")
            lines.append(f"  Recall:    {results.get('recall', 0):.4f}")
            lines.append(f"  F1-Score:  {results.get('f1', 0):.4f}")
            if results.get('auc') is not None:
                lines.append(f"  AUC:       {results['auc']:.4f}")

            lines.append(f"\nConfusion Matrix:")
            cm = results.get('confusion_matrix')
            if cm is not None:
                for row in cm:
                    lines.append(f"  {row}")

            lines.append(f"\nClass Distribution:")
            for cls, count in results.get('class_distribution', {}).items():
                lines.append(f"  Class {cls}: {count} samples")

        elif self.task_type == TaskType.REGRESSION:
            lines.append(f"\nTask Type: Regression")
            lines.append(f"\nError Metrics:")
            lines.append(f"  MAE:  {results.get('mae', 0):.4f}")
            lines.append(f"  MSE:  {results.get('mse', 0):.4f}")
            lines.append(f"  RMSE: {results.get('rmse', 0):.4f}")
            lines.append(f"  R²:   {results.get('r2', 0):.4f}")
            lines.append(f"  MAPE: {results.get('mape', 0):.2f}%")

            lines.append(f"\nResidual Statistics:")
            lines.append(f"  Mean:   {results.get('residuals_mean', 0):.4f} (should be ~0)")
            lines.append(f"  Std:    {results.get('residuals_std', 0):.4f}")
            lines.append(f"  Min:    {results.get('residuals_min', 0):.4f}")
            lines.append(f"  Max:    {results.get('residuals_max', 0):.4f}")

            lines.append(f"\nTarget Statistics:")
            lines.append(f"  Mean: {results.get('target_mean', 0):.4f}")
            lines.append(f"  Std:  {results.get('target_std', 0):.4f}")

        lines.append("=" * 60)
        return "\n".join(lines)


def evaluate_model(
    model,
    X_test: np.ndarray,
    y_test: np.ndarray,
    task_type: TaskType
) -> Dict[str, Any]:
    """
    Convenience function to evaluate a trained model on test data.

    Args:
        model: Trained sklearn-compatible model
        X_test: Test features
        y_test: Test labels/values
        task_type: Type of task (classification or regression)

    Returns:
        Dictionary of evaluation results

    Example:
        >>> results = evaluate_model(trained_model, X_test, y_test, TaskType.CLASSIFICATION)
        >>> print(f"Test Accuracy: {results['accuracy']:.4f}")
    """
    evaluator = ModelEvaluator(task_type)

    # Make predictions
    y_pred = model.predict(X_test)

    # Get probabilities for classification
    y_proba = None
    if task_type == TaskType.CLASSIFICATION and hasattr(model, 'predict_proba'):
        try:
            y_proba = model.predict_proba(X_test)
        except:
            y_proba = None

    # Evaluate
    results = evaluator.evaluate(y_test, y_pred, y_proba)

    return results


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    from sklearn.datasets import make_classification, make_regression
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
    from sklearn.model_selection import train_test_split

    print("=" * 60)
    print("AutoML_test Evaluator Test")
    print("=" * 60)

    # Test 1: Classification
    print("\n1. Testing Classification Evaluation:")
    X_cls, y_cls = make_classification(
        n_samples=500,
        n_features=20,
        n_informative=15,
        n_redundant=5,
        n_classes=3,
        random_state=42
    )
    X_train_cls, X_test_cls, y_train_cls, y_test_cls = train_test_split(
        X_cls, y_cls, test_size=0.3, random_state=42
    )

    # Train a model
    model_cls = RandomForestClassifier(n_estimators=100, random_state=42)
    model_cls.fit(X_train_cls, y_train_cls)

    # Evaluate
    results_cls = evaluate_model(model_cls, X_test_cls, y_test_cls, TaskType.CLASSIFICATION)

    evaluator_cls = ModelEvaluator(TaskType.CLASSIFICATION)
    print(evaluator_cls.format_results(results_cls))

    # Test 2: Regression
    print("\n2. Testing Regression Evaluation:")
    X_reg, y_reg = make_regression(
        n_samples=500,
        n_features=20,
        n_informative=15,
        random_state=42
    )
    X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(
        X_reg, y_reg, test_size=0.3, random_state=42
    )

    # Train a model
    model_reg = RandomForestRegressor(n_estimators=100, random_state=42)
    model_reg.fit(X_train_reg, y_train_reg)

    # Evaluate
    results_reg = evaluate_model(model_reg, X_test_reg, y_test_reg, TaskType.REGRESSION)

    evaluator_reg = ModelEvaluator(TaskType.REGRESSION)
    print(evaluator_reg.format_results(results_reg))

    # Test 3: Individual metric calculation
    print("\n3. Testing Individual Metric Calculation:")
    evaluator = ModelEvaluator(TaskType.CLASSIFICATION)
    y_pred_cls = model_cls.predict(X_test_cls)
    y_proba_cls = model_cls.predict_proba(X_test_cls)

    accuracy = evaluator.calculate_metric(MetricType.ACCURACY, y_test_cls, y_pred_cls)
    auc = evaluator.calculate_metric(MetricType.AUC, y_test_cls, y_pred_cls, y_proba_cls)

    print(f"   ✓ Accuracy: {accuracy:.4f}")
    print(f"   ✓ AUC: {auc:.4f}")

    print("\n" + "=" * 60)
    print("Evaluator working correctly!")
    print("=" * 60)
