"""
Core Interface for AutoML_test
================================

This module provides the main user-facing API for the AutoML library.
The FDEAutoML class is a facade that simplifies access to all functionality.

Users are responsible for providing clean, preprocessed data.
The library focuses on hyperparameter optimization and model selection.
"""

from typing import Dict, Any, Optional, List, Union
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from .config import AutoMLConfig, TaskType, MetricType, create_quick_config
from .trainer import AutoMLTrainer
from .evaluator import ModelEvaluator, evaluate_model
from .explainer import ModelExplainer
from .registry import ModelRegistry
from .exceptions import (
    AutoMLError,
    MissingDataError,
    InvalidDataShapeError,
    InsufficientDataError,
    TrainingError,
    EvaluationError,
    ExplanationError,
    RegistryError,
    ModelNotTrainedError,
    ConfigurationError,
    InvalidTaskTypeError,
    wrap_exception,
    validate_and_raise,
    handle_errors
)


class FDEAutoML:
    """
    Main AutoML interface for hyperparameter optimization and model training.

    Users are responsible for providing clean, preprocessed data.
    The library focuses on model selection and hyperparameter optimization.
    """

    def __init__(
        self,
        task: str,
        models: Optional[List[str]] = None,
        metric: Optional[str] = None,
        n_trials: int = 50,
        cv_folds: int = 5,
        random_state: int = 42,
        registry_path: str = "./model_registry"
    ):
        """
        Initialize FDEAutoML for model training and optimization.

        Args:
            task: 'classification' or 'regression'
            models: List of models to try
            metric: Optimization metric
            n_trials: Optuna trials
            cv_folds: Cross-validation folds
            random_state: Random seed
            registry_path: Model storage path

        Note:
            Users must provide preprocessed data. The library expects clean,
            numeric data with no missing values.
        """
        # Create configuration
        self.config = create_quick_config(
            task=task,
            models=models,
            metric=metric,
            n_trials=n_trials
        )
        self.config.optuna_config.cv_folds = cv_folds
        self.config.random_state = random_state
        self.config.model_registry_path = registry_path

        # Initialize components
        self.trainer: Optional[AutoMLTrainer] = None
        self.best_model = None
        self.evaluator = ModelEvaluator(self.config.task_type)
        self.explainer: Optional[ModelExplainer] = None
        self.registry = ModelRegistry(registry_path)

        # Store results and feature names
        self.results: Dict[str, Any] = {}
        self.feature_names: Optional[List[str]] = None
        self.original_feature_names: Optional[List[str]] = None
        self.training_history: Dict[str, Any] = {}

        # Store held-out test set for automatic train-test split
        self.X_test_held_out: Optional[Union[np.ndarray, pd.DataFrame]] = None
        self.y_test_held_out: Optional[Union[np.ndarray, pd.Series]] = None

        print("FDEAutoML initialized")
        print(f"  Task: {task}")
        print(f"  Models: {self.config.models}")
        print(f"  Metric: {self.config.primary_metric}")
        print(f"  Trials: {n_trials}")

    def fit(
        self,
        X: Union[np.ndarray, pd.DataFrame],
        y: Union[np.ndarray, pd.Series],
        feature_names: Optional[List[str]] = None,
        validation_split: float = 0.2,
        test_size: Optional[float] = None
    ) -> 'FDEAutoML':
        """
        Train AutoML models on preprocessed data.

        Args:
            X: Feature matrix (must be clean, numeric, no missing values)
            y: Target vector
            feature_names: Optional feature names
            validation_split: Validation set fraction
            test_size: If provided, automatically splits data into train/test sets
                      (e.g., 0.2 means 80% train, 20% test). Test set is held out
                      and can be used with evaluate() without passing data.

        Returns:
            self

        Note:
            Data must be preprocessed before calling fit(). Handle missing values,
            encode categorical variables, and scale features as needed.
        """
        # Validate inputs
        validate_and_raise(
            X is not None,
            MissingDataError,
            "Feature matrix X cannot be None"
        )
        validate_and_raise(
            y is not None,
            MissingDataError,
            "Target vector y cannot be None"
        )

        # Validate shapes
        if hasattr(X, 'shape'):
            if len(X.shape) != 2:
                raise InvalidDataShapeError(
                    expected_shape="2D array (samples, features)",
                    actual_shape=X.shape
                )
            if X.shape[0] == 0:
                raise InsufficientDataError(
                    min_samples=1,
                    actual_samples=X.shape[0]
                )

        # Validate y length matches X
        if hasattr(X, '__len__') and hasattr(y, '__len__'):
            if len(X) != len(y):
                raise InvalidDataShapeError(
                    expected_shape=f"{len(X)} samples in both X and y",
                    actual_shape=(len(X), len(y))
                )

        print("\n" + "=" * 70)
        print("Starting AutoML Training")
        print("=" * 70)

        # Convert to DataFrame if needed
        if not isinstance(X, pd.DataFrame):
            if feature_names is not None:
                X = pd.DataFrame(X, columns=feature_names)
            else:
                X = pd.DataFrame(X)

        if not isinstance(y, pd.Series):
            y = pd.Series(y)

        # Store original feature names
        self.original_feature_names = X.columns.tolist()

        print(f"\nInput data shape: {X.shape}")
        print(f"Features: {len(X.columns)}")
        print(f"Samples: {len(X)}")

        # Automatic train-test split if requested
        if test_size is not None:
            print(f"\n⚙ Performing automatic train-test split (test_size={test_size})")
            X_train, X_test, y_train, y_test = train_test_split(
                X, y,
                test_size=test_size,
                random_state=self.config.random_state,
                stratify=y if self.config.task_type == TaskType.CLASSIFICATION else None
            )
            # Store raw test set (before preprocessing)
            self.X_test_held_out = X_test.copy()
            self.y_test_held_out = y_test.copy()
            # Use train set for training
            X = X_train
            y = y_train
            print(f"✓ Split complete: {len(X_train)} train, {len(X_test)} test (held out)")
        else:
            # No automatic split - reset held-out test set
            self.X_test_held_out = None
            self.y_test_held_out = None

        # Data is expected to be preprocessed by the user

        # Store final feature names
        if isinstance(X, pd.DataFrame):
            self.feature_names = X.columns.tolist()
        else:
            self.feature_names = [f"feature_{i}" for i in range(X.shape[1])]

        print(f"\n✓ Final feature count: {len(self.feature_names)}")

        # Convert to numpy for training
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(y, pd.Series):
            y = y.values

        # Step 3: Split validation set if requested
        if validation_split > 0:
            X_train, X_val, y_train, y_val = train_test_split(
                X, y,
                test_size=validation_split,
                random_state=self.config.random_state,
                stratify=y if self.config.task_type == TaskType.CLASSIFICATION else None
            )
            print(f"\n✓ Split data: {len(X_train)} train, {len(X_val)} validation")
        else:
            X_train, y_train = X, y
            X_val, y_val = None, None

        # Step 1: Model training and optimization
        print("\n" + "="*70)
        print("STEP 1: MODEL TRAINING & OPTIMIZATION")
        print("="*70)

        with handle_errors("model training", {ValueError: TrainingError, RuntimeError: TrainingError}):
            self.trainer = AutoMLTrainer(self.config, X_train, y_train)
            optimization_results = self.trainer.optimize()
            self.best_model = self.trainer.get_best_model()

            # Store results
            self.results['optimization'] = optimization_results
            self.results['best_model_name'] = optimization_results['best_model_name']
            self.results['best_params'] = optimization_results['best_params']
            self.results['best_cv_score'] = optimization_results['best_score']

        # Evaluate on validation set if available
        if X_val is not None:
            print("\nEvaluating on validation set...")
            val_results = self.evaluate(X_val, y_val, verbose=False)
            self.results['validation'] = val_results

        # Initialize explainer
        if self.config.enable_shap:
            try:
                background_size = min(100, len(X_train))
                with handle_errors("SHAP explainer initialization", {ValueError: ExplanationError, RuntimeError: ExplanationError}):
                    self.explainer = ModelExplainer(
                        model=self.best_model,
                        X_background=X_train[:background_size],
                        feature_names=self.feature_names
                    )
            except ExplanationError as e:
                print(f"Warning: Could not initialize SHAP: {e}")
                self.explainer = None

        print("\n" + "=" * 70)
        print("✓ AutoML Training Complete!")
        print("=" * 70)
        print(f"\nBest Model: {self.results['best_model_name']}")
        print(f"CV Score: {self.results['best_cv_score']:.4f}")

        return self

    def predict(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        """
        Make predictions on preprocessed data.

        Args:
            X: Preprocessed input data (must match training data format)

        Returns:
            Predictions

        Note:
            Data must be preprocessed the same way as training data.
        """
        if self.best_model is None:
            raise ModelNotTrainedError("prediction")

        # Convert to numpy if needed
        if isinstance(X, pd.DataFrame):
            X = X.values

        return self.best_model.predict(X)

    def predict_proba(self, X: Union[np.ndarray, pd.DataFrame]) -> np.ndarray:
        """
        Get class probabilities for preprocessed data.

        Args:
            X: Preprocessed input data (must match training data format)

        Returns:
            Probabilities

        Note:
            Only available for classification tasks.
            Data must be preprocessed the same way as training data.
        """
        if self.best_model is None:
            raise ModelNotTrainedError("predict_proba")

        validate_and_raise(
            self.config.task_type == TaskType.CLASSIFICATION,
            InvalidTaskTypeError,
            "predict_proba is only available for classification tasks",
            details={"task_type": str(self.config.task_type), "method": "predict_proba"}
        )

        # Convert to numpy if needed
        if isinstance(X, pd.DataFrame):
            X = X.values

        return self.best_model.predict_proba(X)

    def evaluate(
        self,
        X_test: Optional[Union[np.ndarray, pd.DataFrame]] = None,
        y_test: Optional[Union[np.ndarray, pd.Series]] = None,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """
        Evaluate model on preprocessed test data.

        Args:
            X_test: Test features (preprocessed). If None, uses held-out test set from fit()
            y_test: Test labels. If None, uses held-out test set from fit()
            verbose: Print results

        Returns:
            Metrics dictionary

        Note:
            Test data must be preprocessed the same way as training data.
        """
        if self.best_model is None:
            raise ModelNotTrainedError("evaluation")

        # Use held-out test set if not provided
        if X_test is None or y_test is None:
            if self.X_test_held_out is None or self.y_test_held_out is None:
                raise ValueError(
                    "No test data provided and no held-out test set available. "
                    "Either provide X_test and y_test, or use test_size parameter in fit()."
                )
            X_test = self.X_test_held_out
            y_test = self.y_test_held_out
            if verbose:
                print("\n⚙ Using held-out test set for evaluation")

        # Convert to numpy if needed
        if isinstance(X_test, pd.DataFrame):
            X_test = X_test.values
        if isinstance(y_test, pd.Series):
            y_test = y_test.values

        # Use the standalone evaluate_model function with error handling
        with handle_errors("model evaluation", {ValueError: EvaluationError, RuntimeError: EvaluationError}):
            from .evaluator import evaluate_model
            results = evaluate_model(
                model=self.best_model,
                X_test=X_test,
                y_test=y_test,
                task_type=self.config.task_type
            )

        if verbose:
            print("\n" + "=" * 70)
            print("EVALUATION RESULTS")
            print("=" * 70)
            for metric, value in results.items():
                if isinstance(value, (int, float)):
                    print(f"  {metric}: {value:.4f}")
                else:
                    print(f"  {metric}: {value}")
            print("=" * 70)

        return results

    def explain(
        self,
        X: Optional[Union[np.ndarray, pd.DataFrame]] = None,
        sample_idx: int = 0
    ) -> Dict[str, Any]:
        """
        Generate SHAP explanations for preprocessed data.

        Note:
            Data must be preprocessed the same way as training data.
        """
        validate_and_raise(
            self.explainer is not None,
            ExplanationError,
            "Explainer not initialized. Fit model with enable_shap=True first.",
            details={"operation": "explain"}
        )

        if X is not None:
            # Convert to numpy if needed
            if isinstance(X, pd.DataFrame):
                X = X.values

        with handle_errors("SHAP explanation generation", {ValueError: ExplanationError, RuntimeError: ExplanationError}):
            return self.explainer.explain(X, sample_idx)

    def get_feature_importance(self, top_n: int = 10) -> pd.DataFrame:
        """Get feature importance from model."""
        if self.best_model is None:
            raise ModelNotTrainedError("get_feature_importance")

        try:
            importances = self.best_model.feature_importances_
        except AttributeError:
            try:
                importances = np.abs(self.best_model.coef_).flatten()
            except AttributeError:
                raise ConfigurationError(
                    "Model does not support feature importance",
                    details={"model_type": type(self.best_model).__name__}
                )

        importance_df = pd.DataFrame({
            'feature': self.feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False).head(top_n)

        return importance_df

    def save_model(self, name: Optional[str] = None) -> str:
        """
        Save model with preprocessing pipeline.

        Args:
            name: Model name

        Returns:
            model_id
        """
        if self.best_model is None:
            raise ModelNotTrainedError("save_model")

        # Helper function to convert numpy arrays to lists for JSON serialization
        def make_json_serializable(obj):
            """Convert numpy arrays and other non-serializable types to JSON-compatible types."""
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, dict):
                return {key: make_json_serializable(value) for key, value in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [make_json_serializable(item) for item in obj]
            else:
                return obj

        metadata = {
            "model_name": self.results.get('best_model_name', 'unknown'),
            "task_type": str(self.config.task_type),
            "best_params": make_json_serializable(self.results.get('best_params', {})),
            "cv_score": float(self.results.get('best_cv_score')) if self.results.get('best_cv_score') is not None else None,
            "feature_names": make_json_serializable(self.feature_names) if self.feature_names is not None else None,
            "original_feature_names": make_json_serializable(self.original_feature_names) if self.original_feature_names is not None else None,
            "metrics": make_json_serializable(self.results.get('validation', {}))
        }

        with handle_errors("model saving", {IOError: RegistryError, OSError: RegistryError}):
            model_id = self.registry.save_model(
                model=self.best_model,
                metadata=metadata,
                model_name=name
            )

        return model_id

    def load_model(self, model_id: str) -> 'FDEAutoML':
        """
        Load saved model.

        Args:
            model_id: Model ID

        Returns:
            self
        """
        with handle_errors("model loading", {IOError: RegistryError, OSError: RegistryError, FileNotFoundError: RegistryError}):
            self.best_model = self.registry.load_model(model_id)
            metadata = self.registry.get_model_metadata(model_id)

            self.feature_names = metadata.get('feature_names')
            self.original_feature_names = metadata.get('original_feature_names', self.feature_names)
            self.results['best_model_name'] = metadata.get('model_name')
            self.results['best_params'] = metadata.get('best_params', {})
            self.results['best_cv_score'] = metadata.get('cv_score')

            print(f"\n✓ Model loaded: {metadata.get('model_name')}")

        return self

    def get_results(self) -> Dict[str, Any]:
        """Get all training results."""
        return self.results

    def summary(self) -> str:
        """Get formatted summary."""
        if not self.results:
            return "No model trained yet."

        lines = []
        lines.append("="*70)
        lines.append("AUTOML SUMMARY")
        lines.append("="*70)
        lines.append(f"Best Model: {self.results.get('best_model_name', 'N/A')}")
        lines.append(f"CV Score: {self.results.get('best_cv_score', 0):.4f}")
        lines.append("="*70)

        return "\n".join(lines)
