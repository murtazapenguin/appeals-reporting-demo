"""
Configuration Module for AutoML_test
=====================================

This module defines Pydantic models for validating user configurations.
It ensures type safety, provides sensible defaults, and catches errors early.

Key Classes:
- TaskType: Enum for classification/regression tasks
- MetricType: Enum for supported metrics
- ModelType: Enum for supported models
- OptunaConfig: Configuration for Optuna hyperparameter optimization
- AutoMLConfig: Main configuration class tying everything together
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict


class TaskType(str, Enum):
    """
    Supported ML task types.

    - CLASSIFICATION: Binary or multi-class classification
    - REGRESSION: Continuous value prediction
    """
    CLASSIFICATION = "classification"
    REGRESSION = "regression"


class MetricType(str, Enum):
    """
    Supported evaluation metrics.

    Classification metrics:
    - PRECISION: True Positives / (True Positives + False Positives)
    - RECALL: True Positives / (True Positives + False Negatives)
    - F1: Harmonic mean of Precision and Recall
    - F1_WEIGHTED: F1 score with weighted averaging (by support)
    - F1_MACRO: F1 score with macro averaging (unweighted mean)
    - F1_MICRO: F1 score with micro averaging (global)
    - PRECISION_WEIGHTED: Precision with weighted averaging
    - PRECISION_MACRO: Precision with macro averaging
    - RECALL_WEIGHTED: Recall with weighted averaging
    - RECALL_MACRO: Recall with macro averaging
    - AUC: Area Under the ROC Curve
    - ACCURACY: Correct predictions / Total predictions

    Regression metrics:
    - MSE: Mean Squared Error
    - MAE: Mean Absolute Error
    - RMSE: Root Mean Squared Error
    - R2: R-squared score
    """
    # Classification metrics - basic
    PRECISION = "precision"
    RECALL = "recall"
    F1 = "f1"
    AUC = "auc"
    ACCURACY = "accuracy"

    # Classification metrics - weighted/macro/micro variants
    F1_WEIGHTED = "f1_weighted"
    F1_MACRO = "f1_macro"
    F1_MICRO = "f1_micro"
    PRECISION_WEIGHTED = "precision_weighted"
    PRECISION_MACRO = "precision_macro"
    RECALL_WEIGHTED = "recall_weighted"
    RECALL_MACRO = "recall_macro"

    # Regression metrics
    MSE = "mse"
    MAE = "mae"
    RMSE = "rmse"
    R2 = "r2"


class ModelType(str, Enum):
    """
    Supported model types.

    Tree-based models:
    - RANDOM_FOREST: Ensemble of decision trees
    - XGBOOST: Gradient boosting framework
    - LIGHTGBM: Light Gradient Boosting Machine
    - CATBOOST: Categorical boosting

    Linear models:
    - LINEAR_REGRESSION: Ordinary least squares regression
    - LOGISTIC_REGRESSION: Logistic regression for classification
    - RIDGE: Ridge regression (L2 regularization)
    - LASSO: Lasso regression (L1 regularization)

    Support Vector Machines:
    - SVM: Support Vector Machine

    Other:
    - KNN: K-Nearest Neighbors
    - DECISION_TREE: Single decision tree
    """
    # Tree-based models
    RANDOM_FOREST = "random_forest"
    XGBOOST = "xgboost"
    LIGHTGBM = "lightgbm"
    CATBOOST = "catboost"

    # Linear models
    LINEAR_REGRESSION = "linear_regression"
    LOGISTIC_REGRESSION = "logistic_regression"
    RIDGE = "ridge"
    LASSO = "lasso"

    # SVM
    SVM = "svm"

    # Other
    KNN = "knn"
    DECISION_TREE = "decision_tree"


class OptunaConfig(BaseModel):
    """
    Configuration for Optuna hyperparameter optimization.

    Attributes:
        n_trials: Number of optimization trials to run
        timeout: Maximum time (seconds) for optimization (None = no limit)
        n_jobs: Number of parallel jobs (-1 = use all processors)
        cv_folds: Number of cross-validation folds
        direction: Optimization direction ('maximize' or 'minimize')
        sampler: Optuna sampler type ('tpe', 'random', 'grid')
        show_progress_bar: Whether to display progress bar
        verbosity: Optuna logging verbosity (0=silent, 1=info, 2=debug)
    """
    n_trials: int = Field(default=50, ge=1, description="Number of optimization trials")
    timeout: Optional[int] = Field(default=None, ge=1, description="Timeout in seconds")
    n_jobs: int = Field(default=1, ge=-1, description="Number of parallel jobs")
    cv_folds: int = Field(default=5, ge=2, le=10, description="Cross-validation folds")
    direction: str = Field(default="maximize", description="Optimization direction")
    sampler: str = Field(default="tpe", description="Optuna sampler type")
    show_progress_bar: bool = Field(default=True, description="Show progress bar")
    verbosity: int = Field(default=1, ge=0, le=2, description="Logging verbosity")

    @field_validator("direction")
    @classmethod
    def validate_direction(cls, v):
        """Ensure direction is either 'maximize' or 'minimize'."""
        if v not in ["maximize", "minimize"]:
            raise ValueError("direction must be 'maximize' or 'minimize'")
        return v

    @field_validator("sampler")
    @classmethod
    def validate_sampler(cls, v):
        """Ensure sampler is supported."""
        if v not in ["tpe", "random", "grid"]:
            raise ValueError("sampler must be 'tpe', 'random', or 'grid'")
        return v


class AutoMLConfig(BaseModel):
    """
    Main configuration class for AutoML_test.

    This class validates and stores all configuration parameters needed
    for the AutoML pipeline.

    Attributes:
        task_type: Type of ML task (classification or regression)
        models: List of model types to try
        primary_metric: Primary metric to optimize
        secondary_metrics: Additional metrics to track
        optuna_config: Optuna optimization settings
        random_state: Random seed for reproducibility
        test_size: Proportion of data for testing (0.0 to 1.0)
        enable_shap: Whether to generate SHAP explanations
        model_registry_path: Path to save/load models
        custom_params: Custom parameters for specific models

    Example:
        >>> config = AutoMLConfig(
        ...     task_type=TaskType.CLASSIFICATION,
        ...     models=[ModelType.RANDOM_FOREST, ModelType.XGBOOST],
        ...     primary_metric=MetricType.AUC
        ... )
    """
    task_type: TaskType = Field(..., description="ML task type")
    models: List[ModelType] = Field(
        default=[ModelType.RANDOM_FOREST, ModelType.XGBOOST],
        min_length=1,
        description="List of models to try"
    )
    primary_metric: MetricType = Field(..., description="Primary metric to optimize")
    secondary_metrics: List[MetricType] = Field(
        default_factory=list,
        description="Additional metrics to track"
    )
    optuna_config: OptunaConfig = Field(
        default_factory=OptunaConfig,
        description="Optuna optimization settings"
    )
    random_state: int = Field(default=42, description="Random seed for reproducibility")
    test_size: float = Field(
        default=0.2,
        ge=0.0,
        le=1.0,
        description="Test set proportion"
    )
    enable_shap: bool = Field(default=True, description="Enable SHAP explanations")
    model_registry_path: str = Field(
        default="./model_registry",
        description="Path to model registry"
    )
    custom_params: Dict[str, Any] = Field(
        default_factory=dict,
        description="Custom parameters for specific models"
    )

    @field_validator("models")
    @classmethod
    def validate_models_not_empty(cls, v):
        """Ensure at least one model is specified."""
        if not v:
            raise ValueError("At least one model must be specified")
        return v

    @model_validator(mode='after')
    def validate_metrics_for_task(self):
        """
        Ensure metrics are appropriate for the task type.

        Classification tasks should use classification metrics.
        Regression tasks should use regression metrics.
        """
        task_type = self.task_type
        primary_metric = self.primary_metric
        secondary_metrics = self.secondary_metrics

        classification_metrics = {
            MetricType.PRECISION, MetricType.RECALL,
            MetricType.F1, MetricType.AUC, MetricType.ACCURACY,
            MetricType.F1_WEIGHTED, MetricType.F1_MACRO, MetricType.F1_MICRO,
            MetricType.PRECISION_WEIGHTED, MetricType.PRECISION_MACRO,
            MetricType.RECALL_WEIGHTED, MetricType.RECALL_MACRO
        }
        regression_metrics = {
            MetricType.MSE, MetricType.MAE,
            MetricType.RMSE, MetricType.R2
        }

        all_metrics = [primary_metric] + secondary_metrics

        if task_type == TaskType.CLASSIFICATION:
            invalid = [m for m in all_metrics if m in regression_metrics]
            if invalid:
                raise ValueError(
                    f"Invalid metrics for classification: {invalid}. "
                    f"Use classification metrics: {classification_metrics}"
                )
        elif task_type == TaskType.REGRESSION:
            invalid = [m for m in all_metrics if m in classification_metrics]
            if invalid:
                raise ValueError(
                    f"Invalid metrics for regression: {invalid}. "
                    f"Use regression metrics: {regression_metrics}"
                )

        return self

    @model_validator(mode='after')
    def validate_models_for_task(self):
        """
        Ensure models are appropriate for the task type.

        Linear regression models should only be used for regression tasks.
        Logistic regression should only be used for classification tasks.
        """
        task_type = self.task_type
        models = self.models

        if task_type == TaskType.CLASSIFICATION:
            if ModelType.LINEAR_REGRESSION in models:
                raise ValueError(
                    "linear_regression cannot be used for classification tasks. "
                    "Use logistic_regression instead."
                )
        elif task_type == TaskType.REGRESSION:
            if ModelType.LOGISTIC_REGRESSION in models:
                raise ValueError(
                    "logistic_regression cannot be used for regression tasks. "
                    "Use linear_regression instead."
                )

        return self

    model_config = ConfigDict(
        use_enum_values=True,
        validate_assignment=True,
        extra="forbid"  # Raise error if unknown fields are passed
    )


# Helper function to create a quick config
def create_quick_config(
    task: str,
    models: Optional[List[str]] = None,
    metric: Optional[str] = None,
    n_trials: int = 50
) -> AutoMLConfig:
    """
    Convenience function to create a config with minimal boilerplate.

    Args:
        task: 'classification' or 'regression'
        models: List of model names (default: random_forest, xgboost)
        metric: Primary metric (default: 'auc' for classification, 'mse' for regression)
        n_trials: Number of Optuna trials

    Returns:
        AutoMLConfig instance

    Example:
        >>> config = create_quick_config('classification', metric='auc')
        >>> config = create_quick_config('regression', models=['xgboost'], n_trials=100)
    """
    task_type = TaskType(task)

    # Set default models if not provided
    if models is None:
        models = ["random_forest", "xgboost"]
    model_types = [ModelType(m) for m in models]

    # Set default metric if not provided
    if metric is None:
        metric = "auc" if task_type == TaskType.CLASSIFICATION else "mse"
    metric_type = MetricType(metric)

    # Set optimization direction based on metric
    maximize_metrics = [
        "auc", "precision", "recall", "f1", "accuracy", "r2",
        "f1_weighted", "f1_macro", "f1_micro",
        "precision_weighted", "precision_macro",
        "recall_weighted", "recall_macro"
    ]
    direction = "maximize" if metric in maximize_metrics else "minimize"

    return AutoMLConfig(
        task_type=task_type,
        models=model_types,
        primary_metric=metric_type,
        optuna_config=OptunaConfig(n_trials=n_trials, direction=direction)
    )


if __name__ == "__main__":
    # Example usage and testing
    print("=" * 60)
    print("AutoML_test Configuration Examples")
    print("=" * 60)

    # Example 1: Classification config
    print("\n1. Classification Config:")
    config_cls = AutoMLConfig(
        task_type=TaskType.CLASSIFICATION,
        models=[ModelType.RANDOM_FOREST, ModelType.XGBOOST, ModelType.LOGISTIC_REGRESSION],
        primary_metric=MetricType.AUC,
        secondary_metrics=[MetricType.PRECISION, MetricType.RECALL]
    )
    print(f"   Task: {config_cls.task_type}")
    print(f"   Models: {config_cls.models}")
    print(f"   Primary Metric: {config_cls.primary_metric}")
    print(f"   Optuna Trials: {config_cls.optuna_config.n_trials}")

    # Example 2: Regression config
    print("\n2. Regression Config:")
    config_reg = AutoMLConfig(
        task_type=TaskType.REGRESSION,
        models=[ModelType.XGBOOST, ModelType.LINEAR_REGRESSION],
        primary_metric=MetricType.MSE,
        secondary_metrics=[MetricType.MAE, MetricType.R2]
    )
    print(f"   Task: {config_reg.task_type}")
    print(f"   Models: {config_reg.models}")
    print(f"   Primary Metric: {config_reg.primary_metric}")

    # Example 3: Quick config
    print("\n3. Quick Config (Classification):")
    config_quick = create_quick_config("classification", metric="f1", n_trials=30)
    print(f"   Task: {config_quick.task_type}")
    print(f"   Models: {config_quick.models}")
    print(f"   Primary Metric: {config_quick.primary_metric}")

    # Example 4: Error handling - Invalid metric for task
    print("\n4. Error Handling Example:")
    try:
        invalid_config = AutoMLConfig(
            task_type=TaskType.CLASSIFICATION,
            models=[ModelType.RANDOM_FOREST],
            primary_metric=MetricType.MSE  # MSE is for regression!
        )
    except ValueError as e:
        print(f"   ✓ Caught error: {str(e)[:80]}...")

    print("\n" + "=" * 60)
    print("Configuration module working correctly!")
    print("=" * 60)
