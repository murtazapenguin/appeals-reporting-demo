"""
Penguin Embeddings Base Module

Abstract base class for all embedding provider implementations.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from .types import EmbeddingResult, ProviderCapabilities


class BaseEmbeddingProvider(ABC):
    """
    Abstract base class for embedding provider implementations.

    Provides unified interface for different embedding providers
    while abstracting away provider-specific API differences.
    """

    def __init__(
        self,
        model: str,
        dimensions: int = 1024,
        **kwargs: Any
    ):
        """
        Initialize the embedding provider.

        Args:
            model: Model identifier (e.g., "amazon.titan-embed-text-v2:0")
            dimensions: Embedding dimensions (256, 512, or 1024)
            **kwargs: Provider-specific configuration
        """
        self.model = model
        self.dimensions = dimensions
        self.config = kwargs

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider name (e.g., 'bedrock')."""
        pass

    @property
    @abstractmethod
    def capabilities(self) -> ProviderCapabilities:
        """Return provider capabilities."""
        pass

    @abstractmethod
    async def embed(
        self,
        text: str,
        **kwargs: Any
    ) -> EmbeddingResult:
        """
        Generate embedding for a single text.

        Args:
            text: Input text to embed
            **kwargs: Additional parameters

        Returns:
            EmbeddingResult with vector and usage info
        """
        pass

    @abstractmethod
    async def embed_batch(
        self,
        texts: List[str],
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """
        Generate embeddings for multiple texts.

        Args:
            texts: List of input texts
            **kwargs: Additional parameters

        Returns:
            List of EmbeddingResult objects
        """
        pass

    async def embed_documents(
        self,
        documents: List[Dict[str, Any]],
        text_field: str = "content",
        id_field: Optional[str] = "id",
        include_text: bool = True,
        **kwargs: Any
    ) -> List[EmbeddingResult]:
        """
        Generate embeddings for documents with metadata.

        IMPROVED: Now preserves document IDs and optionally includes text.

        Args:
            documents: List of document dicts with structure:
                {
                    "id": "unique_id",           # Required if id_field specified
                    "content": "text to embed",  # Field name configurable via text_field
                    "source": "file.pdf",        # Any additional fields become metadata
                    "page": 1,
                    ...
                }
            text_field: Field containing text to embed (default: "content")
            id_field: Field containing document ID (default: "id", None to skip)
            include_text: Include original text in result.input_text (default: True)
            **kwargs: Additional parameters

        Returns:
            List of EmbeddingResult objects with:
                - embedding: The vector
                - input_text: Original text (if include_text=True)
                - metadata: All fields except text_field, with document_id added

        Example:
            documents = [
                {
                    "id": "doc1_chunk0",
                    "content": "Text to embed",
                    "source": "file.pdf",
                    "page": 1,
                    "chunk_index": 0
                }
            ]
            results = await client.embed_documents(documents)
            # result.metadata = {"document_id": "doc1_chunk0", "source": "file.pdf", "page": 1, "chunk_index": 0}
        """
        results = []
        for doc in documents:
            text = doc.get(text_field, "")

            # Embed the text
            result = await self.embed(
                text,
                include_text=include_text,
                **kwargs
            )

            # Preserve document metadata (all fields except text_field)
            metadata = {k: v for k, v in doc.items() if k != text_field}

            # Add document_id if id_field specified
            if id_field and id_field in doc:
                metadata["document_id"] = doc[id_field]

            result.metadata = metadata
            results.append(result)
        return results

    async def embed_document_chunks(
        self,
        chunks: List["DocumentChunk"],
        include_text: bool = True,
        **kwargs: Any
    ) -> List["EmbeddedDocument"]:
        """
        Generate embeddings for structured DocumentChunk objects.

        This is the RECOMMENDED method for embedding documents.

        Args:
            chunks: List of DocumentChunk objects (from document_models.py)
            include_text: Include original text in result
            **kwargs: Additional parameters

        Returns:
            List of EmbeddedDocument objects ready for vector storage

        Example:
            from penguin.embeddings.document_models import DocumentChunk

            chunks = [
                DocumentChunk(
                    id="doc1_chunk0",
                    content="Text to embed",
                    source="file.pdf",
                    page=1,
                    chunk_index=0
                )
            ]

            embedded_docs = await client.embed_document_chunks(chunks)

            # Convert to VectorRecords for storage
            vectors = [ed.to_vector_record() for ed in embedded_docs]
            await vector_client.put_vectors("index", vectors)
        """
        # Import here to avoid circular dependency
        from .document_models import EmbeddedDocument

        results = []
        for chunk in chunks:
            # Embed the chunk content
            emb_result = await self.embed(
                chunk.content,
                include_text=include_text,
                **kwargs
            )

            # Create EmbeddedDocument
            embedded_doc = EmbeddedDocument(
                chunk=chunk,
                embedding=emb_result.embedding,
                dimensions=emb_result.dimensions,
                model=emb_result.model,
                provider=emb_result.provider
            )
            results.append(embedded_doc)

        return results


# ================== EXCEPTIONS ==================

class EmbeddingError(Exception):
    """Base exception for embedding errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        status_code: Optional[int] = None,
    ):
        self.provider = provider
        self.status_code = status_code
        super().__init__(message)


class RateLimitError(EmbeddingError):
    """Rate limit exceeded."""
    pass


class AuthenticationError(EmbeddingError):
    """Authentication failed."""
    pass


class InvalidRequestError(EmbeddingError):
    """Invalid request parameters."""
    pass
