"""
Penguin Embeddings Types Module

Defines standardized types for embedding operations.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class EmbeddingUsage(BaseModel):
    """Token usage for embedding operations."""
    input_tokens: int = 0
    total_tokens: int = 0

    def __add__(self, other: "EmbeddingUsage") -> "EmbeddingUsage":
        return EmbeddingUsage(
            input_tokens=self.input_tokens + other.input_tokens,
            total_tokens=self.total_tokens + other.total_tokens,
        )


class EmbeddingResult(BaseModel):
    """
    Result from an embedding operation.
    """
    # The embedding vector
    embedding: List[float]

    # Dimensions of the embedding
    dimensions: int

    # Original input text (optional, for tracking)
    input_text: Optional[str] = None

    # Token usage
    usage: EmbeddingUsage = Field(default_factory=EmbeddingUsage)

    # Provider info
    model: str
    provider: str

    # Optional metadata (preserved from documents)
    metadata: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True


class ProviderCapabilities(BaseModel):
    """Declares what an embedding provider supports."""
    supported_dimensions: List[int] = [256, 512, 1024]
    max_batch_size: int = 100
    max_text_length: int = 8192
    supports_documents: bool = True


class EmbeddingConfig(BaseModel):
    """Configuration for embedding requests."""
    dimensions: int = 1024
    normalize: bool = True
