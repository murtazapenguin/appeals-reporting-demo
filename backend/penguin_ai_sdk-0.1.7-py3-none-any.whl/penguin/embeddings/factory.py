"""
Penguin Embeddings Factory Module

Factory functions for creating embedding clients with provider auto-detection.
"""

import os
from typing import Optional, Union

from .base import BaseEmbeddingProvider
from .middleware import MiddlewareWrappedEmbeddingClient


# Provider registry - lazy imports to avoid loading all dependencies
PROVIDER_CLASSES = {
    "bedrock": ("penguin.embeddings.providers.bedrock", "BedrockTitanEmbeddingClient"),
    "sentence_transformers": ("penguin.embeddings.providers.sentence_transformers", "SentenceTransformerEmbeddingClient"),
    "local": ("penguin.embeddings.providers.sentence_transformers", "SentenceTransformerEmbeddingClient"),  # Alias for local/finetuned models
}

# Default models per provider
DEFAULT_MODELS = {
    "bedrock": "amazon.titan-embed-text-v2:0",
    "sentence_transformers": "BAAI/bge-m3",
    "local": None,  # Must specify model path for local models
}


def _import_provider_class(provider: str) -> type:
    """Dynamically import provider class to avoid loading all dependencies."""
    if provider not in PROVIDER_CLASSES:
        raise ValueError(
            f"Unknown provider: {provider}. "
            f"Available providers: {', '.join(PROVIDER_CLASSES.keys())}"
        )

    module_path, class_name = PROVIDER_CLASSES[provider]

    import importlib
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def create_embedding_client(
    provider: str = "bedrock",
    model: Optional[str] = None,
    dimensions: Optional[int] = None,
    enable_tracing: Optional[bool] = None,
    **kwargs
) -> Union[BaseEmbeddingProvider, MiddlewareWrappedEmbeddingClient]:
    """
    Create an embedding client for the specified provider.

    Args:
        provider: Provider name ("bedrock", "sentence_transformers", "local")
        model: Model identifier (uses default if not specified)
        dimensions: Embedding dimensions (auto-detected for sentence_transformers)
        enable_tracing: Override tracing (None = use env var)
        **kwargs: Provider-specific configuration

    Returns:
        Configured embedding client

    Example:
        # Create Bedrock Titan client
        client = create_embedding_client("bedrock", dimensions=512)
        result = await client.embed("Hello world")

        # Open-source model via sentence-transformers
        client = create_embedding_client("sentence_transformers", model="bge-m3")
        result = await client.embed("Hello world")

        # Local/finetuned model
        client = create_embedding_client("local", model="./my_finetuned_model")

        # Query embedding (for asymmetric retrieval)
        result = await client.embed_query("What is machine learning?")
    """
    from .models import get_model, resolve_model_id

    provider = provider.lower()

    if model is None:
        model = DEFAULT_MODELS.get(provider)
        if model is None and provider == "local":
            raise ValueError(
                "Model path is required for 'local' provider. "
                "Example: create_embedding_client('local', model='./my_model')"
            )

    # Resolve friendly model names to HuggingFace IDs (except for local paths)
    if provider != "local" and model and not model.startswith(("./", "/", "~")):
        model_info = get_model(model)
        if model_info:
            model = model_info.api_id

    client_class = _import_provider_class(provider)

    # Build kwargs for client - only pass dimensions if specified
    client_kwargs = {"model": model, **kwargs}
    if dimensions is not None:
        client_kwargs["dimensions"] = dimensions

    client = client_class(**client_kwargs)

    # Determine if tracing is enabled
    if enable_tracing is None:
        from penguin.observability.config import is_tracing_enabled
        tracing = is_tracing_enabled()
    else:
        tracing = enable_tracing

    # Wrap with middleware if tracing enabled
    if tracing:
        from penguin.observability import setup_tracing
        setup_tracing()
        from .middleware import get_embedding_middleware_chain
        chain = get_embedding_middleware_chain()
        return MiddlewareWrappedEmbeddingClient(client, chain)

    return client


def create_embedding_client_from_env(
    dimensions: int = 1024,
    enable_tracing: Optional[bool] = None,
    **kwargs
) -> Union[BaseEmbeddingProvider, MiddlewareWrappedEmbeddingClient]:
    """
    Create an embedding client using environment variables for configuration.

    Checks for AWS credentials to determine provider.

    Args:
        dimensions: Embedding dimensions
        enable_tracing: Override tracing
        **kwargs: Additional configuration

    Returns:
        Configured embedding client
    """
    # Check for AWS credentials
    if any([
        os.environ.get("AWS_ACCESS_KEY_ID"),
        os.environ.get("AWS_PROFILE"),
        os.environ.get("AWS_ROLE_ARN"),
    ]):
        return create_embedding_client(
            "bedrock",
            dimensions=dimensions,
            enable_tracing=enable_tracing,
            **kwargs
        )

    raise ValueError(
        "No embedding provider credentials found. "
        "Set AWS credentials for Bedrock."
    )
