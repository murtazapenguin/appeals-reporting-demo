"""
Penguin Evals Models

Data models for LLM-based evaluation results.
"""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class EvalCase(BaseModel):
    """Single input-output pair for evaluation."""
    row_index: int
    input_text: str
    actual_output: str
    expected_output: Optional[str] = None  # Reference answer (optional)
    context: Optional[str] = None          # Additional context
    metadata: Dict[str, Any] = Field(default_factory=dict)


class EvalCriteriaResult(BaseModel):
    """Result of evaluating one criteria on one row."""
    criteria_name: str
    row_index: int
    passed: bool       # TRUE/FALSE only (no scores - LLMs unreliable with numeric scores)
    reason: str        # Explanation for pass/fail


class CriteriaSummary(BaseModel):
    """Summary statistics for a single criteria."""
    criteria_name: str
    total_evaluated: int
    passed_count: int
    failed_count: int
    pass_rate: float   # passed_count / total_evaluated


class EvalReport(BaseModel):
    """Complete evaluation report with trace ID for retrieval."""
    trace_id: str              # UUID to retrieve traces later
    task_name: str
    total_rows: int
    criteria_evaluated: List[str]
    criteria_summaries: Dict[str, CriteriaSummary]
    row_results: List[Dict[str, EvalCriteriaResult]]
    overall_pass_rate: float   # Average of all criteria pass_rates
    overall_passed: bool       # True if overall_pass_rate >= threshold


# ============================================================================
# Batch Evaluation Models (for multi-criteria per call)
# ============================================================================

class BatchEvalResult(BaseModel):
    """Single result within a batch evaluation response."""
    rule_index: int     # 0-based index of the criteria in the batch
    passed: bool
    reason: str


class BatchEvalResponse(BaseModel):
    """Schema for LLM batch evaluation response (multiple criteria, one row)."""
    evaluations: List[BatchEvalResult]
