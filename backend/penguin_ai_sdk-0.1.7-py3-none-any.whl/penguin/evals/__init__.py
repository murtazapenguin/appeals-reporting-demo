"""
Penguin Evals Module

Evaluate AI outputs against custom criteria using LLM-as-judge.

Example:
    ```python
    from penguin.llm import create_client
    from penguin.evals import EvalRunner

    client = create_client("bedrock", model="claude-sonnet-4-5")
    runner = EvalRunner(client, max_concurrency=5)

    criteria = [
        "Output must be factually accurate",
        "Output must be relevant to the question",
    ]

    report = await runner.evaluate(
        df=my_dataframe,
        criteria=criteria,
        task_name="QA Evaluation"
    )

    print(f"Trace ID: {report.trace_id}")
    print(f"Pass Rate: {report.overall_pass_rate:.1%}")

    # Retrieve traces later
    traces = EvalRunner.get_traces(report.trace_id)
    ```
"""

from .eval_models import (
    EvalCase,
    EvalCriteriaResult,
    EvalReport,
    CriteriaSummary,
)
from .eval_runner import EvalRunner

__all__ = [
    "EvalRunner",
    "EvalCase",
    "EvalCriteriaResult",
    "EvalReport",
    "CriteriaSummary",
]
