"""
Penguin Evals Runner

Main orchestrator for LLM-based evaluation on input-output pairs.
"""

import asyncio
import logging
import uuid
from typing import Dict, List, Optional, Any

import pandas as pd

from ..llm.base import BaseChatCompletionClient
from ..llm.messages import SystemMessage, UserMessage
from ..observability import (
    get_exporter,
    set_trace_context,
    reset_context,
    get_tracer,
)
from ..observability.attributes import GenAIAttributes

from .eval_models import (
    EvalCase,
    EvalCriteriaResult,
    EvalReport,
    CriteriaSummary,
    BatchEvalResponse,
)

logger = logging.getLogger("penguin.evals")


class EvalRunner:
    """
    Main orchestrator for LLM-based evaluation.

    Evaluates input-output pairs against custom criteria using LLM-as-judge.
    Each evaluation is traced and can be retrieved later using the trace_id.

    Example:
        ```python
        from penguin.llm import create_client
        from penguin.evals import EvalRunner

        client = create_client("bedrock", model="claude-sonnet-4-5")
        runner = EvalRunner(client, max_concurrency=5)

        criteria = [
            "Output must be factually accurate given the context",
            "Output must directly answer the question asked",
        ]

        report = await runner.evaluate(
            df=my_dataframe,
            criteria=criteria,
            task_name="QA Bot Evaluation",
            input_col="question",
            output_col="answer",
            expected_col="reference_answer",
            context_col="source_text"
        )

        print(f"Trace ID: {report.trace_id}")
        print(f"Pass Rate: {report.overall_pass_rate:.1%}")
        ```
    """

    def __init__(
        self,
        client: BaseChatCompletionClient,
        max_concurrency: int = 5
    ):
        """
        Initialize the evaluation runner.

        Args:
            client: LLM client for evaluation (any provider via BaseChatCompletionClient)
            max_concurrency: Maximum concurrent LLM evaluations (default: 5)
        """
        self.client = client
        self.semaphore = asyncio.Semaphore(max_concurrency)
        self.max_concurrency = max_concurrency

    def _df_to_cases(
        self,
        df: pd.DataFrame,
        input_col: str,
        output_col: str,
        expected_col: Optional[str] = None,
        context_col: Optional[str] = None
    ) -> List[EvalCase]:
        """Convert DataFrame rows to EvalCase objects."""
        cases = []
        for idx, row in df.iterrows():
            input_text = str(row.get(input_col, "")) if pd.notna(row.get(input_col)) else ""
            actual_output = str(row.get(output_col, "")) if pd.notna(row.get(output_col)) else ""

            expected_output = None
            if expected_col and expected_col in row:
                expected_output = str(row.get(expected_col, "")) if pd.notna(row.get(expected_col)) else None

            context = None
            if context_col and context_col in row:
                context = str(row.get(context_col, "")) if pd.notna(row.get(context_col)) else None

            case = EvalCase(
                row_index=int(idx),
                input_text=input_text,
                actual_output=actual_output,
                expected_output=expected_output,
                context=context
            )
            cases.append(case)
        return cases

    async def _evaluate_batch(
        self,
        criteria_list: List[str],
        case: EvalCase,
        task_name: str,
        use_thinking: bool = True
    ) -> List[EvalCriteriaResult]:
        """
        Evaluate multiple criteria on one case in a single LLM call.

        Args:
            criteria_list: List of criteria descriptions (up to 10)
            case: The input-output pair to evaluate
            task_name: Name/description of the task
            use_thinking: Whether to enable thinking mode (default: True)

        Returns:
            List of EvalCriteriaResult, one per criteria
        """
        async with self.semaphore:
            # Build numbered criteria list for prompt
            criteria_text = "\n".join(
                f"[{i}] {crit}" for i, crit in enumerate(criteria_list)
            )

            system_content = f"""You are an evaluator for: {task_name}

You will evaluate the OUTPUT against MULTIPLE CRITERIA.
For EACH criteria, determine if it passes or fails.

Think through each criteria carefully before making a decision.
Return your evaluation for ALL criteria in the specified JSON format."""

            user_content = f"""CRITERIA TO EVALUATE:
{criteria_text}

INPUT: {case.input_text}

OUTPUT: {case.actual_output}"""

            if case.expected_output:
                user_content += f"\n\nEXPECTED: {case.expected_output}"

            if case.context:
                user_content += f"\n\nCONTEXT: {case.context}"

            user_content += """

Evaluate the OUTPUT against EACH criteria above.
Return JSON with an evaluation for each criteria by its index (0-based)."""

            messages = [
                SystemMessage(system_content),
                UserMessage(user_content)
            ]

            try:
                # Build request kwargs
                request_kwargs = {
                    "messages": messages,
                    "output_format": BatchEvalResponse,
                    "temperature": 0.0,
                }

                # Enable thinking if supported and requested
                if use_thinking and self.client.capabilities.supports_thinking:
                    request_kwargs["thinking"] = True

                response = await self.client.create(**request_kwargs)

                # Log thinking if available
                if hasattr(response, 'thinking') and response.thinking:
                    logger.debug(f"Thinking (row {case.row_index}): {response.thinking[:200]}...")

                # Parse response
                content = response.content
                results = []

                if isinstance(content, dict):
                    evaluations = content.get("evaluations", [])
                else:
                    # Try to parse string as JSON
                    import json
                    try:
                        parsed = json.loads(str(content))
                        evaluations = parsed.get("evaluations", [])
                    except (json.JSONDecodeError, TypeError):
                        # Return all as failed if parse error
                        return [
                            EvalCriteriaResult(
                                criteria_name=crit[:100],
                                row_index=case.row_index,
                                passed=False,
                                reason=f"Parse error: {str(content)[:100]}"
                            )
                            for crit in criteria_list
                        ]

                # Map evaluations back to criteria
                eval_by_index = {e.get("rule_index", i): e for i, e in enumerate(evaluations)}

                for i, crit in enumerate(criteria_list):
                    eval_data = eval_by_index.get(i, {})
                    results.append(EvalCriteriaResult(
                        criteria_name=crit[:100],
                        row_index=case.row_index,
                        passed=bool(eval_data.get("passed", False)),
                        reason=str(eval_data.get("reason", "No reason provided"))
                    ))

                return results

            except Exception as e:
                logger.error(f"Error batch evaluating on row {case.row_index}: {e}")
                return [
                    EvalCriteriaResult(
                        criteria_name=crit[:100],
                        row_index=case.row_index,
                        passed=False,
                        reason=f"Evaluation error: {str(e)}"
                    )
                    for crit in criteria_list
                ]

    async def evaluate(
        self,
        df: pd.DataFrame,
        criteria: List[str],
        task_name: str,
        input_col: str = "input",
        output_col: str = "output",
        expected_col: Optional[str] = None,
        context_col: Optional[str] = None,
        threshold: float = 0.7,
        batch_size: int = 10,
        use_thinking: bool = True
    ) -> EvalReport:
        """
        Evaluate criteria on input-output pairs.

        Args:
            df: DataFrame with input-output pairs
            criteria: List of criteria description strings
            task_name: Description of the task being evaluated
            input_col: Column name for input/question (default: "input")
            output_col: Column name for actual output/answer (default: "output")
            expected_col: Optional column name for reference/expected answer
            context_col: Optional column name for additional context
            threshold: Pass/fail threshold for overall_passed (default: 0.7)
            batch_size: Max criteria to evaluate per LLM call (default: 10)
            use_thinking: Enable thinking mode for supported models (default: True)

        Returns:
            EvalReport with trace_id for later retrieval
        """
        tracer = get_tracer("penguin.evals")

        # Initialize trace_id and tokens - will be updated from OTel span
        trace_id = str(uuid.uuid4())  # Fallback UUID
        tokens = set_trace_context(trace_id, str(uuid.uuid4()))  # Initialize tokens

        try:
            with tracer.start_as_current_span("evals.evaluate") as span:
                # Get actual OTel trace_id from the span context
                span_context = span.get_span_context()
                if span_context.is_valid:
                    trace_id = format(span_context.trace_id, '032x')
                    # Update trace context with OTel trace_id
                    reset_context(*tokens)
                    tokens = set_trace_context(trace_id, format(span_context.span_id, '016x'))

                span.set_attribute("evals.trace_id", trace_id)
                span.set_attribute("evals.task_name", task_name)
                span.set_attribute("evals.row_count", len(df))
                span.set_attribute("evals.criteria_count", len(criteria))

                logger.info(f"Starting evaluation: {task_name}")
                logger.info(f"  Trace ID: {trace_id}")
                logger.info(f"  Rows: {len(df)}, Criteria: {len(criteria)}")

                # Convert DataFrame to cases
                cases = self._df_to_cases(df, input_col, output_col, expected_col, context_col)

                # Initialize result structures
                # row_results[row_index][criteria_name] = EvalCriteriaResult
                row_results: List[Dict[str, EvalCriteriaResult]] = [{} for _ in cases]
                criteria_summaries: Dict[str, CriteriaSummary] = {}

                # Initialize pass counts for each criteria
                criteria_pass_counts: Dict[str, int] = {crit: 0 for crit in criteria}

                # Batch evaluation: evaluate all criteria per row in single LLM calls
                logger.info(f"  Using batch evaluation (batch_size={batch_size}, thinking={use_thinking})")

                # Create tasks for each case (evaluating all criteria in batches)
                async def evaluate_case_batched(case: EvalCase) -> List[EvalCriteriaResult]:
                    all_results = []
                    # Split criteria into batches
                    for i in range(0, len(criteria), batch_size):
                        batch = criteria[i:i + batch_size]
                        batch_results = await self._evaluate_batch(
                            batch, case, task_name, use_thinking
                        )
                        all_results.extend(batch_results)
                    return all_results

                tasks = [evaluate_case_batched(case) for case in cases]
                all_case_results = await asyncio.gather(*tasks, return_exceptions=True)

                # Process results
                for case_idx, case_results in enumerate(all_case_results):
                    if isinstance(case_results, Exception):
                        # Handle exceptions - mark all criteria as failed
                        for crit in criteria:
                            result = EvalCriteriaResult(
                                criteria_name=crit[:100],
                                row_index=case_idx,
                                passed=False,
                                reason=f"Evaluation error: {str(case_results)}"
                            )
                            row_results[case_idx][crit] = result
                    else:
                        for result in case_results:
                            row_results[case_idx][result.criteria_name] = result
                            if result.passed:
                                # Find original criteria by prefix match
                                for crit in criteria:
                                    if crit[:100] == result.criteria_name:
                                        criteria_pass_counts[crit] += 1
                                        break

                # Build criteria summaries
                total = len(cases)
                for crit in criteria:
                    passed_count = criteria_pass_counts[crit]
                    criteria_summaries[crit] = CriteriaSummary(
                        criteria_name=crit,
                        total_evaluated=total,
                        passed_count=passed_count,
                        failed_count=total - passed_count,
                        pass_rate=passed_count / total if total > 0 else 0.0
                    )
                    logger.info(f"  {crit[:50]}: {passed_count}/{total} passed ({passed_count/total*100:.1f}%)")

                # Calculate overall pass rate
                if criteria_summaries:
                    overall_pass_rate = sum(s.pass_rate for s in criteria_summaries.values()) / len(criteria_summaries)
                else:
                    overall_pass_rate = 0.0

                overall_passed = overall_pass_rate >= threshold

                # Build report
                report = EvalReport(
                    trace_id=trace_id,
                    task_name=task_name,
                    total_rows=len(df),
                    criteria_evaluated=criteria,
                    criteria_summaries=criteria_summaries,
                    row_results=row_results,
                    overall_pass_rate=overall_pass_rate,
                    overall_passed=overall_passed
                )

                # Record final metrics on span
                span.set_attribute("evals.overall_pass_rate", overall_pass_rate)
                span.set_attribute("evals.overall_passed", overall_passed)

                logger.info(f"Evaluation complete.")
                logger.info(f"  Overall pass rate: {overall_pass_rate:.1%}")
                logger.info(f"  Trace ID: {trace_id}")

                return report

        finally:
            # Reset trace context
            reset_context(*tokens)

    @staticmethod
    def get_traces(trace_id: str) -> List[Dict[str, Any]]:
        """
        Retrieve all traces for a given trace_id.

        Args:
            trace_id: The trace ID from an EvalReport

        Returns:
            List of span dictionaries from the trace file
        """
        try:
            exporter = get_exporter()
            all_spans = exporter.read_all()
            return [s for s in all_spans if s.get("trace_id") == trace_id]
        except Exception as e:
            logger.warning(f"Error reading traces: {e}")
            return []

    def to_dataframe(
        self,
        report: EvalReport,
        include_reasons: bool = True
    ) -> pd.DataFrame:
        """
        Convert evaluation report to a DataFrame.

        Adds columns for each criteria's pass/fail status.

        Args:
            report: EvalReport from evaluate()
            include_reasons: Whether to include reason columns (default: True)

        Returns:
            DataFrame with evaluation columns added
        """
        data = []

        for row_idx, row_result in enumerate(report.row_results):
            row_data = {"row_index": row_idx}

            for criteria_name, result in row_result.items():
                # Use a shorter key for the column name
                short_name = criteria_name[:50] if len(criteria_name) > 50 else criteria_name
                row_data[f"{short_name}_passed"] = result.passed
                if include_reasons:
                    row_data[f"{short_name}_reason"] = result.reason

            data.append(row_data)

        return pd.DataFrame(data)
