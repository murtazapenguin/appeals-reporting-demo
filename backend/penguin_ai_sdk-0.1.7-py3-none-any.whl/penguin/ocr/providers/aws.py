import os
import asyncio
import time
import io
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any, Union
import boto3
from botocore.exceptions import ClientError

from ..base import BaseOCRProvider
from ..models import OCRResult, OCRLine
from ...observability.decorator import observe

# Optional: PDF to image conversion for problematic PDFs
try:
    from pdf2image import convert_from_bytes
    from PIL import Image
    PDF_CONVERSION_AVAILABLE = True
except ImportError:
    PDF_CONVERSION_AVAILABLE = False


class TextractToAzureConverter:
    """
    Converts AWS Textract response to Azure Document Intelligence format.
    Supports multipage documents, tables, forms, and complex layouts.
    """

    DEFAULT_PAGE_WIDTH = 8.5
    DEFAULT_PAGE_HEIGHT = 11.0

    def __init__(self,
                 default_page_width: float = 8.5,
                 default_page_height: float = 11.0,
                 unit: str = "inch"):
        self.default_page_width = default_page_width
        self.default_page_height = default_page_height
        self.unit = unit

        self._block_map: Dict[str, Dict] = {}
        self._page_dimensions: Dict[int, tuple] = {}

    def convert(self, textract_response: Union[Dict[str, Any], List[Dict[str, Any]]]) -> Dict[str, Any]:
        """Convert Textract response to Azure-compatible format."""
        # Reset state
        self._block_map = {}
        self._page_dimensions = {}

        # Collect all blocks
        all_blocks = self._collect_all_blocks(textract_response)

        # Build block map
        self._block_map = {block['Id']: block for block in all_blocks}

        # Detect page dimensions
        self._detect_page_dimensions(all_blocks)

        # Group by page
        pages_data = self._group_blocks_by_page(all_blocks)

        # Convert pages
        pages = []
        for page_num in sorted(pages_data.keys()):
            page_blocks = pages_data[page_num]
            azure_page = self._convert_page(page_num, page_blocks)
            pages.append(azure_page)

        # Extract tables and key-value pairs
        tables = self._extract_tables(all_blocks)
        key_value_pairs = self._extract_key_value_pairs(all_blocks)

        # Build content string
        content = self._build_content_string(all_blocks)

        return {
            'api_version': '2023-07-31',
            'model_id': 'aws_textract',
            'content': content,
            'pages': pages,
            'tables': tables,
            'key_value_pairs': key_value_pairs
        }

    def _collect_all_blocks(self, response: Union[Dict, List[Dict]]) -> List[Dict]:
        """Collect all blocks from single or multiple responses"""
        all_blocks = []
        if isinstance(response, list):
            for resp in response:
                all_blocks.extend(resp.get('Blocks', []))
        else:
            all_blocks = response.get('Blocks', [])
        return all_blocks

    def _detect_page_dimensions(self, blocks: List[Dict]):
        """Detect page dimensions from PAGE blocks"""
        for block in blocks:
            if block.get('BlockType') == 'PAGE':
                page_num = block.get('Page', 1)
                self._page_dimensions[page_num] = (
                    self.default_page_width,
                    self.default_page_height
                )

    def _group_blocks_by_page(self, blocks: List[Dict]) -> Dict[int, List[Dict]]:
        """Group blocks by page number"""
        pages = {}
        for block in blocks:
            page_num = block.get('Page', 1)
            if page_num not in pages:
                pages[page_num] = []
            pages[page_num].append(block)
        return pages

    def _get_page_dimensions(self, page_num: int) -> tuple:
        """Get dimensions for a specific page"""
        return self._page_dimensions.get(
            page_num,
            (self.default_page_width, self.default_page_height)
        )

    def _convert_page(self, page_number: int, blocks: List[Dict]) -> Dict[str, Any]:
        """Convert blocks for a single page"""
        page_width, page_height = self._get_page_dimensions(page_number)

        lines = self._extract_lines(blocks, page_width, page_height)
        words = self._extract_words(blocks, page_width, page_height)

        return {
            'page_number': page_number,
            'width': page_width,
            'height': page_height,
            'unit': self.unit,
            'angle': 0.0,
            'lines': lines,
            'words': words
        }

    def _extract_lines(self, blocks: List[Dict], page_width: float, page_height: float) -> List[Dict]:
        """Extract line objects from LINE blocks"""
        lines = []
        for block in blocks:
            if block.get('BlockType') == 'LINE':
                text = block.get('Text', '')
                geometry = block.get('Geometry', {})
                polygon = self._get_polygon(geometry, page_width, page_height)
                line_words = self._get_line_words(block, page_width, page_height)

                lines.append({
                    'content': text,
                    'polygon': polygon,
                    'words': line_words
                })
        return lines

    def _get_line_words(self, line_block: Dict, page_width: float, page_height: float) -> List[Dict]:
        """Get words belonging to a line"""
        words = []
        relationships = line_block.get('Relationships', [])

        for rel in relationships:
            if rel.get('Type') == 'CHILD':
                for child_id in rel.get('Ids', []):
                    child_block = self._block_map.get(child_id)
                    if child_block and child_block.get('BlockType') == 'WORD':
                        word = self._convert_word(child_block, page_width, page_height)
                        words.append(word)
        return words

    def _extract_words(self, blocks: List[Dict], page_width: float, page_height: float) -> List[Dict]:
        """Extract all word objects"""
        words = []
        for block in blocks:
            if block.get('BlockType') == 'WORD':
                word = self._convert_word(block, page_width, page_height)
                words.append(word)
        return words

    def _convert_word(self, block: Dict, page_width: float, page_height: float) -> Dict[str, Any]:
        """Convert a WORD block"""
        text = block.get('Text', '')
        confidence = block.get('Confidence', 0) / 100.0
        geometry = block.get('Geometry', {})
        polygon = self._get_polygon(geometry, page_width, page_height)

        return {
            'content': text,
            'polygon': polygon,
            'confidence': confidence
        }

    def _get_polygon(self, geometry: Dict, page_width: float, page_height: float) -> List[Dict]:
        """Extract polygon from geometry"""
        polygon_points = geometry.get('Polygon', [])
        if polygon_points:
            return [
                {'x': p.get('X', 0) * page_width, 'y': p.get('Y', 0) * page_height}
                for p in polygon_points
            ]

        # Fallback to bounding box
        bbox = geometry.get('BoundingBox', {})
        if bbox:
            left = bbox.get('Left', 0) * page_width
            top = bbox.get('Top', 0) * page_height
            width = bbox.get('Width', 0) * page_width
            height = bbox.get('Height', 0) * page_height

            return [
                {'x': left, 'y': top},
                {'x': left + width, 'y': top},
                {'x': left + width, 'y': top + height},
                {'x': left, 'y': top + height}
            ]
        return []

    def _extract_tables(self, blocks: List[Dict]) -> List[Dict]:
        """Extract all tables"""
        tables = []
        table_blocks = [b for b in blocks if b.get('BlockType') == 'TABLE']

        for table_block in table_blocks:
            page_num = table_block.get('Page', 1)
            page_width, page_height = self._get_page_dimensions(page_num)

            cells = self._extract_table_cells(table_block, page_width, page_height)

            if cells:
                row_count = max(cell['row_index'] for cell in cells) + 1
                column_count = max(cell['column_index'] for cell in cells) + 1

                geometry = table_block.get('Geometry', {})
                polygon = self._get_polygon(geometry, page_width, page_height)

                tables.append({
                    'row_count': row_count,
                    'column_count': column_count,
                    'cells': cells,
                    'bounding_regions': [{
                        'page_number': page_num,
                        'polygon': polygon
                    }]
                })

        return tables

    def _extract_table_cells(self, table_block: Dict, page_width: float, page_height: float) -> List[Dict]:
        """Extract cells from a TABLE block"""
        cells = []
        relationships = table_block.get('Relationships', [])
        page_num = table_block.get('Page', 1)

        for rel in relationships:
            if rel.get('Type') == 'CHILD':
                for cell_id in rel.get('Ids', []):
                    cell_block = self._block_map.get(cell_id)
                    if cell_block and cell_block.get('BlockType') == 'CELL':
                        cell = self._convert_table_cell(cell_block, page_num, page_width, page_height)
                        if cell:
                            cells.append(cell)

        return cells

    def _convert_table_cell(self, cell_block: Dict, page_num: int,
                            page_width: float, page_height: float) -> Dict[str, Any]:
        """Convert a CELL block"""
        row_index = cell_block.get('RowIndex', 1) - 1
        column_index = cell_block.get('ColumnIndex', 1) - 1
        row_span = cell_block.get('RowSpan', 1)
        column_span = cell_block.get('ColumnSpan', 1)

        content = self._get_block_text_content(cell_block)
        geometry = cell_block.get('Geometry', {})
        polygon = self._get_polygon(geometry, page_width, page_height)

        entity_types = cell_block.get('EntityTypes', [])
        if 'COLUMN_HEADER' in entity_types:
            kind = 'columnHeader'
        elif 'ROW_HEADER' in entity_types:
            kind = 'rowHeader'
        else:
            kind = 'content'

        return {
            'kind': kind,
            'row_index': row_index,
            'column_index': column_index,
            'row_span': row_span,
            'column_span': column_span,
            'content': content,
            'bounding_regions': [{
                'page_number': page_num,
                'polygon': polygon
            }]
        }

    def _get_block_text_content(self, block: Dict) -> str:
        """Extract text content from a block"""
        content_parts = []
        relationships = block.get('Relationships', [])

        for rel in relationships:
            if rel.get('Type') == 'CHILD':
                for child_id in rel.get('Ids', []):
                    child = self._block_map.get(child_id)
                    if child:
                        if child.get('BlockType') == 'WORD':
                            content_parts.append(child.get('Text', ''))
                        elif child.get('BlockType') == 'SELECTION_ELEMENT':
                            status = child.get('SelectionStatus', 'NOT_SELECTED')
                            content_parts.append('☑' if status == 'SELECTED' else '☐')

        return ' '.join(content_parts)

    def _extract_key_value_pairs(self, blocks: List[Dict]) -> List[Dict]:
        """Extract key-value pairs"""
        key_value_pairs = []

        for block in blocks:
            if block.get('BlockType') == 'KEY_VALUE_SET':
                entity_types = block.get('EntityTypes', [])

                if 'KEY' in entity_types:
                    page_num = block.get('Page', 1)
                    page_width, page_height = self._get_page_dimensions(page_num)

                    key_content = self._get_block_text_content(block)
                    key_geometry = block.get('Geometry', {})
                    key_polygon = self._get_polygon(key_geometry, page_width, page_height)

                    key_element = {
                        'content': key_content,
                        'bounding_regions': [{
                            'page_number': page_num,
                            'polygon': key_polygon
                        }]
                    }

                    value_element = None
                    value_block = self._find_value_block(block)

                    if value_block:
                        value_page = value_block.get('Page', page_num)
                        value_page_width, value_page_height = self._get_page_dimensions(value_page)

                        value_content = self._get_block_text_content(value_block)
                        value_geometry = value_block.get('Geometry', {})
                        value_polygon = self._get_polygon(value_geometry, value_page_width, value_page_height)

                        value_element = {
                            'content': value_content,
                            'bounding_regions': [{
                                'page_number': value_page,
                                'polygon': value_polygon
                            }]
                        }

                    confidence = block.get('Confidence', 0) / 100.0

                    key_value_pairs.append({
                        'key': key_element,
                        'value': value_element,
                        'confidence': confidence
                    })

        return key_value_pairs

    def _find_value_block(self, key_block: Dict) -> Optional[Dict]:
        """Find the VALUE block associated with a KEY block"""
        relationships = key_block.get('Relationships', [])

        for rel in relationships:
            if rel.get('Type') == 'VALUE':
                value_ids = rel.get('Ids', [])
                if value_ids:
                    return self._block_map.get(value_ids[0])

        return None

    def _build_content_string(self, blocks: List[Dict]) -> str:
        """Build full document content string with line numbers"""
        pages_text = {}

        for block in blocks:
            if block.get('BlockType') == 'LINE':
                page_num = block.get('Page', 1)
                text = block.get('Text', '')

                if page_num not in pages_text:
                    pages_text[page_num] = []
                pages_text[page_num].append(text)

        all_text = []
        for page_num in sorted(pages_text.keys()):
            all_text.append(f"--- PAGE {page_num} ---")
            page_lines = pages_text[page_num]

            # Add line numbers to each line (1-indexed per page)
            for line_idx, line_text in enumerate(page_lines, start=1):
                all_text.append(f"{line_text} || {line_idx}")

            if len(pages_text) > 1:
                all_text.append('')

        return '\n'.join(all_text)


class AWSTextractProvider(BaseOCRProvider):
    def __init__(self,
                 region_name: str = None,
                 aws_access_key_id: str = None,
                 aws_secret_access_key: str = None,
                 aws_session_token: str = None,
                 s3_bucket: str = None,
                 s3_prefix: str = "textract/",
                 s3_naming_strategy: str = "uuid",
                 user_id: str = None,
                 session_id: str = None,
                 extract_tables: bool = False,
                 extract_forms: bool = False,
                 cleanup_s3: bool = True,
                 use_async_for_large_files: bool = False,
                 size_threshold_mb: int = 10):
        """
        Initialize AWS Textract OCR Provider with Azure-compatible format and S3 support.

        Args:
            region_name: AWS region (defaults to AWS_REGION env var or 'us-east-1')
            aws_access_key_id: AWS access key (defaults to AWS_ACCESS_KEY_ID env var)
            aws_secret_access_key: AWS secret key (defaults to AWS_SECRET_ACCESS_KEY env var)
            aws_session_token: AWS session token for temporary credentials (defaults to AWS_SESSION_TOKEN env var)
            s3_bucket: S3 bucket for temp storage (defaults to AWS_S3_BUCKET env var)
            s3_prefix: Base prefix for all Textract files (default: 'textract/')
            s3_naming_strategy: Naming strategy - 'uuid' (default), 'user', or 'job'
                - 'uuid': textract/{date}/{uuid}_{timestamp}_{filename}
                - 'user': textract/{user_id}/{session_id}/{timestamp}_{filename}
                - 'job': textract/jobs/{date}/{job_id}_{filename}
            user_id: User identifier (required if s3_naming_strategy='user')
            session_id: Session identifier (optional, auto-generated if not provided)
            extract_tables: Extract tables from documents (default: False)
            extract_forms: Extract forms/key-value pairs from documents (default: False)
            cleanup_s3: Auto-delete S3 temp files after processing (default: True)
            use_async_for_large_files: Use S3 + async API for large files (default: False)
            size_threshold_mb: File size threshold for async processing (default: 10MB)
        """
        self.region_name = region_name or os.environ.get("AWS_REGION", "us-east-1")
        self.aws_access_key_id = aws_access_key_id or os.environ.get("AWS_ACCESS_KEY_ID")
        self.aws_secret_access_key = aws_secret_access_key or os.environ.get("AWS_SECRET_ACCESS_KEY")
        self.aws_session_token = aws_session_token or os.environ.get("AWS_SESSION_TOKEN")

        # S3 configuration
        self.s3_bucket = s3_bucket or os.environ.get("AWS_S3_BUCKET")
        self.s3_prefix = s3_prefix.rstrip('/') + '/'  # Ensure trailing slash
        self.s3_naming_strategy = s3_naming_strategy
        self.user_id = user_id
        self.session_id = session_id or str(uuid.uuid4())[:8]  # Auto-generate session ID
        self.cleanup_s3 = cleanup_s3
        self.use_async_for_large_files = use_async_for_large_files
        self.size_threshold_mb = size_threshold_mb

        # Validate configuration
        if s3_naming_strategy == 'user' and not user_id:
            raise ValueError("user_id is required when s3_naming_strategy='user'")

        self.extract_tables = extract_tables
        self.extract_forms = extract_forms

        # Initialize converter for Azure format
        self.converter = TextractToAzureConverter()

        if not self.aws_access_key_id or not self.aws_secret_access_key:
            raise ValueError("AWS credentials (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY) are missing.")

    def _get_client(self):
        """Creates and returns the Textract client."""
        client_config = {
            'region_name': self.region_name,
            'aws_access_key_id': self.aws_access_key_id,
            'aws_secret_access_key': self.aws_secret_access_key
        }

        # Add session token if available (for temporary credentials)
        if self.aws_session_token:
            client_config['aws_session_token'] = self.aws_session_token

        return boto3.client('textract', **client_config)

    def _get_feature_types(self) -> Optional[List[str]]:
        """Get feature types based on configuration."""
        feature_types = []

        if self.extract_tables:
            feature_types.append('TABLES')

        if self.extract_forms:
            feature_types.append('FORMS')

        return feature_types if feature_types else None

    def _get_s3_client(self):
        """Creates and returns the S3 client."""
        client_config = {
            'region_name': self.region_name,
            'aws_access_key_id': self.aws_access_key_id,
            'aws_secret_access_key': self.aws_secret_access_key
        }

        if self.aws_session_token:
            client_config['aws_session_token'] = self.aws_session_token

        return boto3.client('s3', **client_config)

    def _generate_s3_key(self, file_path: str, job_id: str = None) -> str:
        """
        Generate unique S3 key based on naming strategy.

        Strategies:
        1. UUID: textract/2026-01-06/a7f3d891-uuid_1736179200_invoice.pdf
        2. User: textract/user_12345/sess_abc123/1736179200_invoice.pdf
        3. Job:  textract/jobs/2026-01-06/textract-job-abc123_invoice.pdf

        Args:
            file_path: Original file path
            job_id: Textract job ID (for 'job' strategy)

        Returns:
            Complete S3 key with guaranteed uniqueness
        """
        file_name = Path(file_path).name
        timestamp = int(time.time())
        date_str = datetime.now().strftime('%Y-%m-%d')

        # Sanitize filename (remove special chars)
        safe_filename = "".join(c for c in file_name if c.isalnum() or c in '._- ')
        safe_filename = safe_filename.replace(' ', '_')

        if self.s3_naming_strategy == 'uuid':
            # UUID-based: Best for multi-user without user tracking
            unique_id = str(uuid.uuid4())
            s3_key = f"{self.s3_prefix}{date_str}/{unique_id}_{timestamp}_{safe_filename}"

        elif self.s3_naming_strategy == 'user':
            # User-based: Best for user tracking and isolation
            s3_key = f"{self.s3_prefix}{self.user_id}/{self.session_id}/{timestamp}_{safe_filename}"

        elif self.s3_naming_strategy == 'job':
            # Job-based: Best for direct Textract job correlation
            if not job_id:
                # Pre-upload: use temp UUID until job starts
                temp_id = str(uuid.uuid4())[:8]
                s3_key = f"{self.s3_prefix}jobs/{date_str}/pending_{temp_id}_{timestamp}_{safe_filename}"
            else:
                s3_key = f"{self.s3_prefix}jobs/{date_str}/{job_id}_{safe_filename}"

        else:
            raise ValueError(f"Invalid s3_naming_strategy: {self.s3_naming_strategy}")

        return s3_key

    def _parse_textract_result(self, file_path: str, textract_response: dict) -> OCRResult:
        """Converts AWS Textract response to Penguin format via Azure-compatible format."""

        # Convert to Azure format first
        azure_result = self.converter.convert(textract_response)

        # Extract lines from Azure-formatted result
        all_lines_data = []

        for page in azure_result.get('pages', []):
            page_number = page.get('page_number', 1)

            for line_idx, line in enumerate(page.get('lines', []), start=1):
                content = line.get('content', '')
                polygon = line.get('polygon', [])

                # Convert polygon format to Penguin format
                bbox = [{"x": point['x'], "y": point['y']} for point in polygon]

                # Calculate average confidence from words
                words = line.get('words', [])
                confidence = None
                if words:
                    word_confidences = [w.get('confidence') for w in words if w.get('confidence') is not None]
                    if word_confidences:
                        confidence = sum(word_confidences) / len(word_confidences)

                line_obj = OCRLine(
                    content=content,
                    page_number=page_number,
                    line_number=line_idx,
                    bounding_box=bbox,
                    confidence=confidence
                )
                all_lines_data.append(line_obj)

        # Extract page dimensions for top-level metadata (consistent with Azure provider)
        page_dimensions = []
        for page in azure_result.get('pages', []):
            page_dimensions.append({
                "page_number": page.get('page_number', 1),
                "width": page.get('width', self.converter.default_page_width),
                "height": page.get('height', self.converter.default_page_height),
                "unit": page.get('unit', self.converter.unit)
            })

        # Build rich metadata with Azure format
        metadata = {
            "region": self.region_name,
            "page_dimensions": page_dimensions,  # Top-level for bbox_converter compatibility
            "azure_format": azure_result,  # Full Azure-compatible result
            "pages_count": len(azure_result.get('pages', [])),
            "tables_count": len(azure_result.get('tables', [])),
            "key_value_pairs_count": len(azure_result.get('key_value_pairs', []))
        }

        return OCRResult(
            file_path=file_path,
            full_text=azure_result.get('content', ''),
            lines=all_lines_data,
            provider="aws_textract",
            metadata=metadata
        )

    async def process_file(self, file_path: str) -> OCRResult:
        """
        Performs OCR on a single file using AWS Textract with smart routing.

        Smart Routing Strategy:
        1. Large files (>threshold) OR use_async_for_large_files=True: Use S3 + Async API
        2. Small files: Try synchronous API first
        3. If synchronous fails: Try S3 + Async API (if S3 bucket configured)
        4. Last resort: PDF-to-image conversion (legacy fallback)

        Args:
            file_path: Path to the document file

        Returns:
            OCRResult with Azure-formatted data in metadata
        """
        # Check file size
        file_size_mb = Path(file_path).stat().st_size / (1024 * 1024)

        # Strategy 1: Use S3 + Async for PDFs when S3 bucket is configured (most reliable)
        if file_path.lower().endswith('.pdf') and self.s3_bucket:
            print(f"📁 PDF detected with S3 configured. Using S3 + Async API (most reliable for PDFs)...")
            return await self._process_with_s3(file_path)

        # Strategy 2: Use S3 + Async for large files if enabled
        if self.use_async_for_large_files and file_size_mb >= self.size_threshold_mb:
            if self.s3_bucket:
                print(f"📁 File size {file_size_mb:.2f}MB >= {self.size_threshold_mb}MB. Using S3 + Async API...")
                return await self._process_with_s3(file_path)
            else:
                print(f"⚠️  File is large ({file_size_mb:.2f}MB) but no S3 bucket configured. Using synchronous API...")

        # Strategy 3: Try synchronous API for small files or when S3 not configured
        try:
            # Read the document
            with open(file_path, 'rb') as document:
                document_bytes = document.read()

            # Determine which API to use
            feature_types = self._get_feature_types()

            # Run Textract in executor to avoid blocking
            loop = asyncio.get_event_loop()

            # Always use analyze_document (supports all document types including complex PDFs)
            # detect_document_text has limitations with multi-page and complex PDFs
            # If no features specified, use LAYOUT which provides basic text extraction
            if not feature_types:
                feature_types = ['LAYOUT']

            response = await loop.run_in_executor(
                None,
                lambda: self._get_client().analyze_document(
                    Document={'Bytes': document_bytes},
                    FeatureTypes=feature_types
                )
            )

            return self._parse_textract_result(file_path, response)

        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']

            # Strategy 4: If synchronous API fails, try S3 + Async (fallback for non-PDF or when S3 wasn't used)
            if error_code == 'UnsupportedDocumentException' and file_path.lower().endswith('.pdf'):
                if self.s3_bucket:
                    print(f"⚠️  Synchronous API failed. Trying S3 + Async API (better than image conversion)...")
                    return await self._process_with_s3(file_path)
                else:
                    # Strategy 5: Last resort - PDF to image conversion (legacy fallback)
                    print(f"⚠️  AWS Textract rejected PDF format. No S3 bucket configured. Attempting PDF-to-image conversion...")
                    return await self._process_pdf_as_images(file_path, document_bytes, feature_types)

            raise RuntimeError(f"AWS Textract failed for {file_path}: {error_code} - {error_message}")
        except Exception as e:
            raise RuntimeError(f"AWS Textract failed for {file_path}: {str(e)}")

    async def _process_pdf_as_images(self, file_path: str, pdf_bytes: bytes, feature_types: List[str]) -> OCRResult:
        """
        Convert PDF to images and process each page through AWS Textract.
        Combines results into a single OCRResult maintaining page numbers.

        Args:
            file_path: Original PDF file path
            pdf_bytes: PDF content as bytes
            feature_types: Textract features to use

        Returns:
            Combined OCRResult from all pages
        """
        if not PDF_CONVERSION_AVAILABLE:
            raise RuntimeError(
                "PDF-to-image conversion requires pdf2image and Pillow. "
                "Install with: pip install pdf2image Pillow"
            )

        try:
            # Convert PDF to images (one per page)
            print(f"  Converting PDF to images...")
            images = convert_from_bytes(pdf_bytes, dpi=200)
            print(f"  Converted {len(images)} pages to images")

            # Process each page as an image
            all_responses = []
            loop = asyncio.get_event_loop()

            for page_num, image in enumerate(images, start=1):
                print(f"  Processing page {page_num}/{len(images)}...")

                # Convert PIL image to bytes
                img_byte_arr = io.BytesIO()
                image.save(img_byte_arr, format='PNG')
                img_bytes = img_byte_arr.getvalue()

                # Process with Textract
                response = await loop.run_in_executor(
                    None,
                    lambda img=img_bytes: self._get_client().analyze_document(
                        Document={'Bytes': img},
                        FeatureTypes=feature_types
                    )
                )

                # Update page numbers in response to maintain correct sequence
                for block in response.get('Blocks', []):
                    block['Page'] = page_num

                all_responses.append(response)

            # Combine all responses
            print(f"  Combining results from {len(all_responses)} pages...")
            combined_response = self._combine_responses(all_responses)

            # Parse combined result
            result = self._parse_textract_result(file_path, combined_response)
            result.metadata['conversion_method'] = 'pdf_to_image'
            result.metadata['converted_pages'] = len(images)

            print(f"✓ Successfully processed PDF via image conversion")
            return result

        except Exception as e:
            raise RuntimeError(f"PDF-to-image conversion failed: {str(e)}")

    def _combine_responses(self, responses: List[Dict]) -> Dict:
        """
        Combine multiple Textract responses into a single response.

        Args:
            responses: List of Textract response dictionaries

        Returns:
            Combined response dictionary
        """
        if not responses:
            return {'Blocks': []}

        combined = {
            'DocumentMetadata': responses[0].get('DocumentMetadata', {}),
            'Blocks': []
        }

        # Combine all blocks from all responses
        for response in responses:
            blocks = response.get('Blocks', [])
            combined['Blocks'].extend(blocks)

        return combined

    async def _poll_textract_job(self, job_id: str, is_analysis: bool,
                                  poll_interval: int = 5, max_wait: int = 600) -> List[Dict]:
        """
        Poll Textract job until completion.
        Handles pagination for multi-page results.

        Args:
            job_id: Textract job ID
            is_analysis: True for AnalyzeDocument, False for DetectText
            poll_interval: Seconds between polls (default: 5)
            max_wait: Maximum wait time in seconds (default: 600)

        Returns:
            List of all blocks from the completed job
        """
        textract_client = self._get_client()
        loop = asyncio.get_event_loop()
        start_time = time.time()

        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait:
                raise TimeoutError(f"Textract job {job_id} exceeded {max_wait}s timeout")

            # Get job status
            if is_analysis:
                get_response = await loop.run_in_executor(
                    None,
                    lambda: textract_client.get_document_analysis(JobId=job_id)
                )
            else:
                get_response = await loop.run_in_executor(
                    None,
                    lambda: textract_client.get_document_text_detection(JobId=job_id)
                )

            status = get_response['JobStatus']
            print(f"  ⏳ Job status: {status} (elapsed: {elapsed:.1f}s)")

            if status == 'SUCCEEDED':
                # Collect all blocks (handle pagination)
                all_blocks = get_response.get('Blocks', [])
                next_token = get_response.get('NextToken')
                page_count = 1

                while next_token:
                    page_count += 1
                    print(f"  📄 Fetching result page {page_count}...")

                    if is_analysis:
                        next_response = await loop.run_in_executor(
                            None,
                            lambda t=next_token: textract_client.get_document_analysis(
                                JobId=job_id,
                                NextToken=t
                            )
                        )
                    else:
                        next_response = await loop.run_in_executor(
                            None,
                            lambda t=next_token: textract_client.get_document_text_detection(
                                JobId=job_id,
                                NextToken=t
                            )
                        )

                    all_blocks.extend(next_response.get('Blocks', []))
                    next_token = next_response.get('NextToken')

                print(f"  ✅ Job completed. Extracted {len(all_blocks)} blocks from {page_count} result page(s)")
                return all_blocks

            elif status == 'FAILED':
                error = get_response.get('StatusMessage', 'Unknown error')
                raise RuntimeError(f"Textract job failed: {error}")

            elif status in ['IN_PROGRESS', 'PENDING']:
                await asyncio.sleep(poll_interval)

            else:
                raise RuntimeError(f"Unknown job status: {status}")

    async def _process_with_s3(self, file_path: str) -> OCRResult:
        """
        Process document using S3 + Async Textract API.
        Uses smart naming strategy to avoid collisions.

        Args:
            file_path: Path to the document file

        Returns:
            OCRResult with Azure-formatted data in metadata
        """
        if not self.s3_bucket:
            raise ValueError(
                "S3 bucket required for async processing. "
                "Set s3_bucket parameter or AWS_S3_BUCKET environment variable"
            )

        # Generate unique S3 key
        s3_key = self._generate_s3_key(file_path)

        print(f"📁 Using S3 naming strategy: {self.s3_naming_strategy}")
        print(f"🔑 S3 Key: s3://{self.s3_bucket}/{s3_key}")

        try:
            # Step 1: Upload to S3
            print(f"  ⬆️  Uploading to S3...")
            loop = asyncio.get_event_loop()
            s3_client = self._get_s3_client()

            await loop.run_in_executor(
                None,
                lambda: s3_client.upload_file(
                    file_path,
                    self.s3_bucket,
                    s3_key,
                    ExtraArgs={
                        'Metadata': {
                            'original_filename': Path(file_path).name,
                            'upload_timestamp': str(int(time.time())),
                            'naming_strategy': self.s3_naming_strategy,
                            'user_id': self.user_id or 'anonymous',
                            'session_id': self.session_id
                        }
                    }
                )
            )
            print(f"  ✅ Upload complete")

            # Step 2: Start async Textract job
            print(f"  🚀 Starting Textract async job...")
            feature_types = self._get_feature_types()
            textract_client = self._get_client()

            if feature_types:
                start_response = await loop.run_in_executor(
                    None,
                    lambda: textract_client.start_document_analysis(
                        DocumentLocation={
                            'S3Object': {
                                'Bucket': self.s3_bucket,
                                'Name': s3_key
                            }
                        },
                        FeatureTypes=feature_types,
                        JobTag=f"user:{self.user_id or 'anon'}_session:{self.session_id}"
                    )
                )
            else:
                start_response = await loop.run_in_executor(
                    None,
                    lambda: textract_client.start_document_text_detection(
                        DocumentLocation={
                            'S3Object': {
                                'Bucket': self.s3_bucket,
                                'Name': s3_key
                            }
                        },
                        JobTag=f"user:{self.user_id or 'anon'}_session:{self.session_id}"
                    )
                )

            job_id = start_response['JobId']
            print(f"  📋 Job ID: {job_id}")

            # Step 3: Poll for completion
            result_blocks = await self._poll_textract_job(job_id, feature_types is not None)

            # Step 4: Cleanup S3 (optional)
            if self.cleanup_s3:
                print(f"  🧹 Cleaning up S3 temp file...")
                await loop.run_in_executor(
                    None,
                    lambda: s3_client.delete_object(Bucket=self.s3_bucket, Key=s3_key)
                )
                print(f"  ✅ Cleanup complete")
            else:
                print(f"  💾 S3 file retained: s3://{self.s3_bucket}/{s3_key}")

            # Step 5: Parse result
            combined_response = {'Blocks': result_blocks}
            result = self._parse_textract_result(file_path, combined_response)
            result.metadata['processing_method'] = 's3_async'
            result.metadata['s3_location'] = f"s3://{self.s3_bucket}/{s3_key}"
            result.metadata['s3_key'] = s3_key
            result.metadata['textract_job_id'] = job_id
            result.metadata['naming_strategy'] = self.s3_naming_strategy

            return result

        except Exception as e:
            # Cleanup on error
            if self.cleanup_s3:
                try:
                    print(f"  ⚠️  Error occurred, cleaning up S3...")
                    s3_client.delete_object(Bucket=self.s3_bucket, Key=s3_key)
                except Exception as cleanup_error:
                    print(f"  ⚠️  Failed to cleanup S3: {cleanup_error}")
            raise RuntimeError(f"S3 + Async Textract failed: {str(e)}")

    async def _process_with_semaphore(self, file_path: str, semaphore: asyncio.Semaphore) -> OCRResult:
        """Process a file with semaphore control for concurrency."""
        async with semaphore:
            return await self.process_file(file_path)

    async def process_batch(self, file_paths: List[str], max_concurrency: int = 5) -> List[OCRResult]:
        """
        Processes a list of files in parallel using AWS Textract.

        Args:
            file_paths: List of file paths to process
            max_concurrency: Maximum number of concurrent requests

        Returns:
            List of OCRResult objects with Azure-formatted data
        """
        print(f"--- [Penguin] Starting Batch OCR for {len(file_paths)} files ---")
        start_time = time.time()

        semaphore = asyncio.Semaphore(max_concurrency)
        tasks = [self._process_with_semaphore(f, semaphore) for f in file_paths]

        # return_exceptions=True allows the batch to complete even if one file fails
        results = await asyncio.gather(*tasks, return_exceptions=True)

        valid_results = []
        for i, res in enumerate(results):
            if isinstance(res, Exception):
                print(f"[ERROR] Failed to process {file_paths[i]}: {res}")
            else:
                valid_results.append(res)

        end_time = time.time()
        print(f"--- [Penguin] Finished in {end_time - start_time:.2f} seconds ---")
        return valid_results
