"""OCR Providers"""

from .azure import AzureOCRProvider
from .aws import AWSTextractProvider

__all__ = ["AzureOCRProvider", "AWSTextractProvider"]
