"""
Utility for converting Penguin SDK OCR format to canonical bbox format.

This module provides functions to convert OCRResult objects to the standard
bbox format used by PDFViewer and other consumers.
"""

from typing import List, Dict, Any
import os
from .models import OCRResult, OCRLine


def ocr_line_to_bbox_format(
    ocr_line: OCRLine,
    document_name: str,
    page_dimensions: Dict[str, Any]
) -> dict:
    """
    Convert a single OCRLine to canonical bbox format.

    Args:
        ocr_line: OCRLine object from OCR processing
        document_name: Name of the document (filename)
        page_dimensions: Dict with 'width', 'height', 'unit' for the page

    Returns:
        Dict in canonical bbox format with normalized 0-1 coordinates:
        {
            "document_name": "file.pdf",
            "page_number": 1,
            "bbox": [[x1, y1, x2, y2, x3, y3, x4, y4]],
            "page_dimensions": {"width": 8.5, "height": 11.0, "unit": "inch"}
        }

    Example:
        >>> line = result.find_line(1, page_number=1)
        >>> page_dims = result.metadata['page_dimensions'][0]
        >>> bbox_dict = ocr_line_to_bbox_format(line, "invoice.pdf", page_dims)
        >>> print(bbox_dict["bbox"])  # [[0.1176, 0.1364, ...]]
    """
    # Get page dimensions for normalization
    page_width = page_dimensions.get("width", 8.5)
    page_height = page_dimensions.get("height", 11.0)
    unit = page_dimensions.get("unit", "inch")

    # Convert from [{x, y}, {x, y}, ...] to flat array [x1, y1, x2, y2, ...]
    # OCR bounding_box has 4 points: top-left, top-right, bottom-right, bottom-left
    bbox_points = ocr_line.bounding_box

    if len(bbox_points) != 4:
        raise ValueError(f"Expected 4 bounding box points, got {len(bbox_points)}")

    # Extract raw coordinates (in inches from Azure)
    raw_coords = [
        bbox_points[0]["x"], bbox_points[0]["y"],  # top-left
        bbox_points[1]["x"], bbox_points[1]["y"],  # top-right
        bbox_points[2]["x"], bbox_points[2]["y"],  # bottom-right
        bbox_points[3]["x"], bbox_points[3]["y"],  # bottom-left
    ]

    # Normalize to 0-1 range
    normalized_coords = [
        raw_coords[0] / page_width,  raw_coords[1] / page_height,  # top-left
        raw_coords[2] / page_width,  raw_coords[3] / page_height,  # top-right
        raw_coords[4] / page_width,  raw_coords[5] / page_height,  # bottom-right
        raw_coords[6] / page_width,  raw_coords[7] / page_height,  # bottom-left
    ]

    return {
        "document_name": document_name,
        "page_number": ocr_line.page_number,
        "bbox": [normalized_coords],  # Wrap in array for single bbox
        "page_dimensions": {
            "width": page_width,
            "height": page_height,
            "unit": unit
        }
    }


def ocr_result_to_bbox_format(
    ocr_result: OCRResult,
    line_numbers: List[int] = None,
    page_number: int = None,
    group_by_page: bool = True
) -> List[dict]:
    """
    Convert OCRResult to canonical bbox format for all or specific lines.

    Args:
        ocr_result: OCRResult object from OCR processing
        line_numbers: Optional list of specific line numbers to convert. If None, converts all lines.
        page_number: Optional page number to filter lines. If None, processes all pages.
        group_by_page: If True, groups multiple bboxes on same page together. Default True.

    Returns:
        List of bbox objects in canonical format:
        [
            {
                "document_name": "file.pdf",
                "page_number": 1,
                "bbox": [[x1, y1, x2, y2, ...], [x1, y1, ...]],  # Multiple bboxes if grouped
                "page_dimensions": {"width": 8.5, "height": 11.0, "unit": "inch"}
            }
        ]

    Example:
        >>> # Convert all lines
        >>> bbox_list = ocr_result_to_bbox_format(result)
        >>>
        >>> # Convert specific lines on page 1
        >>> bbox_list = ocr_result_to_bbox_format(result, line_numbers=[1, 2, 3], page_number=1)
        >>>
        >>> # Convert all lines, don't group by page
        >>> bbox_list = ocr_result_to_bbox_format(result, group_by_page=False)
    """
    # Extract document name from file_path
    document_name = os.path.basename(ocr_result.file_path)

    # Get page dimensions from metadata
    page_dimensions_list = ocr_result.metadata.get("page_dimensions", [])
    page_dims_map = {pd["page_number"]: pd for pd in page_dimensions_list}

    # Default dimensions if not in metadata (fallback)
    default_dims = {"width": 8.5, "height": 11.0, "unit": "inch"}

    # Convert lines to bbox format
    bbox_objects = []

    for line in ocr_result.lines:
        # Filter by page_number if specified
        if page_number is not None and line.page_number != page_number:
            continue

        # Filter by line_numbers if specified
        if line_numbers is not None and line.line_number not in line_numbers:
            continue

        # Get page dimensions for this line's page
        page_dims = page_dims_map.get(line.page_number, default_dims)

        # Convert line to bbox format
        bbox_obj = ocr_line_to_bbox_format(line, document_name, page_dims)
        bbox_objects.append(bbox_obj)

    # Group by page if requested
    if group_by_page and bbox_objects:
        return _group_bboxes_by_page(bbox_objects)

    return bbox_objects


def _group_bboxes_by_page(bbox_objects: List[dict]) -> List[dict]:
    """
    Group multiple bboxes on the same page together.

    Args:
        bbox_objects: List of individual bbox objects

    Returns:
        List of grouped bbox objects where bboxes on same page are combined
    """
    grouped = {}

    for bbox_obj in bbox_objects:
        key = f"{bbox_obj['document_name']}_{bbox_obj['page_number']}"

        if key not in grouped:
            grouped[key] = {
                "document_name": bbox_obj["document_name"],
                "page_number": bbox_obj["page_number"],
                "bbox": [],
                "page_dimensions": bbox_obj["page_dimensions"]
            }

        # Extend bbox array with this line's coordinates
        grouped[key]["bbox"].extend(bbox_obj["bbox"])

    # Return as list sorted by document name then page number
    return sorted(grouped.values(), key=lambda x: (x["document_name"], x["page_number"]))


def strip_page_dimensions(bbox_objects: List[dict]) -> List[dict]:
    """
    Remove page_dimensions from bbox objects for consumer format.

    Some consumers (PDFViewer, api-builder) don't need page dimensions.
    Use this to strip them before sending to those consumers.

    Args:
        bbox_objects: List of bbox objects with page_dimensions

    Returns:
        List of bbox objects without page_dimensions field

    Example:
        >>> bbox_list = ocr_result_to_bbox_format(result)
        >>> consumer_bbox_list = strip_page_dimensions(bbox_list)
    """
    return [
        {
            "document_name": obj["document_name"],
            "page_number": obj["page_number"],
            "bbox": obj["bbox"]
        }
        for obj in bbox_objects
    ]
