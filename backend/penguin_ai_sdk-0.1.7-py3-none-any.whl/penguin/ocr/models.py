from typing import List, Dict, Optional, Any, Union
from pydantic import BaseModel

class Point(BaseModel):
    x: float
    y: float

class OCRLine(BaseModel):
    content: str
    page_number: int
    line_number: int  # Sequential line number within page (starts at 1)
    bounding_box: List[Dict[str, float]] # List of {x, y}
    confidence: Optional[float] = None

class OCRResult(BaseModel):
    file_path: str
    full_text: str
    lines: List[OCRLine]
    provider: str
    metadata: Dict[str, Any] = {}

    def get_bounding_boxes_by_line(
        self,
        line_numbers: Union[int, List[int]],
        page_number: Optional[int] = None
    ) -> Union[List[Dict[str, float]], Dict[int, List[Dict[str, float]]]]:
        """
        Get bounding boxes for specific line numbers.

        Args:
            line_numbers: Single line number or list of line numbers to query (1-based, per page)
            page_number: Optional page number to restrict search. If None, searches all pages.

        Returns:
            - If line_numbers is int: Returns single bounding box (List[Dict[str, float]])
            - If line_numbers is List[int]: Returns dict mapping line_number -> bounding_box

        Raises:
            ValueError: If line number(s) not found or if line numbers are invalid (<=0)

        Example:
            >>> result = await provider.process_file("document.pdf")
            >>> # Get single line's bounding box
            >>> bbox = result.get_bounding_boxes_by_line(5, page_number=1)
            >>> print(bbox)  # [{"x": 100, "y": 200}, {"x": 500, "y": 200}, ...]
            >>>
            >>> # Get multiple lines' bounding boxes
            >>> bboxes = result.get_bounding_boxes_by_line([5, 10, 15], page_number=1)
            >>> print(bboxes)  # {5: [...], 10: [...], 15: [...]}
        """
        # Handle single vs multiple line numbers
        single_mode = isinstance(line_numbers, int)
        if single_mode:
            line_numbers_list = [line_numbers]
        else:
            line_numbers_list = line_numbers

        # Validate line numbers are positive
        for ln in line_numbers_list:
            if ln <= 0:
                raise ValueError(f"Line numbers must be positive (1-based). Got: {ln}")

        # Empty list case
        if not line_numbers_list:
            return {}

        # Search for requested line numbers
        results = {}
        for line in self.lines:
            # Filter by page if specified
            if page_number is not None and line.page_number != page_number:
                continue

            # Check if this line number is requested
            if line.line_number in line_numbers_list:
                results[line.line_number] = line.bounding_box

                # Early exit if all found
                if len(results) == len(line_numbers_list):
                    break

        # Validate all requested lines were found
        if len(results) != len(line_numbers_list):
            missing = set(line_numbers_list) - set(results.keys())
            page_info = f" on page {page_number}" if page_number is not None else ""
            raise ValueError(f"Line number(s) not found{page_info}: {sorted(missing)}")

        # Return format based on input type
        if single_mode:
            return results[line_numbers_list[0]]
        else:
            return results

    def find_line(
        self,
        line_number: int,
        page_number: Optional[int] = None
    ) -> Optional[OCRLine]:
        """
        Find and return the complete OCRLine object for a given line number.

        Args:
            line_number: Line number to find (1-based, per page)
            page_number: Optional page number to restrict search. If None, searches all pages.

        Returns:
            OCRLine object if found, None otherwise

        Example:
            >>> result = await provider.process_file("document.pdf")
            >>> line = result.find_line(line_number=5, page_number=1)
            >>> print(f"Content: {line.content}, Confidence: {line.confidence}")
        """
        if line_number <= 0:
            return None

        for line in self.lines:
            # Filter by page if specified
            if page_number is not None and line.page_number != page_number:
                continue

            # Check if this is the line we're looking for
            if line.line_number == line_number:
                return line

        return None

    def find_line_as_bbox(
        self,
        line_number: int,
        page_number: Optional[int] = None,
        include_page_dimensions: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Find a line and return it in canonical bbox format (convenience method).

        This method combines find_line() and bbox conversion in one call.
        Coordinates are automatically normalized to 0-1 range.

        Args:
            line_number: Line number to find (1-based, per page)
            page_number: Optional page number to restrict search. If None, searches all pages.
            include_page_dimensions: If True, includes page dimensions in output. Default True.

        Returns:
            Dict in canonical bbox format:
            {
                "document_name": "file.pdf",
                "page_number": 1,
                "bbox": [[x1, y1, x2, y2, x3, y3, x4, y4]],  # Normalized 0-1
                "page_dimensions": {"width": 8.5, "height": 11.0, "unit": "inch"}  # If include_page_dimensions=True
            }
            Returns None if line not found.

        Example:
            >>> result = await provider.process_file("document.pdf")
            >>> bbox_dict = result.find_line_as_bbox(line_number=5, page_number=1)
            >>> print(bbox_dict["bbox"])  # [[0.1176, 0.1364, 0.5294, ...]]
            >>> print(bbox_dict["document_name"])  # "document.pdf"
            >>>
            >>> # Without page dimensions (for PDFViewer)
            >>> bbox_dict = result.find_line_as_bbox(5, page_number=1, include_page_dimensions=False)
        """
        # Import here to avoid circular dependency
        from .bbox_converter import ocr_line_to_bbox_format
        import os

        # Find the line first
        line = self.find_line(line_number, page_number)
        if line is None:
            return None

        # Get page dimensions for this line's page
        page_dimensions_list = self.metadata.get("page_dimensions", [])
        page_dims_map = {pd["page_number"]: pd for pd in page_dimensions_list}
        page_dims = page_dims_map.get(
            line.page_number,
            {"width": 8.5, "height": 11.0, "unit": "inch"}  # Default fallback
        )

        # Extract document name from file_path
        document_name = os.path.basename(self.file_path)

        # Convert to bbox format
        bbox_obj = ocr_line_to_bbox_format(line, document_name, page_dims)

        # Remove page_dimensions if not requested
        if not include_page_dimensions:
            bbox_obj = {
                "document_name": bbox_obj["document_name"],
                "page_number": bbox_obj["page_number"],
                "bbox": bbox_obj["bbox"]
            }

        return bbox_obj