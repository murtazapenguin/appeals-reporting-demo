from abc import ABC, abstractmethod
from typing import List
from .models import OCRResult

class BaseOCRProvider(ABC):
    @abstractmethod
    async def process_file(self, file_path: str) -> OCRResult:
        """Process a single file and return structured results."""
        pass

    @abstractmethod
    async def process_batch(self, file_paths: List[str], max_concurrency: int = 5) -> List[OCRResult]:
        """Process a list of files in parallel."""
        pass