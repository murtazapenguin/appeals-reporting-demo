"""
Penguin Remote Data Assets

Utilities for downloading and caching large data assets from S3.
Requires AWS credentials (via environment, config, or IAM role).
"""

import logging
import shutil
import zipfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger("penguin.data_assets")

# Default cache location for remote assets
ASSETS_CACHE_DIR = Path.home() / ".penguin" / "assets"


def get_cache_path(asset_name: str) -> Path:
    """
    Get local cache path for an asset.

    Args:
        asset_name: Name of the asset

    Returns:
        Path to the cached asset location
    """
    return ASSETS_CACHE_DIR / asset_name


def is_cached(asset_name: str) -> bool:
    """
    Check if asset is already in local cache.

    Args:
        asset_name: Name of the asset

    Returns:
        True if asset exists in cache
    """
    return get_cache_path(asset_name).exists()


def download_from_s3(
    bucket: str,
    key: str,
    asset_name: str,
    extract_zip: bool = False
) -> Path:
    """
    Download asset from S3 bucket to local cache.

    Uses boto3 with AWS credentials from environment, config, or IAM role.
    Assets are cached locally to avoid re-downloading.

    Args:
        bucket: S3 bucket name
        key: Object key in bucket
        asset_name: Local name for the asset
        extract_zip: If True, extract zip after download

    Returns:
        Path to downloaded (and possibly extracted) asset

    Raises:
        ImportError: If boto3 is not installed
        RuntimeError: If download fails
    """
    try:
        import boto3
        from botocore.exceptions import ClientError, NoCredentialsError
    except ImportError:
        raise ImportError(
            "boto3 is required for remote assets. Install with: pip install boto3"
        )

    cache_dir = ASSETS_CACHE_DIR
    cache_dir.mkdir(parents=True, exist_ok=True)

    local_path = cache_dir / asset_name

    # Check if already cached
    if local_path.exists():
        logger.debug(f"Asset '{asset_name}' loaded from cache: {local_path}")
        return local_path

    print(f"[Penguin] Downloading {asset_name} from s3://{bucket}/{key}...")
    logger.info(f"Downloading {asset_name} from s3://{bucket}/{key}")

    # Download to temp file first
    temp_path = cache_dir / f"{asset_name}.download"

    try:
        s3 = boto3.client('s3')
        s3.download_file(bucket, key, str(temp_path))

        if extract_zip and key.endswith('.zip'):
            # Extract zip to directory
            print(f"[Penguin] Extracting {asset_name}...")
            local_path.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(temp_path, 'r') as zf:
                zf.extractall(local_path)
            temp_path.unlink()
        else:
            # Just rename the downloaded file
            temp_path.rename(local_path)

        print(f"[Penguin] Downloaded to {local_path}")
        logger.info(f"Asset '{asset_name}' downloaded to {local_path}")
        return local_path

    except NoCredentialsError:
        if temp_path.exists():
            temp_path.unlink()
        raise RuntimeError(
            f"AWS credentials not found. Configure credentials via:\n"
            f"  - Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)\n"
            f"  - AWS config file (~/.aws/credentials)\n"
            f"  - IAM role (if running on AWS)"
        )
    except ClientError as e:
        if temp_path.exists():
            temp_path.unlink()
        raise RuntimeError(f"Failed to download {asset_name} from S3: {e}") from e
    except Exception as e:
        # Clean up on failure
        if temp_path.exists():
            temp_path.unlink()
        if local_path.exists() and local_path.is_dir():
            shutil.rmtree(local_path)
        raise RuntimeError(f"Failed to download {asset_name} from S3: {e}") from e


def clear_cache(asset_name: Optional[str] = None) -> None:
    """
    Clear cached assets.

    Args:
        asset_name: If provided, clear only that asset. Otherwise clear all cached assets.
    """
    if asset_name:
        path = get_cache_path(asset_name)
        if path.exists():
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
            logger.info(f"Cleared cache for asset: {asset_name}")
    else:
        if ASSETS_CACHE_DIR.exists():
            shutil.rmtree(ASSETS_CACHE_DIR)
            logger.info("Cleared all cached assets")


def get_cache_info() -> dict:
    """
    Get information about cached assets.

    Returns:
        Dict with cache_dir, cached_assets list, and total_size_mb
    """
    if not ASSETS_CACHE_DIR.exists():
        return {
            "cache_dir": str(ASSETS_CACHE_DIR),
            "cached_assets": [],
            "total_size_mb": 0
        }

    cached = []
    total_size = 0

    for item in ASSETS_CACHE_DIR.iterdir():
        if item.is_dir():
            size = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
        else:
            size = item.stat().st_size
        cached.append({"name": item.name, "size_mb": round(size / (1024 * 1024), 2)})
        total_size += size

    return {
        "cache_dir": str(ASSETS_CACHE_DIR),
        "cached_assets": cached,
        "total_size_mb": round(total_size / (1024 * 1024), 2)
    }
