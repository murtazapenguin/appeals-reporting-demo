# START OF FILE: penguin/data_assets/models.py ---
from pydantic import BaseModel

class DataAsset(BaseModel):
    name: str
    description: str
    file_path: str
# END OF FILE: penguin/data_assets/models.py ---