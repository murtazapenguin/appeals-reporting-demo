"""
Penguin Data Assets Module

Provides access to data assets including bundled datasets, remote datasets,
and user-registered files.

Usage:
    from penguin.data_assets import load_asset, list_assets

    # See available assets
    list_assets()
    # [
    #   {'name': 'icd10', 'description': '...', 'type': 'bundled'},
    #   {'name': 'icd10_guidelines', 'description': '...', 'type': 'remote'}
    # ]

    # Load bundled asset (instant)
    icd10_df = load_asset('icd10')

    # Load remote asset (downloads on first use, then cached)
    guidelines_df = load_asset('icd10_guidelines')

Cache Management:
    from penguin.data_assets import clear_cache, get_cache_info

    # See what's cached
    get_cache_info()

    # Clear specific asset
    clear_cache('icd10_guidelines')

    # Clear all cached assets
    clear_cache()
"""

from .registry import DataAssetRegistry
from .loader import load_asset, list_assets, get_asset_info
from .remote import clear_cache, get_cache_info, is_cached

__all__ = [
    "DataAssetRegistry",
    "load_asset",
    "list_assets",
    "get_asset_info",
    "clear_cache",
    "get_cache_info",
    "is_cached",
]
