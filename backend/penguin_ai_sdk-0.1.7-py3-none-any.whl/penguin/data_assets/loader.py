"""
Penguin Data Assets Loader

Provides easy access to bundled and remote data assets.

Bundled assets are included in the package.
Remote assets are stored on S3 and downloaded on first use.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .remote import download_from_s3, is_cached, get_cache_path


# Directory where bundled data files are stored
_DATA_DIR = Path(__file__).parent

# Registry of bundled assets (included in package)
# Format: {name: {file: filename, description: str, columns: list}}
_BUNDLED_ASSETS: Dict[str, Dict] = {
    "icd10": {
        "file": "icd10cm_codes_2025.csv",
        "description": "ICD-10-CM diagnosis codes (2025 edition) with descriptions",
        "columns": ["icd_code", "icd_desc"],
    },
}

# Registry of remote assets (stored on S3, downloaded on demand)
# Format: {name: {bucket: str, key: str, description: str, columns: list, extract_zip: bool, file_in_zip: str}}
_REMOTE_ASSETS: Dict[str, Dict] = {
    "icd10_guidelines": {
        "bucket": "penguin-library",
        "key": "guidelines_text_csv.zip",
        "description": "ICD-10 coding guidelines text (extracted from CMS documentation)",
        "columns": ["chapter", "section", "guideline_text"],
        "extract_zip": True,
        "file_in_zip": "guidelines_text.csv",
    },
}


def list_assets() -> List[Dict[str, str]]:
    """
    List all available data assets (bundled and remote).

    Returns:
        List of dicts with 'name', 'description', and 'type' for each asset

    Example:
        >>> from penguin.data_assets import list_assets
        >>> list_assets()
        [
            {'name': 'icd10', 'description': 'ICD-10-CM diagnosis codes...', 'type': 'bundled'},
            {'name': 'icd10_guidelines', 'description': '...', 'type': 'remote'}
        ]
    """
    assets = [
        {"name": name, "description": info["description"], "type": "bundled"}
        for name, info in _BUNDLED_ASSETS.items()
    ]
    assets.extend([
        {
            "name": name,
            "description": info["description"],
            "type": "remote",
            "cached": is_cached(name)
        }
        for name, info in _REMOTE_ASSETS.items()
    ])
    return assets


def get_asset_info(name: str) -> Optional[Dict]:
    """
    Get detailed information about a specific asset.

    Args:
        name: Asset name (e.g., 'icd10', 'icd10_guidelines')

    Returns:
        Dict with asset info or None if not found
    """
    if name in _BUNDLED_ASSETS:
        info = _BUNDLED_ASSETS[name].copy()
        info["type"] = "bundled"
        return info
    if name in _REMOTE_ASSETS:
        info = _REMOTE_ASSETS[name].copy()
        info["type"] = "remote"
        info["cached"] = is_cached(name)
        return info
    return None


def load_asset(name: str) -> pd.DataFrame:
    """
    Load a data asset as a pandas DataFrame.

    Supports both bundled assets (in package) and remote assets (downloaded from S3).
    Remote assets are cached locally after first download.

    Args:
        name: Asset name (e.g., 'icd10', 'icd10_guidelines')

    Returns:
        pandas DataFrame with the asset data

    Raises:
        ValueError: If asset name is not found

    Example:
        >>> from penguin.data_assets import load_asset
        >>> icd10 = load_asset('icd10')  # Bundled - instant
        >>> guidelines = load_asset('icd10_guidelines')  # Remote - downloads on first use
    """
    # Check bundled assets first
    if name in _BUNDLED_ASSETS:
        asset_info = _BUNDLED_ASSETS[name]
        file_path = _DATA_DIR / asset_info["file"]

        if not file_path.exists():
            raise FileNotFoundError(f"Asset file not found: {file_path}")

        return pd.read_csv(file_path)

    # Check remote assets
    if name in _REMOTE_ASSETS:
        asset_info = _REMOTE_ASSETS[name]

        # Download if not cached
        cache_path = download_from_s3(
            bucket=asset_info["bucket"],
            key=asset_info["key"],
            asset_name=name,
            extract_zip=asset_info.get("extract_zip", False)
        )

        # Load the CSV (handle directory if extracted from zip)
        if cache_path.is_dir():
            csv_file = cache_path / asset_info.get("file_in_zip", "data.csv")
        else:
            csv_file = cache_path

        if not csv_file.exists():
            raise FileNotFoundError(f"Asset CSV not found: {csv_file}")

        return pd.read_csv(csv_file)

    # Not found in either registry
    all_assets = list(_BUNDLED_ASSETS.keys()) + list(_REMOTE_ASSETS.keys())
    raise ValueError(f"Asset '{name}' not found. Available: {', '.join(all_assets)}")
