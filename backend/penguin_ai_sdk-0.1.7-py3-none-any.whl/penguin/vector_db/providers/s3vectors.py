"""
Penguin AWS S3 Vectors Provider

AWS S3 Vectors implementation for vector database operations.
"""

import asyncio
import os
from typing import Any, Dict, List, Optional

from ..base import (
    BaseVectorDBProvider,
    VectorDBError,
    BucketNotFoundError,
    BucketAlreadyExistsError,
    IndexNotFoundError,
    IndexAlreadyExistsError,
    AuthenticationError,
    RateLimitError,
)
from ..types import (
    VectorRecord,
    VectorMatch,
    VectorQueryResult,
    IndexConfig,
    DistanceMetric,
    ProviderCapabilities,
)


class S3VectorsClient(BaseVectorDBProvider):
    """
    AWS S3 Vectors client.

    Provides vector storage and similarity search using AWS S3 Vectors.

    Supports:
    - Bucket and index management
    - Vector put, get, delete operations
    - Similarity queries with filtering
    - Cosine and Euclidean distance metrics

    Example:
        client = S3VectorsClient(bucket_name="my-vectors")
        await client.create_index("embeddings", dimension=1024)
        await client.put_vectors("embeddings", vectors)
        results = await client.query_vectors("embeddings", query_vector, top_k=10)
    """

    def __init__(
        self,
        bucket_name: Optional[str] = None,
        region_name: Optional[str] = None,
        profile_name: Optional[str] = None,
        read_timeout: int = 120,
        connect_timeout: int = 60,
        max_retries: int = 3,
        **kwargs: Any
    ):
        """
        Initialize S3 Vectors client.

        Args:
            bucket_name: Default vector bucket name
            region_name: AWS region (falls back to AWS_DEFAULT_REGION)
            profile_name: AWS profile name for credentials
            read_timeout: Read timeout in seconds
            connect_timeout: Connection timeout in seconds
            max_retries: Max retry attempts
        """
        # Lazy import boto3 - gives clear error if not installed
        try:
            import boto3
            from botocore.config import Config as BotoConfig
        except ImportError:
            raise ImportError(
                "boto3 is required for S3 Vectors. "
                "Install with: pip install penguin-ai-sdk[vector-db]"
            )

        super().__init__(bucket_name=bucket_name, **kwargs)

        region_name = region_name or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        self._region = region_name

        session_kwargs = {"region_name": region_name}
        if profile_name:
            session_kwargs["profile_name"] = profile_name

        boto_config = BotoConfig(
            read_timeout=read_timeout,
            connect_timeout=connect_timeout,
            retries={"max_attempts": max_retries, "mode": "adaptive"}
        )

        try:
            session = boto3.Session(**session_kwargs)
            self.client = session.client("s3vectors", config=boto_config)
        except Exception as e:
            raise AuthenticationError(
                f"Failed to create S3 Vectors client: {e}",
                provider="s3vectors"
            )

    @property
    def provider_name(self) -> str:
        return "s3vectors"

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supported_distance_metrics=[
                DistanceMetric.COSINE,
                DistanceMetric.EUCLIDEAN
            ],
            max_vector_dimension=4096,
            max_batch_size=100,
            max_top_k=100,
            supports_filtering=True,
            supports_metadata=True,
        )

    def _get_bucket(self, bucket_name: Optional[str] = None) -> str:
        """Get bucket name, using default if not specified."""
        bucket = bucket_name or self.bucket_name
        if not bucket:
            raise VectorDBError(
                "No bucket name specified. Provide bucket_name parameter or set default in constructor.",
                provider=self.provider_name
            )
        return bucket

    def _handle_error(self, e: Exception, operation: str) -> None:
        """Convert boto3 exceptions to Penguin exceptions."""
        error_str = str(e)
        error_type = type(e).__name__

        if "ThrottlingException" in error_type or "Throttling" in error_str:
            raise RateLimitError(str(e), provider=self.provider_name)
        elif "ResourceNotFoundException" in error_type or "not found" in error_str.lower():
            if "bucket" in error_str.lower():
                raise BucketNotFoundError(str(e), provider=self.provider_name)
            else:
                raise IndexNotFoundError(str(e), provider=self.provider_name)
        elif "ConflictException" in error_type or "already exists" in error_str.lower():
            if "bucket" in error_str.lower():
                raise BucketAlreadyExistsError(str(e), provider=self.provider_name)
            else:
                raise IndexAlreadyExistsError(str(e), provider=self.provider_name)
        else:
            raise VectorDBError(f"{operation} failed: {e}", provider=self.provider_name)

    # ================== BUCKET OPERATIONS ==================

    async def create_bucket(
        self,
        bucket_name: str,
        **kwargs: Any
    ) -> bool:
        """Create a new vector bucket."""
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None,
                lambda: self.client.create_vector_bucket(
                    vectorBucketName=bucket_name,
                    **kwargs
                )
            )
            return True
        except Exception as e:
            self._handle_error(e, "create_bucket")
            return False

    async def delete_bucket(
        self,
        bucket_name: str,
        **kwargs: Any
    ) -> bool:
        """Delete a vector bucket."""
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None,
                lambda: self.client.delete_vector_bucket(
                    vectorBucketName=bucket_name
                )
            )
            return True
        except Exception as e:
            self._handle_error(e, "delete_bucket")
            return False

    async def list_buckets(
        self,
        **kwargs: Any
    ) -> List[str]:
        """List all vector buckets."""
        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(
                None,
                lambda: self.client.list_vector_buckets()
            )
            return [b["vectorBucketName"] for b in response.get("vectorBuckets", [])]
        except Exception as e:
            self._handle_error(e, "list_buckets")
            return []

    async def bucket_exists(
        self,
        bucket_name: str
    ) -> bool:
        """Check if a bucket exists."""
        try:
            buckets = await self.list_buckets()
            return bucket_name in buckets
        except Exception:
            return False

    # ================== INDEX OPERATIONS ==================

    async def create_index(
        self,
        index_name: str,
        dimension: int,
        distance_metric: DistanceMetric = DistanceMetric.COSINE,
        bucket_name: Optional[str] = None,
        data_type: str = "float32",
        **kwargs: Any
    ) -> bool:
        """Create a new vector index.

        Args:
            index_name: Name of the index
            dimension: Vector dimension (1-4096)
            distance_metric: Distance metric (cosine, euclidean)
            bucket_name: Bucket name (uses default if not specified)
            data_type: Vector data type (default: float32)
            **kwargs: Additional parameters (e.g., metadataConfiguration)
        """
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        # S3 Vectors expects lowercase distance metric
        metric_str = distance_metric.value.lower()

        try:
            await loop.run_in_executor(
                None,
                lambda: self.client.create_index(
                    vectorBucketName=bucket,
                    indexName=index_name,
                    dimension=dimension,
                    distanceMetric=metric_str,
                    dataType=data_type,
                    **kwargs
                )
            )
            return True
        except Exception as e:
            self._handle_error(e, "create_index")
            return False

    async def delete_index(
        self,
        index_name: str,
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ) -> bool:
        """Delete a vector index."""
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        try:
            await loop.run_in_executor(
                None,
                lambda: self.client.delete_index(
                    vectorBucketName=bucket,
                    indexName=index_name
                )
            )
            return True
        except Exception as e:
            self._handle_error(e, "delete_index")
            return False

    async def list_indexes(
        self,
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ) -> List[IndexConfig]:
        """List all indexes in a bucket."""
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        try:
            response = await loop.run_in_executor(
                None,
                lambda: self.client.list_indexes(vectorBucketName=bucket)
            )
            return [
                IndexConfig(
                    name=idx["indexName"],
                    dimension=idx.get("dimension", 0),
                    distance_metric=DistanceMetric(
                        idx.get("distanceMetric", "cosine").lower()
                    ),
                    vector_count=idx.get("vectorCount", 0),
                )
                for idx in response.get("indexes", [])
            ]
        except Exception as e:
            self._handle_error(e, "list_indexes")
            return []

    async def index_exists(
        self,
        index_name: str,
        bucket_name: Optional[str] = None
    ) -> bool:
        """Check if an index exists."""
        try:
            indexes = await self.list_indexes(bucket_name)
            return any(idx.name == index_name for idx in indexes)
        except Exception:
            return False

    # ================== VECTOR OPERATIONS ==================

    async def put_vectors(
        self,
        index_name: str,
        vectors: List[VectorRecord],
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ) -> int:
        """Insert or update vectors."""
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        # Convert to S3 Vectors format
        vector_data = []
        for v in vectors:
            record = {
                "key": v.id,
                "data": {"float32": v.vector},
            }
            if v.metadata:
                record["metadata"] = v.metadata
            vector_data.append(record)

        try:
            await loop.run_in_executor(
                None,
                lambda: self.client.put_vectors(
                    vectorBucketName=bucket,
                    indexName=index_name,
                    vectors=vector_data
                )
            )
            return len(vectors)
        except Exception as e:
            self._handle_error(e, "put_vectors")
            return 0

    async def get_vectors(
        self,
        index_name: str,
        ids: List[str],
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ) -> List[VectorRecord]:
        """Retrieve vectors by ID."""
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        try:
            response = await loop.run_in_executor(
                None,
                lambda: self.client.get_vectors(
                    vectorBucketName=bucket,
                    indexName=index_name,
                    keys=ids,
                    returnData=True,
                    returnMetadata=True
                )
            )

            return [
                VectorRecord(
                    id=v["key"],
                    vector=v.get("data", {}).get("float32", []),
                    metadata=v.get("metadata", {})
                )
                for v in response.get("vectors", [])
            ]
        except Exception as e:
            self._handle_error(e, "get_vectors")
            return []

    async def delete_vectors(
        self,
        index_name: str,
        ids: List[str],
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ) -> int:
        """Delete vectors by ID."""
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        try:
            await loop.run_in_executor(
                None,
                lambda: self.client.delete_vectors(
                    vectorBucketName=bucket,
                    indexName=index_name,
                    keys=ids
                )
            )
            return len(ids)
        except Exception as e:
            self._handle_error(e, "delete_vectors")
            return 0

    async def query_vectors(
        self,
        index_name: str,
        vector: List[float],
        top_k: int = 10,
        filter: Optional[Dict[str, Any]] = None,
        include_metadata: bool = True,
        include_vectors: bool = False,
        bucket_name: Optional[str] = None,
        **kwargs: Any
    ) -> VectorQueryResult:
        """
        Query for similar vectors with optional metadata filtering.

        Args:
            index_name: Index name to query
            vector: Query vector (embedding)
            top_k: Number of results (max 100 for S3 Vectors)
            filter: Metadata filter (see AWS S3 Vectors filter syntax)
            include_metadata: Include metadata in results
            include_vectors: Include vector data in results
            bucket_name: Override default bucket

        Returns:
            VectorQueryResult with matches

        Examples:
            # Basic query
            results = await client.query_vectors("docs", vector, top_k=10)

            # With filtering
            results = await client.query_vectors(
                "docs",
                vector,
                filter={"tenant_id": "acme", "status": "published"}
            )

        Note:
            S3 Vectors filter syntax: https://docs.aws.amazon.com/s3/vectors/
        """
        bucket = self._get_bucket(bucket_name)
        loop = asyncio.get_event_loop()

        query_params = {
            "vectorBucketName": bucket,
            "indexName": index_name,
            "queryVector": {"float32": vector},
            "topK": min(top_k, 100),  # S3 Vectors max is 100
            "returnMetadata": include_metadata,
            "returnDistance": True,
        }

        if include_vectors:
            query_params["returnData"] = True

        if filter:
            query_params["filter"] = filter

        try:
            response = await loop.run_in_executor(
                None,
                lambda: self.client.query_vectors(**query_params)
            )

            matches = [
                VectorMatch(
                    id=m["key"],
                    score=m.get("distance", 0.0),
                    vector=m.get("data", {}).get("float32") if include_vectors else None,
                    metadata=m.get("metadata", {}) if include_metadata else {}
                )
                for m in response.get("vectors", [])
            ]

            return VectorQueryResult(
                matches=matches,
                query_vector_dimension=len(vector),
                index_name=index_name,
                provider=self.provider_name,
            )
        except Exception as e:
            self._handle_error(e, "query_vectors")
            # Return empty result on error
            return VectorQueryResult(
                matches=[],
                query_vector_dimension=len(vector),
                index_name=index_name,
                provider=self.provider_name,
            )
