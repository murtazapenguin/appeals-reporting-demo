"""
Penguin Vector DB Types Module

Defines standardized types for vector database operations.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from enum import Enum


class DistanceMetric(str, Enum):
    """Supported distance metrics."""
    COSINE = "cosine"
    EUCLIDEAN = "euclidean"


class VectorRecord(BaseModel):
    """
    A single vector with its ID and optional metadata.
    """
    id: str
    vector: List[float]
    metadata: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        arbitrary_types_allowed = True


class VectorMatch(BaseModel):
    """
    A single match from a vector query.
    """
    id: str
    score: float
    vector: Optional[List[float]] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class VectorQueryResult(BaseModel):
    """
    Result from a vector query operation.
    """
    matches: List[VectorMatch] = Field(default_factory=list)

    # Query metadata
    query_vector_dimension: int
    index_name: str

    # Provider info
    provider: str

    # Additional response metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @property
    def top_match(self) -> Optional[VectorMatch]:
        """Get the top scoring match."""
        return self.matches[0] if self.matches else None

    @property
    def ids(self) -> List[str]:
        """Get all matched IDs."""
        return [m.id for m in self.matches]

    @property
    def scores(self) -> List[float]:
        """Get all match scores."""
        return [m.score for m in self.matches]


class IndexConfig(BaseModel):
    """Configuration for a vector index."""
    name: str
    dimension: int
    distance_metric: DistanceMetric = DistanceMetric.COSINE
    vector_count: int = 0
    metadata: Dict[str, Any] = Field(default_factory=dict)


class BucketConfig(BaseModel):
    """Configuration for a vector bucket."""
    name: str
    region: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ProviderCapabilities(BaseModel):
    """Declares what a vector DB provider supports."""
    supported_distance_metrics: List[DistanceMetric] = [
        DistanceMetric.COSINE,
        DistanceMetric.EUCLIDEAN
    ]
    max_vector_dimension: int = 4096
    max_batch_size: int = 100
    max_top_k: int = 100
    supports_filtering: bool = True
    supports_metadata: bool = True
