"""
Penguin Vector DB Provider Registry

Centralized vector database provider definitions with capabilities.
Adding a new vector DB provider? Just add it to the PROVIDERS dict below!
"""

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional
from enum import Enum

from .types import DistanceMetric

logger = logging.getLogger(__name__)


class Provider(str, Enum):
    """Supported vector database providers."""
    S3VECTORS = "s3vectors"
    # Future providers:
    # PINECONE = "pinecone"
    # WEAVIATE = "weaviate"
    # CHROMA = "chroma"
    # QDRANT = "qdrant"
    # MILVUS = "milvus"
    # PGVECTOR = "pgvector"


@dataclass
class VectorDBInfo:
    """
    Vector database provider metadata and capabilities.

    Attributes:
        id: Provider identifier (e.g., "s3vectors")
        provider: Provider enum value
        display_name: Human-readable provider name
        supported_metrics: List of supported distance metrics
        default_metric: Default distance metric
        max_vector_dimension: Maximum vector dimension supported
        max_batch_size: Maximum batch size for vector operations
        max_top_k: Maximum top-K results in queries
        supports_filtering: Whether metadata filtering is supported
        supports_metadata: Whether metadata storage is supported
        supports_namespaces: Whether namespaces/collections are supported
        requires_bucket: Whether a bucket/database needs to be created first
        cloud_service: Whether it's a cloud-managed service
        region_required: Whether region configuration is required
        description: Human-readable description
    """
    id: str
    provider: Provider
    display_name: str
    supported_metrics: List[DistanceMetric]
    default_metric: DistanceMetric = DistanceMetric.COSINE
    max_vector_dimension: int = 4096
    max_batch_size: int = 100
    max_top_k: int = 100
    supports_filtering: bool = True
    supports_metadata: bool = True
    supports_namespaces: bool = True
    requires_bucket: bool = False
    cloud_service: bool = False
    region_required: bool = False
    description: str = ""

    def supports_metric(self, metric: DistanceMetric) -> bool:
        """Check if this provider supports a specific distance metric."""
        return metric in self.supported_metrics

    def supports_dimension(self, dimension: int) -> bool:
        """Check if this provider supports a specific dimension."""
        return 0 < dimension <= self.max_vector_dimension


# =============================================================================
# PROVIDER DEFINITIONS
# =============================================================================
# To add a new vector DB provider, just add an entry here!
# The provider will automatically be available in list_providers().

PROVIDERS: Dict[str, VectorDBInfo] = {
    # =========================================================================
    # AWS S3 VECTORS
    # =========================================================================
    "s3vectors": VectorDBInfo(
        id="s3vectors",
        provider=Provider.S3VECTORS,
        display_name="AWS S3 Vectors",
        supported_metrics=[DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
        default_metric=DistanceMetric.COSINE,
        max_vector_dimension=4096,
        max_batch_size=100,
        max_top_k=100,
        supports_filtering=True,
        supports_metadata=True,
        supports_namespaces=True,  # S3 Vectors uses indexes as namespaces
        requires_bucket=True,  # S3 Vectors requires bucket creation
        cloud_service=True,
        region_required=True,
        description="AWS S3 Vectors - Managed vector storage with S3 integration",
    ),

    # Future providers - commented out for reference
    # =========================================================================
    # # PINECONE
    # =========================================================================
    # "pinecone": VectorDBInfo(
    #     id="pinecone",
    #     provider=Provider.PINECONE,
    #     display_name="Pinecone",
    #     supported_metrics=[DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
    #     default_metric=DistanceMetric.COSINE,
    #     max_vector_dimension=20000,
    #     max_batch_size=100,
    #     max_top_k=10000,
    #     supports_filtering=True,
    #     supports_metadata=True,
    #     supports_namespaces=True,
    #     requires_bucket=False,  # Pinecone manages indexes directly
    #     cloud_service=True,
    #     region_required=True,
    #     description="Pinecone - Fully managed vector database with low latency",
    # ),
    #
    # =========================================================================
    # # WEAVIATE
    # =========================================================================
    # "weaviate": VectorDBInfo(
    #     id="weaviate",
    #     provider=Provider.WEAVIATE,
    #     display_name="Weaviate",
    #     supported_metrics=[DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
    #     default_metric=DistanceMetric.COSINE,
    #     max_vector_dimension=65535,
    #     max_batch_size=100,
    #     max_top_k=10000,
    #     supports_filtering=True,
    #     supports_metadata=True,
    #     supports_namespaces=True,
    #     requires_bucket=False,
    #     cloud_service=False,  # Can be self-hosted or cloud
    #     region_required=False,
    #     description="Weaviate - Open-source vector database with GraphQL API",
    # ),
    #
    # =========================================================================
    # # CHROMA
    # =========================================================================
    # "chroma": VectorDBInfo(
    #     id="chroma",
    #     provider=Provider.CHROMA,
    #     display_name="ChromaDB",
    #     supported_metrics=[DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
    #     default_metric=DistanceMetric.COSINE,
    #     max_vector_dimension=16384,
    #     max_batch_size=1000,
    #     max_top_k=1000,
    #     supports_filtering=True,
    #     supports_metadata=True,
    #     supports_namespaces=True,  # Chroma uses collections
    #     requires_bucket=False,
    #     cloud_service=False,
    #     region_required=False,
    #     description="ChromaDB - Lightweight, open-source embedding database",
    # ),
    #
    # =========================================================================
    # # QDRANT
    # =========================================================================
    # "qdrant": VectorDBInfo(
    #     id="qdrant",
    #     provider=Provider.QDRANT,
    #     display_name="Qdrant",
    #     supported_metrics=[DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
    #     default_metric=DistanceMetric.COSINE,
    #     max_vector_dimension=65535,
    #     max_batch_size=100,
    #     max_top_k=10000,
    #     supports_filtering=True,
    #     supports_metadata=True,
    #     supports_namespaces=True,
    #     requires_bucket=False,
    #     cloud_service=False,
    #     region_required=False,
    #     description="Qdrant - High-performance vector search engine with filtering",
    # ),
    #
    # =========================================================================
    # # PGVECTOR
    # =========================================================================
    # "pgvector": VectorDBInfo(
    #     id="pgvector",
    #     provider=Provider.PGVECTOR,
    #     display_name="pgvector",
    #     supported_metrics=[DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
    #     default_metric=DistanceMetric.COSINE,
    #     max_vector_dimension=16000,
    #     max_batch_size=1000,
    #     max_top_k=1000,
    #     supports_filtering=True,
    #     supports_metadata=True,
    #     supports_namespaces=True,  # Uses PostgreSQL tables
    #     requires_bucket=False,
    #     cloud_service=False,
    #     region_required=False,
    #     description="pgvector - PostgreSQL extension for vector similarity search",
    # ),
}


# =============================================================================
# DEFAULT PROVIDERS
# =============================================================================

DEFAULT_PROVIDER = "s3vectors"


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_provider(provider_id: str) -> Optional[VectorDBInfo]:
    """
    Get vector DB provider info by ID.

    Args:
        provider_id: Provider identifier (e.g., "s3vectors", "pinecone")

    Returns:
        VectorDBInfo or None if not found

    Example:
        provider = get_provider("s3vectors")
        if provider:
            print(f"Supported metrics: {provider.supported_metrics}")
    """
    return PROVIDERS.get(provider_id)


def list_providers() -> List[VectorDBInfo]:
    """
    List all available vector database providers.

    Returns:
        List of VectorDBInfo objects

    Example:
        # List all providers
        all_providers = list_providers()
        for provider in all_providers:
            print(f"{provider.id}: {provider.description}")
    """
    return list(PROVIDERS.values())


def get_default_provider() -> str:
    """
    Get default vector database provider ID.

    Returns:
        Default provider ID

    Example:
        default = get_default_provider()  # Returns "s3vectors"
    """
    return DEFAULT_PROVIDER


def get_providers_by_metric(metric: DistanceMetric) -> List[VectorDBInfo]:
    """
    Get vector DB providers that support a specific distance metric.

    Args:
        metric: Target distance metric

    Returns:
        List of providers supporting the metric

    Example:
        # Find providers supporting cosine similarity
        cosine_providers = get_providers_by_metric(DistanceMetric.COSINE)
    """
    return [p for p in PROVIDERS.values() if p.supports_metric(metric)]


def get_providers_by_dimension(dimension: int) -> List[VectorDBInfo]:
    """
    Get vector DB providers that support a specific vector dimension.

    Args:
        dimension: Target vector dimension

    Returns:
        List of providers supporting the dimension

    Example:
        # Find providers supporting 1024-dimensional vectors
        providers_1024 = get_providers_by_dimension(1024)
    """
    return [p for p in PROVIDERS.values() if p.supports_dimension(dimension)]


def get_cloud_providers() -> List[VectorDBInfo]:
    """
    Get cloud-managed vector database providers.

    Returns:
        List of cloud-managed providers

    Example:
        cloud_providers = get_cloud_providers()
    """
    return [p for p in PROVIDERS.values() if p.cloud_service]


def get_self_hosted_providers() -> List[VectorDBInfo]:
    """
    Get self-hosted vector database providers.

    Returns:
        List of self-hosted providers

    Example:
        self_hosted = get_self_hosted_providers()
    """
    return [p for p in PROVIDERS.values() if not p.cloud_service]


def get_provider_capabilities(provider_id: str) -> Dict[str, any]:
    """
    Get capabilities for a specific vector DB provider.

    Args:
        provider_id: Provider identifier

    Returns:
        Dict with capability information

    Example:
        caps = get_provider_capabilities("s3vectors")
        # Returns: {
        #     "supported_metrics": [DistanceMetric.COSINE, DistanceMetric.EUCLIDEAN],
        #     "default_metric": DistanceMetric.COSINE,
        #     "max_vector_dimension": 4096,
        #     "max_batch_size": 100,
        #     "max_top_k": 100,
        #     "supports_filtering": True,
        #     "supports_metadata": True,
        #     "supports_namespaces": True
        # }
    """
    provider = PROVIDERS.get(provider_id)
    if provider:
        return {
            "supported_metrics": provider.supported_metrics,
            "default_metric": provider.default_metric,
            "max_vector_dimension": provider.max_vector_dimension,
            "max_batch_size": provider.max_batch_size,
            "max_top_k": provider.max_top_k,
            "supports_filtering": provider.supports_filtering,
            "supports_metadata": provider.supports_metadata,
            "supports_namespaces": provider.supports_namespaces,
            "requires_bucket": provider.requires_bucket,
            "cloud_service": provider.cloud_service,
            "region_required": provider.region_required,
        }
    return {
        "supported_metrics": [DistanceMetric.COSINE],
        "default_metric": DistanceMetric.COSINE,
        "max_vector_dimension": 4096,
        "max_batch_size": 100,
        "max_top_k": 100,
        "supports_filtering": True,
        "supports_metadata": True,
        "supports_namespaces": True,
        "requires_bucket": False,
        "cloud_service": False,
        "region_required": False,
    }


def validate_metric(provider_id: str, metric: DistanceMetric) -> bool:
    """
    Check if a distance metric is valid for a given provider.

    Args:
        provider_id: Provider identifier
        metric: Distance metric to validate

    Returns:
        True if metric is supported, False otherwise

    Example:
        if validate_metric("s3vectors", DistanceMetric.COSINE):
            print("Cosine similarity supported!")
    """
    provider = get_provider(provider_id)
    if provider:
        return provider.supports_metric(metric)
    # If provider not found, assume metric is valid
    return True


def validate_dimension(provider_id: str, dimension: int) -> bool:
    """
    Check if a vector dimension is valid for a given provider.

    Args:
        provider_id: Provider identifier
        dimension: Vector dimension to validate

    Returns:
        True if dimension is supported, False otherwise

    Example:
        if validate_dimension("s3vectors", 1024):
            print("1024 dimensions supported!")
    """
    provider = get_provider(provider_id)
    if provider:
        return provider.supports_dimension(dimension)
    # If provider not found, assume dimension is valid
    return True


def compare_providers(provider_ids: List[str]) -> Dict[str, Dict[str, any]]:
    """
    Compare capabilities of multiple providers.

    Args:
        provider_ids: List of provider IDs to compare

    Returns:
        Dict mapping provider IDs to their capabilities

    Example:
        comparison = compare_providers(["s3vectors", "pinecone"])
        for provider_id, caps in comparison.items():
            print(f"{provider_id}: {caps['max_vector_dimension']} dimensions")
    """
    return {
        provider_id: get_provider_capabilities(provider_id)
        for provider_id in provider_ids
        if get_provider(provider_id)
    }
