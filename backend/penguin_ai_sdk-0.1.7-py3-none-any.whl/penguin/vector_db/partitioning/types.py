"""
Partitioning Types Module

Type definitions for partitioning, namespacing, and tenant isolation.
"""

from enum import Enum
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field, validator


class PartitionStrategy(str, Enum):
    """Partition strategy types."""
    HASH = "hash"           # Hash-based partitioning (even distribution)
    RANGE = "range"         # Range-based partitioning (time-series, numeric)
    LIST = "list"           # List-based partitioning (explicit values)
    HIERARCHICAL = "hierarchical"  # Hierarchical namespaces


class TenantIsolationLevel(str, Enum):
    """Tenant isolation levels."""
    DEDICATED = "dedicated"     # Dedicated index per tenant (strongest)
    SHARED = "shared"           # Shared index with partition keys
    HYBRID = "hybrid"           # Mix of dedicated and shared


class PartitionKey(BaseModel):
    """
    Partition key specification.

    Examples:
        # Simple key
        PartitionKey(field="tenant_id", value="acme_corp")

        # Hierarchical key
        PartitionKey(
            field="namespace",
            value="tenant:acme_corp/project:proj_a/env:prod"
        )

        # Multiple keys
        PartitionKey(
            field="composite",
            values={"tenant_id": "acme", "region": "us-east"}
        )
    """
    field: str
    value: Optional[str] = None
    values: Optional[Dict[str, Any]] = None

    @validator('values')
    def value_or_values_required(cls, v, values):
        """Ensure either value or values is provided."""
        if v is None and values.get('value') is None:
            raise ValueError("Either 'value' or 'values' must be provided")
        return v

    def to_string(self) -> str:
        """Convert partition key to string representation."""
        if self.value:
            return f"{self.field}:{self.value}"
        if self.values:
            parts = [f"{k}:{v}" for k, v in self.values.items()]
            return "/".join(parts)
        return self.field


class PartitionConfig(BaseModel):
    """
    Configuration for index partitioning.

    Attributes:
        strategy: Partitioning strategy (hash, range, list, hierarchical)
        key_field: Field name to partition on (e.g., "tenant_id")
        num_partitions: Number of partitions (for hash strategy)
        ranges: Range definitions (for range strategy)
        values: Allowed values (for list strategy)
        enforcement: Whether to enforce partition boundaries strictly
        auto_create: Auto-create partitions on demand
    """
    strategy: PartitionStrategy
    key_field: str
    num_partitions: Optional[int] = None
    ranges: Optional[List[Dict[str, Any]]] = None
    values: Optional[List[str]] = None
    enforcement: str = "strict"  # "strict" or "relaxed"
    auto_create: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @validator('num_partitions')
    def validate_num_partitions(cls, v, values):
        """Validate num_partitions for hash strategy."""
        if values.get('strategy') == PartitionStrategy.HASH and v is None:
            raise ValueError("num_partitions required for hash strategy")
        return v

    @validator('ranges')
    def validate_ranges(cls, v, values):
        """Validate ranges for range strategy."""
        if values.get('strategy') == PartitionStrategy.RANGE and not v:
            raise ValueError("ranges required for range strategy")
        return v

    @validator('values')
    def validate_values(cls, v, values):
        """Validate values for list strategy."""
        if values.get('strategy') == PartitionStrategy.LIST and not v:
            raise ValueError("values required for list strategy")
        return v


class SubsetQuery(BaseModel):
    """
    Configuration for querying a subset of vectors.

    Examples:
        # Time-based subset
        SubsetQuery(
            type="time_range",
            field="created_at",
            start="2024-01-01",
            end="2024-12-31"
        )

        # Category subset
        SubsetQuery(
            type="category",
            categories=["engineering", "product"]
        )

        # Permission-based subset
        SubsetQuery(
            type="permission",
            user_id="user_123",
            roles=["engineer", "viewer"]
        )
    """
    type: str  # "time_range", "category", "permission", "hierarchy"
    field: Optional[str] = None
    start: Optional[str] = None
    end: Optional[str] = None
    window: Optional[str] = None  # e.g., "30d", "7d"
    categories: Optional[List[str]] = None
    exclude: Optional[List[str]] = None
    user_id: Optional[str] = None
    roles: Optional[List[str]] = None
    path: Optional[str] = None  # Hierarchical path
    metadata: Dict[str, Any] = Field(default_factory=dict)


class PartitionInfo(BaseModel):
    """Information about a partition."""
    id: str
    name: str
    index_name: str
    partition_key: str
    vector_count: int = 0
    size_mb: float = 0.0
    created_at: Optional[str] = None
    last_updated: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class PartitionStats(BaseModel):
    """Statistics for partition performance."""
    partition_id: str
    vector_count: int
    avg_query_latency_ms: float
    total_queries: int
    cache_hit_rate: float = 0.0
    last_accessed: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
