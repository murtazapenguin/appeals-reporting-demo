"""
Partition Strategy Implementations

Provides different partitioning strategies for vector databases.
"""

import hashlib
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

from .types import PartitionConfig, PartitionStrategy


class BasePartitionStrategy(ABC):
    """
    Abstract base class for partition strategies.

    All partition strategies must implement:
    - get_partition_id: Determine partition for a given key
    - list_partitions: List all available partitions
    - validate_key: Validate partition key
    """

    def __init__(self, config: PartitionConfig):
        """
        Initialize partition strategy.

        Args:
            config: Partition configuration
        """
        self.config = config

    @abstractmethod
    def get_partition_id(self, key_value: Any) -> str:
        """
        Get partition ID for a given key value.

        Args:
            key_value: Value of the partition key

        Returns:
            Partition identifier

        Example:
            partition_id = strategy.get_partition_id("acme_corp")
            # Returns: "partition_0" or "tenant_acme_corp"
        """
        pass

    @abstractmethod
    def list_partitions(self) -> List[str]:
        """
        List all available partitions.

        Returns:
            List of partition identifiers
        """
        pass

    @abstractmethod
    def validate_key(self, key_value: Any) -> bool:
        """
        Validate if key value is valid for this strategy.

        Args:
            key_value: Value to validate

        Returns:
            True if valid, False otherwise
        """
        pass


class HashPartitionStrategy(BasePartitionStrategy):
    """
    Hash-based partitioning strategy.

    Distributes data evenly across N partitions using consistent hashing.
    Best for: Multi-tenant systems with even distribution requirements.

    Example:
        config = PartitionConfig(
            strategy=PartitionStrategy.HASH,
            key_field="tenant_id",
            num_partitions=10
        )
        strategy = HashPartitionStrategy(config)

        # All data for "acme_corp" goes to same partition
        partition_id = strategy.get_partition_id("acme_corp")
        # Returns: "partition_3"
    """

    def __init__(self, config: PartitionConfig):
        super().__init__(config)
        if not config.num_partitions:
            raise ValueError("num_partitions required for hash strategy")
        self.num_partitions = config.num_partitions

    def get_partition_id(self, key_value: Any) -> str:
        """Get partition using consistent hashing."""
        if key_value is None:
            raise ValueError("key_value cannot be None for hash partitioning")

        # Convert to string and hash
        key_str = str(key_value)
        hash_value = int(hashlib.md5(key_str.encode()).hexdigest(), 16)

        # Modulo to get partition number
        partition_num = hash_value % self.num_partitions

        return f"partition_{partition_num}"

    def list_partitions(self) -> List[str]:
        """List all hash partitions."""
        return [f"partition_{i}" for i in range(self.num_partitions)]

    def validate_key(self, key_value: Any) -> bool:
        """Validate key - any non-None value is valid."""
        return key_value is not None


class RangePartitionStrategy(BasePartitionStrategy):
    """
    Range-based partitioning strategy.

    Partitions data based on value ranges.
    Best for: Time-series data, numeric ranges, alphabetical sorting.

    Example:
        config = PartitionConfig(
            strategy=PartitionStrategy.RANGE,
            key_field="created_at",
            ranges=[
                {"name": "2024_q1", "start": "2024-01-01", "end": "2024-03-31"},
                {"name": "2024_q2", "start": "2024-04-01", "end": "2024-06-30"},
                {"name": "2024_q3", "start": "2024-07-01", "end": "2024-09-30"},
                {"name": "2024_q4", "start": "2024-10-01", "end": "2024-12-31"},
            ]
        )
        strategy = RangePartitionStrategy(config)

        # Route to correct quarter
        partition_id = strategy.get_partition_id("2024-05-15")
        # Returns: "2024_q2"
    """

    def __init__(self, config: PartitionConfig):
        super().__init__(config)
        if not config.ranges:
            raise ValueError("ranges required for range strategy")
        self.ranges = config.ranges

    def get_partition_id(self, key_value: Any) -> str:
        """Get partition based on range."""
        if key_value is None:
            raise ValueError("key_value cannot be None for range partitioning")

        # Try to parse as datetime if string
        if isinstance(key_value, str):
            try:
                key_value = datetime.fromisoformat(key_value.replace('Z', '+00:00'))
            except (ValueError, AttributeError):
                pass

        # Find matching range
        for range_def in self.ranges:
            start = range_def.get("start")
            end = range_def.get("end")

            # Parse range bounds
            if isinstance(start, str):
                start = datetime.fromisoformat(start.replace('Z', '+00:00'))
            if isinstance(end, str):
                end = datetime.fromisoformat(end.replace('Z', '+00:00'))

            # Check if value falls in range
            if isinstance(key_value, datetime):
                if start <= key_value <= end:
                    return range_def["name"]
            else:
                if start <= key_value <= end:
                    return range_def["name"]

        # Default partition if no match
        return "default"

    def list_partitions(self) -> List[str]:
        """List all range partitions."""
        return [r["name"] for r in self.ranges] + ["default"]

    def validate_key(self, key_value: Any) -> bool:
        """Validate key - must be comparable."""
        return key_value is not None


class ListPartitionStrategy(BasePartitionStrategy):
    """
    List-based partitioning strategy.

    Explicit partition assignment based on predefined values.
    Best for: Fixed categories, regions, departments.

    Example:
        config = PartitionConfig(
            strategy=PartitionStrategy.LIST,
            key_field="region",
            values=["us-east", "us-west", "eu-west", "ap-south"]
        )
        strategy = ListPartitionStrategy(config)

        partition_id = strategy.get_partition_id("us-east")
        # Returns: "region_us-east"
    """

    def __init__(self, config: PartitionConfig):
        super().__init__(config)
        if not config.values:
            raise ValueError("values required for list strategy")
        self.values = config.values

    def get_partition_id(self, key_value: Any) -> str:
        """Get partition based on explicit list."""
        if key_value is None:
            raise ValueError("key_value cannot be None for list partitioning")

        key_str = str(key_value)

        if key_str in self.values:
            return f"{self.config.key_field}_{key_str}"

        # Default partition if not in list
        return f"{self.config.key_field}_other"

    def list_partitions(self) -> List[str]:
        """List all value-based partitions."""
        partitions = [f"{self.config.key_field}_{v}" for v in self.values]
        partitions.append(f"{self.config.key_field}_other")
        return partitions

    def validate_key(self, key_value: Any) -> bool:
        """Validate key - must be in allowed values."""
        return str(key_value) in self.values


class HierarchicalPartitionStrategy(BasePartitionStrategy):
    """
    Hierarchical namespace partitioning strategy.

    Supports multi-level namespaces with wildcards.
    Best for: Complex organizational structures, project hierarchies.

    Example:
        config = PartitionConfig(
            strategy=PartitionStrategy.HIERARCHICAL,
            key_field="namespace"
        )
        strategy = HierarchicalPartitionStrategy(config)

        # Hierarchical namespace
        partition_id = strategy.get_partition_id(
            "tenant:acme_corp/project:proj_a/env:prod"
        )
        # Returns: "tenant_acme_corp_project_proj_a_env_prod"

        # Wildcard support
        partitions = strategy.get_partitions_for_pattern(
            "tenant:acme_corp/project:*/env:prod"
        )
        # Returns: All prod partitions for acme_corp across all projects
    """

    def __init__(self, config: PartitionConfig):
        super().__init__(config)
        self.separator = "/"
        self.level_separator = ":"

    def get_partition_id(self, key_value: Any) -> str:
        """Get partition from hierarchical path."""
        if key_value is None:
            raise ValueError("key_value cannot be None for hierarchical partitioning")

        path = str(key_value)

        # Convert path to partition ID
        # "tenant:acme/project:a/env:prod" -> "tenant_acme_project_a_env_prod"
        partition_id = path.replace(self.separator, "_").replace(self.level_separator, "_")

        return partition_id

    def get_partitions_for_pattern(self, pattern: str) -> List[str]:
        """
        Get partitions matching a wildcard pattern.

        Args:
            pattern: Pattern with wildcards (e.g., "tenant:acme/project:*/env:prod")

        Returns:
            List of matching partition IDs
        """
        # In real implementation, this would query the database
        # For now, return pattern-based ID
        return [self.get_partition_id(pattern.replace("*", "wildcard"))]

    def list_partitions(self) -> List[str]:
        """List all hierarchical partitions."""
        # This would typically be dynamically generated
        return []

    def validate_key(self, key_value: Any) -> bool:
        """Validate hierarchical path format."""
        if not key_value:
            return False

        path = str(key_value)

        # Check format: "level1:value1/level2:value2/..."
        if self.separator not in path and self.level_separator not in path:
            return False

        return True

    def parse_path(self, path: str) -> Dict[str, str]:
        """
        Parse hierarchical path into components.

        Args:
            path: Hierarchical path (e.g., "tenant:acme/project:a")

        Returns:
            Dictionary of level -> value mappings
        """
        components = {}
        parts = path.split(self.separator)

        for part in parts:
            if self.level_separator in part:
                level, value = part.split(self.level_separator, 1)
                components[level] = value

        return components


def create_partition_strategy(config: PartitionConfig) -> BasePartitionStrategy:
    """
    Factory function to create appropriate partition strategy.

    Args:
        config: Partition configuration

    Returns:
        Appropriate partition strategy instance

    Example:
        config = PartitionConfig(
            strategy=PartitionStrategy.HASH,
            key_field="tenant_id",
            num_partitions=10
        )
        strategy = create_partition_strategy(config)
    """
    strategy_map = {
        PartitionStrategy.HASH: HashPartitionStrategy,
        PartitionStrategy.RANGE: RangePartitionStrategy,
        PartitionStrategy.LIST: ListPartitionStrategy,
        PartitionStrategy.HIERARCHICAL: HierarchicalPartitionStrategy,
    }

    strategy_class = strategy_map.get(config.strategy)
    if not strategy_class:
        raise ValueError(f"Unknown partition strategy: {config.strategy}")

    return strategy_class(config)
