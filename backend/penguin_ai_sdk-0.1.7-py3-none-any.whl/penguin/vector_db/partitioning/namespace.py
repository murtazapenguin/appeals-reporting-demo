"""
Namespace Manager

Manages hierarchical namespaces for vector databases.
"""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class Namespace(BaseModel):
    """
    Represents a hierarchical namespace.

    Examples:
        # Simple namespace
        ns = Namespace(path="tenant:acme_corp")

        # Hierarchical namespace
        ns = Namespace(
            path="tenant:acme_corp/project:proj_a/env:prod",
            metadata={"created_by": "admin"}
        )
    """
    path: str
    parent: Optional[str] = None
    children: List[str] = []
    metadata: Dict[str, Any] = {}

    def get_components(self) -> Dict[str, str]:
        """Parse namespace path into components."""
        components = {}
        parts = self.path.split("/")

        for part in parts:
            if ":" in part:
                key, value = part.split(":", 1)
                components[key] = value

        return components

    def matches_pattern(self, pattern: str) -> bool:
        """
        Check if namespace matches a wildcard pattern.

        Args:
            pattern: Pattern with wildcards (e.g., "tenant:acme/project:*/env:prod")

        Returns:
            True if matches, False otherwise
        """
        pattern_parts = pattern.split("/")
        path_parts = self.path.split("/")

        if len(pattern_parts) != len(path_parts):
            return False

        for pattern_part, path_part in zip(pattern_parts, path_parts):
            if pattern_part == "*":
                continue
            if ":" in pattern_part and ":" in path_part:
                p_key, p_val = pattern_part.split(":", 1)
                path_key, path_val = path_part.split(":", 1)

                if p_key != path_key:
                    return False
                if p_val != "*" and p_val != path_val:
                    return False
            elif pattern_part != path_part:
                return False

        return True


class NamespaceManager:
    """
    Manages hierarchical namespaces for multi-level organization.

    Example:
        manager = NamespaceManager()

        # Create hierarchical namespace
        manager.create_namespace(
            "tenant:acme_corp/project:proj_a/env:prod"
        )

        # Query with wildcards
        namespaces = manager.find_namespaces(
            "tenant:acme_corp/project:*/env:prod"
        )
    """

    def __init__(self):
        self.namespaces: Dict[str, Namespace] = {}

    def create_namespace(
        self,
        path: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Namespace:
        """
        Create a new namespace.

        Args:
            path: Hierarchical path (e.g., "tenant:acme/project:a/env:prod")
            metadata: Optional metadata

        Returns:
            Created namespace
        """
        namespace = Namespace(
            path=path,
            metadata=metadata or {}
        )

        # Determine parent
        parts = path.rsplit("/", 1)
        if len(parts) == 2:
            namespace.parent = parts[0]

            # Update parent's children
            if parts[0] in self.namespaces:
                if path not in self.namespaces[parts[0]].children:
                    self.namespaces[parts[0]].children.append(path)

        self.namespaces[path] = namespace
        return namespace

    def get_namespace(self, path: str) -> Optional[Namespace]:
        """Get namespace by path."""
        return self.namespaces.get(path)

    def delete_namespace(self, path: str, recursive: bool = False) -> bool:
        """
        Delete a namespace.

        Args:
            path: Namespace path to delete
            recursive: If True, delete children as well

        Returns:
            True if deleted, False if not found
        """
        namespace = self.namespaces.get(path)
        if not namespace:
            return False

        if recursive:
            # Delete all children
            for child_path in list(namespace.children):
                self.delete_namespace(child_path, recursive=True)

        # Remove from parent's children
        if namespace.parent and namespace.parent in self.namespaces:
            parent = self.namespaces[namespace.parent]
            if path in parent.children:
                parent.children.remove(path)

        del self.namespaces[path]
        return True

    def find_namespaces(self, pattern: str) -> List[Namespace]:
        """
        Find namespaces matching a wildcard pattern.

        Args:
            pattern: Pattern with wildcards (e.g., "tenant:*/project:a/*")

        Returns:
            List of matching namespaces
        """
        matches = []

        for namespace in self.namespaces.values():
            if namespace.matches_pattern(pattern):
                matches.append(namespace)

        return matches

    def list_children(self, parent_path: str) -> List[Namespace]:
        """List all direct children of a namespace."""
        parent = self.namespaces.get(parent_path)
        if not parent:
            return []

        return [
            self.namespaces[child_path]
            for child_path in parent.children
            if child_path in self.namespaces
        ]

    def get_root_namespaces(self) -> List[Namespace]:
        """Get all root-level namespaces (no parent)."""
        return [
            ns for ns in self.namespaces.values()
            if ns.parent is None
        ]
