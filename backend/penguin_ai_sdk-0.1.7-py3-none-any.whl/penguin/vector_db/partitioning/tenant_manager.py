"""
Tenant Manager

Manages multi-tenant configurations and routing.
"""

import logging
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

from ..base import BaseVectorDBProvider
from .types import TenantIsolationLevel, PartitionConfig, PartitionStrategy

logger = logging.getLogger(__name__)


class TenantConfig(BaseModel):
    """
    Configuration for a tenant.

    Attributes:
        tenant_id: Unique tenant identifier
        isolation_level: Level of isolation (dedicated, shared, hybrid)
        index_name: Index name (for dedicated) or shared index
        partition_key: Partition key for shared indices
        dimension: Vector dimension
        tier: Service tier (premium, standard, basic)
        sla_ms: SLA for query latency in milliseconds
        max_vectors: Maximum vectors allowed
        metadata: Additional tenant metadata
    """
    tenant_id: str
    isolation_level: TenantIsolationLevel
    index_name: Optional[str] = None
    partition_key: Optional[str] = None
    dimension: int = 1024
    tier: str = "standard"  # premium, standard, basic
    sla_ms: int = 100
    max_vectors: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TenantManager:
    """
    Manages multi-tenant vector database configurations.

    Supports multiple tenancy patterns:
    1. Dedicated index per tenant (strongest isolation)
    2. Shared index with partition keys (cost-effective)
    3. Hybrid approach (mix of both based on tier)

    Example:
        manager = TenantManager(vector_client)

        # Create premium tenant with dedicated index
        await manager.create_tenant(
            tenant_id="acme_corp",
            isolation_level=TenantIsolationLevel.DEDICATED,
            tier="premium",
            dimension=1024
        )

        # Create standard tenant in shared index
        await manager.create_tenant(
            tenant_id="startup_123",
            isolation_level=TenantIsolationLevel.SHARED,
            tier="standard",
            dimension=1024
        )

        # Query routes to correct index automatically
        results = await manager.query_for_tenant(
            tenant_id="acme_corp",
            vector=query_vector,
            top_k=10
        )
    """

    def __init__(
        self,
        client: BaseVectorDBProvider,
        shared_index_name: str = "vectors_shared",
        auto_create_shared: bool = True
    ):
        """
        Initialize tenant manager.

        Args:
            client: Vector database client
            shared_index_name: Name of shared index for shared tenants
            auto_create_shared: Auto-create shared index if needed
        """
        self.client = client
        self.shared_index_name = shared_index_name
        self.auto_create_shared = auto_create_shared
        self.tenants: Dict[str, TenantConfig] = {}

    async def create_tenant(
        self,
        tenant_id: str,
        isolation_level: TenantIsolationLevel = TenantIsolationLevel.SHARED,
        dimension: int = 1024,
        tier: str = "standard",
        **kwargs: Any
    ) -> TenantConfig:
        """
        Create a new tenant.

        Args:
            tenant_id: Unique tenant identifier
            isolation_level: Isolation level (dedicated, shared, hybrid)
            dimension: Vector dimension
            tier: Service tier
            **kwargs: Additional config options

        Returns:
            Created tenant configuration

        Raises:
            ValueError: If tenant already exists
        """
        if tenant_id in self.tenants:
            raise ValueError(f"Tenant {tenant_id} already exists")

        # Create tenant config
        config = TenantConfig(
            tenant_id=tenant_id,
            isolation_level=isolation_level,
            dimension=dimension,
            tier=tier,
            **kwargs
        )

        # Setup based on isolation level
        if isolation_level == TenantIsolationLevel.DEDICATED:
            # Create dedicated index
            index_name = f"vectors_{tenant_id}"
            config.index_name = index_name

            await self.client.create_index(
                index_name=index_name,
                dimension=dimension
            )

            logger.info(f"Created dedicated index for tenant {tenant_id}: {index_name}")

        elif isolation_level == TenantIsolationLevel.SHARED:
            # Use shared index with partition key
            config.index_name = self.shared_index_name
            config.partition_key = tenant_id

            # Create shared index if doesn't exist
            if self.auto_create_shared:
                exists = await self.client.index_exists(self.shared_index_name)
                if not exists:
                    # Create shared index with partitioning
                    await self.client.create_index(
                        index_name=self.shared_index_name,
                        dimension=dimension
                    )
                    logger.info(f"Created shared index: {self.shared_index_name}")

        elif isolation_level == TenantIsolationLevel.HYBRID:
            # Decide based on tier
            if tier == "premium":
                # Premium gets dedicated
                config.isolation_level = TenantIsolationLevel.DEDICATED
                return await self.create_tenant(
                    tenant_id=tenant_id,
                    isolation_level=TenantIsolationLevel.DEDICATED,
                    dimension=dimension,
                    tier=tier,
                    **kwargs
                )
            else:
                # Standard/basic get shared
                config.isolation_level = TenantIsolationLevel.SHARED
                return await self.create_tenant(
                    tenant_id=tenant_id,
                    isolation_level=TenantIsolationLevel.SHARED,
                    dimension=dimension,
                    tier=tier,
                    **kwargs
                )

        self.tenants[tenant_id] = config
        return config

    async def delete_tenant(
        self,
        tenant_id: str,
        delete_data: bool = False
    ) -> bool:
        """
        Delete a tenant.

        Args:
            tenant_id: Tenant to delete
            delete_data: If True, delete all tenant data

        Returns:
            True if deleted, False if not found
        """
        config = self.tenants.get(tenant_id)
        if not config:
            return False

        if delete_data:
            if config.isolation_level == TenantIsolationLevel.DEDICATED:
                # Delete dedicated index
                if config.index_name:
                    await self.client.delete_index(config.index_name)
                    logger.info(f"Deleted dedicated index: {config.index_name}")

            elif config.isolation_level == TenantIsolationLevel.SHARED:
                # Delete vectors from shared index
                # This would require listing and deleting all tenant's vectors
                logger.warning(
                    f"Deleting data for shared tenant {tenant_id} requires "
                    "listing all vectors - not yet implemented"
                )

        del self.tenants[tenant_id]
        return True

    async def get_tenant(self, tenant_id: str) -> Optional[TenantConfig]:
        """Get tenant configuration."""
        return self.tenants.get(tenant_id)

    async def list_tenants(
        self,
        isolation_level: Optional[TenantIsolationLevel] = None,
        tier: Optional[str] = None
    ) -> List[TenantConfig]:
        """
        List tenants with optional filtering.

        Args:
            isolation_level: Filter by isolation level
            tier: Filter by tier

        Returns:
            List of tenant configurations
        """
        tenants = list(self.tenants.values())

        if isolation_level:
            tenants = [t for t in tenants if t.isolation_level == isolation_level]

        if tier:
            tenants = [t for t in tenants if t.tier == tier]

        return tenants

    async def query_for_tenant(
        self,
        tenant_id: str,
        vector: List[float],
        top_k: int = 10,
        **kwargs: Any
    ) -> Any:
        """
        Query vectors for a specific tenant.

        Automatically routes to correct index based on tenant configuration.

        Args:
            tenant_id: Tenant identifier
            vector: Query vector
            top_k: Number of results
            **kwargs: Additional query parameters

        Returns:
            Query results

        Raises:
            ValueError: If tenant not found
        """
        config = self.tenants.get(tenant_id)
        if not config:
            raise ValueError(f"Tenant {tenant_id} not found")

        # Route based on isolation level
        if config.isolation_level == TenantIsolationLevel.DEDICATED:
            # Query dedicated index
            return await self.client.query_vectors(
                index_name=config.index_name,
                vector=vector,
                top_k=top_k,
                **kwargs
            )

        elif config.isolation_level == TenantIsolationLevel.SHARED:
            # Query shared index with partition filter
            # Add tenant_id to metadata filter
            filter_param = kwargs.get('filter', {})
            filter_param['tenant_id'] = tenant_id
            kwargs['filter'] = filter_param

            return await self.client.query_vectors(
                index_name=config.index_name,
                vector=vector,
                top_k=top_k,
                **kwargs
            )

    async def put_vectors_for_tenant(
        self,
        tenant_id: str,
        vectors: List[Any],
        **kwargs: Any
    ) -> int:
        """
        Store vectors for a specific tenant.

        Args:
            tenant_id: Tenant identifier
            vectors: List of VectorRecord objects
            **kwargs: Additional parameters

        Returns:
            Number of vectors stored

        Raises:
            ValueError: If tenant not found
        """
        config = self.tenants.get(tenant_id)
        if not config:
            raise ValueError(f"Tenant {tenant_id} not found")

        # Add tenant_id to metadata for shared indices
        if config.isolation_level == TenantIsolationLevel.SHARED:
            for vector_record in vectors:
                if not hasattr(vector_record, 'metadata'):
                    vector_record.metadata = {}
                vector_record.metadata['tenant_id'] = tenant_id

        # Store vectors
        return await self.client.put_vectors(
            index_name=config.index_name,
            vectors=vectors,
            **kwargs
        )

    async def get_tenant_stats(self, tenant_id: str) -> Dict[str, Any]:
        """
        Get statistics for a tenant.

        Args:
            tenant_id: Tenant identifier

        Returns:
            Dictionary with tenant statistics
        """
        config = self.tenants.get(tenant_id)
        if not config:
            raise ValueError(f"Tenant {tenant_id} not found")

        # Get index stats
        # This is a placeholder - actual implementation would query the database
        stats = {
            "tenant_id": tenant_id,
            "isolation_level": config.isolation_level.value,
            "tier": config.tier,
            "index_name": config.index_name,
            "dimension": config.dimension,
            "sla_ms": config.sla_ms,
        }

        return stats

    def upgrade_tenant(
        self,
        tenant_id: str,
        new_tier: str
    ) -> TenantConfig:
        """
        Upgrade tenant to a different tier.

        Args:
            tenant_id: Tenant to upgrade
            new_tier: New tier (premium, standard, basic)

        Returns:
            Updated tenant configuration
        """
        config = self.tenants.get(tenant_id)
        if not config:
            raise ValueError(f"Tenant {tenant_id} not found")

        old_tier = config.tier
        config.tier = new_tier

        logger.info(f"Upgraded tenant {tenant_id} from {old_tier} to {new_tier}")

        return config
