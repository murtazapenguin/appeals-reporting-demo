"""
Penguin Finetuning Utilities

GPU cleanup, memory management, and helper functions.
"""

import gc
from typing import Optional, Any


def cleanup_gpu_memory(
    model: Optional[Any] = None,
    tokenizer: Optional[Any] = None,
    trainer: Optional[Any] = None,
    dataset: Optional[Any] = None,
) -> None:
    """
    Clean up GPU memory after training.

    Args:
        model: The model to cleanup
        tokenizer: The tokenizer to cleanup
        trainer: The trainer to cleanup
        dataset: The dataset to cleanup
    """
    # Lazy import torch
    try:
        import torch
        has_torch = True
    except ImportError:
        has_torch = False

    # Delete objects in reverse order of importance
    objects = [trainer, dataset, model, tokenizer]

    for obj in objects:
        if obj is not None:
            # Try to move to CPU first
            if has_torch and hasattr(obj, 'cpu'):
                try:
                    obj.cpu()
                except Exception:
                    pass
            # Delete reference
            try:
                del obj
            except Exception:
                pass

    # Force garbage collection
    gc.collect()

    # Clear CUDA cache if available
    if has_torch and torch.cuda.is_available():
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass
        try:
            torch.cuda.synchronize()
        except Exception:
            pass


def get_device() -> str:
    """
    Get the best available device for training.

    Returns:
        "cuda" if GPU available, else "cpu"
    """
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda"
    except ImportError:
        pass
    return "cpu"


def is_bfloat16_supported() -> bool:
    """
    Check if bfloat16 is supported on the current device.

    Returns:
        True if bfloat16 is supported, False otherwise
    """
    try:
        import torch
        if torch.cuda.is_available():
            # Check compute capability (bfloat16 requires compute >= 8.0)
            major, _ = torch.cuda.get_device_capability()
            return major >= 8
    except ImportError:
        pass
    return False


def get_gpu_memory_info() -> dict:
    """
    Get GPU memory information.

    Returns:
        Dict with 'total', 'used', 'free' in GB, or empty dict if no GPU
    """
    try:
        import torch
        if torch.cuda.is_available():
            total = torch.cuda.get_device_properties(0).total_memory
            reserved = torch.cuda.memory_reserved(0)
            allocated = torch.cuda.memory_allocated(0)
            free = total - reserved

            return {
                "total_gb": round(total / 1024**3, 2),
                "reserved_gb": round(reserved / 1024**3, 2),
                "allocated_gb": round(allocated / 1024**3, 2),
                "free_gb": round(free / 1024**3, 2),
            }
    except ImportError:
        pass
    return {}


def check_dependencies(trainer_type: str) -> dict:
    """
    Check if all dependencies for a trainer type are installed.

    Args:
        trainer_type: "llm", "reranker", or "embedding"

    Returns:
        Dict with 'available' bool and 'missing' list of package names
    """
    missing = []

    if trainer_type == "llm":
        # Try Unsloth first
        try:
            from unsloth import FastLanguageModel  # noqa: F401
        except ImportError:
            # Fall back to transformers + trl
            try:
                from transformers import AutoModelForCausalLM  # noqa: F401
            except ImportError:
                missing.append("transformers")
            try:
                from trl import SFTTrainer  # noqa: F401
            except ImportError:
                missing.append("trl")
            try:
                from peft import get_peft_model  # noqa: F401
            except ImportError:
                missing.append("peft")

    elif trainer_type == "reranker":
        try:
            from transformers import AutoModelForSequenceClassification  # noqa: F401
        except ImportError:
            missing.append("transformers")
        try:
            from peft import get_peft_model  # noqa: F401
        except ImportError:
            missing.append("peft")
        try:
            import bitsandbytes  # noqa: F401
        except ImportError:
            missing.append("bitsandbytes")

    elif trainer_type == "embedding":
        try:
            from sentence_transformers import SentenceTransformer  # noqa: F401
        except ImportError:
            missing.append("sentence-transformers")

    # Common dependencies
    try:
        import torch  # noqa: F401
    except ImportError:
        missing.append("torch")

    try:
        from datasets import Dataset  # noqa: F401
    except ImportError:
        missing.append("datasets")

    return {
        "available": len(missing) == 0,
        "missing": missing,
    }


def format_training_time(seconds: float) -> str:
    """
    Format training time in human-readable format.

    Args:
        seconds: Training time in seconds

    Returns:
        Formatted string (e.g., "1h 30m 45s")
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")

    return " ".join(parts)


def get_lora_target_modules(
    model_id: str,
    model_type: str = "auto",
    show_all: bool = False,
) -> dict:
    """
    Discover available LoRA target modules for a model.

    This helps users find the correct target_modules for LoRA config.

    Args:
        model_id: HuggingFace model ID or local path (e.g., "BAAI/bge-m3")
        model_type: "llm", "reranker", "embedding", or "auto" (auto-detect)
        show_all: If True, show all Linear layers; if False, show only attention layers

    Returns:
        Dict with:
        - 'recommended': List of recommended target modules for LoRA
        - 'all_linear': List of all Linear layer names
        - 'attention': List of attention-related layer names
        - 'model_type': Detected model architecture type

    Example:
        >>> from penguin.finetuning import get_lora_target_modules
        >>> info = get_lora_target_modules("BAAI/bge-m3")
        >>> print(info['recommended'])
        ['query', 'value']

        >>> info = get_lora_target_modules("Qwen/Qwen3-4B")
        >>> print(info['recommended'])
        ['q_proj', 'k_proj', 'v_proj']
    """
    try:
        from transformers import AutoModel, AutoConfig
    except ImportError:
        return {
            "error": "transformers not installed",
            "recommended": [],
            "all_linear": [],
            "attention": [],
        }

    # Load model config to detect architecture
    try:
        config = AutoConfig.from_pretrained(model_id, trust_remote_code=True)
        arch_type = config.model_type if hasattr(config, 'model_type') else "unknown"
    except Exception as e:
        return {"error": f"Failed to load config: {e}"}

    # Load model to inspect layers
    try:
        model = AutoModel.from_pretrained(model_id, trust_remote_code=True)
    except Exception as e:
        return {"error": f"Failed to load model: {e}"}

    # Find all Linear layers
    import torch.nn as nn
    all_linear = []
    attention_layers = []

    attention_keywords = ['query', 'key', 'value', 'q_proj', 'k_proj', 'v_proj',
                          'qkv', 'attention', 'self_attn', 'o_proj', 'out_proj']

    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            # Get just the layer name (last part)
            layer_name = name.split('.')[-1]
            if layer_name not in all_linear:
                all_linear.append(layer_name)

            # Check if it's attention-related
            if any(kw in name.lower() for kw in attention_keywords):
                if layer_name not in attention_layers:
                    attention_layers.append(layer_name)

    # Determine recommended modules based on architecture
    recommended = []

    # Check for common patterns
    if 'query' in attention_layers and 'value' in attention_layers:
        # BERT/RoBERTa/XLM-R style (BGE, E5)
        recommended = ['query', 'value']
    elif 'q_proj' in attention_layers and 'v_proj' in attention_layers:
        # LLaMA/Qwen/Mistral style
        if 'k_proj' in attention_layers:
            recommended = ['q_proj', 'k_proj', 'v_proj']
        else:
            recommended = ['q_proj', 'v_proj']
    elif 'qkv_proj' in attention_layers or 'qkv' in attention_layers:
        # Fused QKV style
        recommended = ['qkv_proj'] if 'qkv_proj' in attention_layers else ['qkv']
    elif 'c_attn' in attention_layers:
        # GPT-2 style
        recommended = ['c_attn']
    elif attention_layers:
        # Fallback to first two attention layers
        recommended = attention_layers[:2]

    # Cleanup
    del model
    gc.collect()

    return {
        "model_id": model_id,
        "architecture": arch_type,
        "recommended": recommended,
        "attention": sorted(set(attention_layers)),
        "all_linear": sorted(set(all_linear)),
    }


def print_lora_modules(model_id: str) -> None:
    """
    Print available LoRA target modules for a model in a user-friendly format.

    Args:
        model_id: HuggingFace model ID (e.g., "BAAI/bge-m3", "Qwen/Qwen3-4B")

    Example:
        >>> from penguin.finetuning import print_lora_modules
        >>> print_lora_modules("BAAI/bge-m3")
    """
    print(f"Discovering LoRA target modules for: {model_id}")
    print("=" * 60)

    info = get_lora_target_modules(model_id)

    if "error" in info:
        print(f"Error: {info['error']}")
        return

    print(f"Architecture: {info['architecture']}")
    print(f"\nRecommended target_modules: {info['recommended']}")
    print(f"\nAll attention layers: {info['attention']}")
    print(f"\nAll Linear layers: {info['all_linear']}")

    print(f"\nUsage:")
    print(f"  LoRAConfig(target_modules={info['recommended']})")
