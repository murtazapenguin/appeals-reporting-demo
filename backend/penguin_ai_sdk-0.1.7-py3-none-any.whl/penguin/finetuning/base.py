"""
Penguin Finetuning Base Module

Abstract base class for all finetuning trainer implementations.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    from .config import TrainingConfig, DataConfig, TrainingResult


class BaseTrainer(ABC):
    """
    Abstract base class for finetuning trainers.

    All trainer implementations MUST implement:
    - load_model(): Load and prepare the model for training
    - load_dataset(): Load and prepare the training dataset
    - train(): Execute the training loop
    - save(): Save the trained model/adapter

    Example:
        trainer = LLMTrainer(
            model_name="qwen3-14b",
            training_config=TrainingConfig(max_steps=100),
            data_config=DataConfig(dataset_path="data.csv"),
            output_dir="./output"
        )

        with trainer:  # Auto cleanup
            trainer.load_model()
            trainer.load_dataset()
            result = trainer.train()
            trainer.save()
    """

    def __init__(
        self,
        model_name: str,
        training_config: "TrainingConfig",
        data_config: "DataConfig",
        output_dir: str,
        **kwargs: Any
    ):
        """
        Initialize the trainer.

        Args:
            model_name: Model identifier (friendly name or HuggingFace ID)
            training_config: Training hyperparameters
            data_config: Dataset configuration
            output_dir: Directory to save outputs
            **kwargs: Additional trainer-specific configuration
        """
        self.model_name = model_name
        self.training_config = training_config
        self.data_config = data_config
        self.output_dir = Path(output_dir)
        self.config = kwargs

        # Lazily loaded components
        self._model = None
        self._tokenizer = None
        self._dataset = None
        self._trainer = None

    @property
    @abstractmethod
    def trainer_type(self) -> str:
        """Return the trainer type (e.g., 'llm', 'reranker', 'embedding')."""
        pass

    @abstractmethod
    def load_model(self) -> None:
        """
        Load and prepare the model for training.

        Should handle:
        - Model loading with quantization if configured
        - LoRA/PEFT preparation
        - Tokenizer setup
        """
        pass

    @abstractmethod
    def load_dataset(self) -> None:
        """
        Load and prepare the training dataset.

        Should handle:
        - Reading from configured data_config.dataset_path
        - Tokenization
        - Filtering by max sequence length
        """
        pass

    @abstractmethod
    def train(self) -> "TrainingResult":
        """
        Execute the training loop.

        Returns:
            TrainingResult with metrics and status
        """
        pass

    @abstractmethod
    def save(self, save_path: Optional[str] = None) -> str:
        """
        Save the trained model/adapter.

        Args:
            save_path: Override output path

        Returns:
            Path where model was saved
        """
        pass

    def cleanup(self) -> None:
        """
        Release GPU memory and cleanup resources.

        Default implementation handles common cleanup.
        Subclasses can override for specific cleanup.
        """
        import gc

        # Lazy import torch only when needed
        try:
            import torch
            has_torch = True
        except ImportError:
            has_torch = False

        # Delete references in reverse order of creation
        for attr in ['_trainer', '_dataset', '_model', '_tokenizer']:
            obj = getattr(self, attr, None)
            if obj is not None:
                if has_torch and hasattr(obj, 'cpu'):
                    try:
                        obj.cpu()
                    except Exception:
                        pass
                try:
                    delattr(self, attr)
                except Exception:
                    pass
                setattr(self, attr, None)

        gc.collect()

        if has_torch and torch.cuda.is_available():
            torch.cuda.empty_cache()
            try:
                torch.cuda.ipc_collect()
            except Exception:
                pass
            try:
                torch.cuda.synchronize()
            except Exception:
                pass

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with cleanup."""
        self.cleanup()
        return False


class FinetuningError(Exception):
    """Base exception for finetuning errors."""

    def __init__(
        self,
        message: str,
        trainer_type: Optional[str] = None,
        model_name: Optional[str] = None,
    ):
        self.trainer_type = trainer_type
        self.model_name = model_name
        super().__init__(message)


class ModelNotSupportedError(FinetuningError):
    """Model not supported for this trainer type."""
    pass


class DatasetError(FinetuningError):
    """Dataset loading or validation error."""
    pass


class TrainingError(FinetuningError):
    """Training execution error."""
    pass


class DependencyError(FinetuningError):
    """Required dependency not installed."""

    def __init__(self, package: str, trainer_type: str, install_hint: str = None):
        self.package = package
        hint = install_hint or f"pip install penguin-ai-sdk[finetuning]"
        message = (
            f"Required package '{package}' not installed for {trainer_type} training. "
            f"Install with: {hint}"
        )
        super().__init__(message, trainer_type=trainer_type)
