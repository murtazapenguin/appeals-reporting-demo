"""
Penguin Reranker Finetuning Trainer

Uses Transformers + PEFT for reranker/retrieval model finetuning.
"""

import os
import time
import random
from pathlib import Path
from typing import Optional, List

from ..base import BaseTrainer, DependencyError
from ..config import TrainingConfig, DataConfig, TrainingResult
from ..models import get_model, resolve_model_id
from ..callbacks import ProgressCallback, MetricLoggingCallback


class RerankerTrainer(BaseTrainer):
    """
    Reranker Finetuning trainer using Transformers and PEFT.

    Features:
    - 4-bit quantization via bitsandbytes
    - LoRA adapters
    - Custom ranking loss (cross-entropy)
    - BGE-style training with query-passage pairs

    Example:
        trainer = RerankerTrainer(
            model_name="bge-m3",
            training_config=TrainingConfig.default_reranker(),
            data_config=DataConfig(dataset_path="data/"),
            output_dir="./adapter"
        )

        with trainer:
            trainer.load_model()
            trainer.load_dataset()
            result = trainer.train()
            trainer.save()
    """

    @property
    def trainer_type(self) -> str:
        return "reranker"

    def _check_dependencies(self) -> None:
        """Check that required dependencies are installed."""
        try:
            from transformers import AutoModelForSequenceClassification  # noqa: F401
            from peft import get_peft_model  # noqa: F401
            import bitsandbytes  # noqa: F401
        except ImportError as e:
            raise DependencyError(
                package=str(e.name),
                trainer_type="reranker",
                install_hint="pip install penguin-ai-sdk[finetuning]"
            )

    def load_model(self) -> None:
        """Load model with 4-bit quantization and LoRA."""
        self._check_dependencies()

        import torch
        from transformers import (
            AutoTokenizer,
            AutoModelForSequenceClassification,
            BitsAndBytesConfig,
        )
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

        hf_model_id = resolve_model_id(self.model_name, "reranker")
        hf_token = os.getenv("HF_TOKEN")

        # 4-bit quantization config
        use_4bit = self.training_config.quantization.value in ("int4", "nf4")
        bnb_config = None

        if use_4bit:
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
                llm_int8_skip_modules=["classifier", "pre_classifier"],
            )

        # Load model
        self._model = AutoModelForSequenceClassification.from_pretrained(
            hf_model_id,
            quantization_config=bnb_config,
            torch_dtype=torch.bfloat16 if self.training_config.bf16 else torch.float16,
            device_map="auto",
            token=hf_token,
        )

        # Prepare for k-bit training
        if use_4bit:
            self._model = prepare_model_for_kbit_training(self._model)

        # Apply LoRA
        if self.training_config.lora:
            lora = self.training_config.lora
            lora_config = LoraConfig(
                r=lora.r,
                lora_alpha=lora.lora_alpha,
                lora_dropout=lora.lora_dropout,
                target_modules=lora.target_modules,
                bias=lora.bias,
                task_type="SEQ_CLS",
            )
            self._model = get_peft_model(self._model, lora_config)

        self._tokenizer = AutoTokenizer.from_pretrained(hf_model_id, token=hf_token)

    def load_dataset(self) -> None:
        """Load and prepare reranker dataset."""
        import datasets
        from torch.utils.data import Dataset as TorchDataset

        data_dir = self.data_config.dataset_path

        # Find JSONL files
        dataset_files = [
            os.path.join(data_dir, f)
            for f in os.listdir(data_dir)
            if f.endswith((".json", ".jsonl"))
        ]

        if not dataset_files:
            raise ValueError(f"No JSON/JSONL files found in {data_dir}")

        # Load with datasets library
        raw_dataset = datasets.load_dataset("json", data_files=dataset_files, split="train")

        # Create custom dataset class
        class RerankerTrainDataset(TorchDataset):
            def __init__(
                self,
                dataset,
                tokenizer,
                max_query_length: int,
                max_passage_length: int,
                train_group_size: int,
                query_column: str,
                positive_column: str,
                negative_column: str,
            ):
                self.tokenizer = tokenizer
                self.max_query_length = max_query_length
                self.max_passage_length = max_passage_length
                self.train_group_size = train_group_size
                self.query_column = query_column
                self.positive_column = positive_column
                self.negative_column = negative_column

                # Filter by token length
                def check_length(x):
                    q_len = len(tokenizer(x[query_column])["input_ids"])
                    p_len = len(tokenizer(x[positive_column][0])["input_ids"]) if x[positive_column] else 0
                    return q_len <= max_query_length and p_len <= max_passage_length

                self.dataset = dataset.filter(check_length)

            def __len__(self):
                return len(self.dataset)

            def _prepare_pair(self, query: str, passage: str):
                """Encode query-passage pair."""
                qry_inputs = self.tokenizer.encode(
                    query,
                    truncation=True,
                    max_length=self.max_query_length,
                    add_special_tokens=False
                )
                doc_inputs = self.tokenizer.encode(
                    passage,
                    truncation=True,
                    max_length=self.max_passage_length,
                    add_special_tokens=False
                )

                return self.tokenizer.prepare_for_model(
                    qry_inputs,
                    doc_inputs,
                    truncation="only_second",
                    max_length=self.max_query_length + self.max_passage_length,
                    padding=False,
                )

            def __getitem__(self, idx):
                """Return tokenized query-passage pairs."""
                query_prompt = "Represent this sentence for searching relevant passages:"
                data = self.dataset[idx]
                query = query_prompt + data[self.query_column]

                # Select positive and negatives
                positive_passage = random.choice(data[self.positive_column])
                neg_count = self.train_group_size - 1
                available_negatives = data[self.negative_column]

                if len(available_negatives) >= neg_count:
                    negative_passages = random.sample(available_negatives, neg_count)
                else:
                    # Repeat negatives if not enough
                    negative_passages = available_negatives * (neg_count // len(available_negatives))
                    negative_passages += random.sample(
                        available_negatives, neg_count % len(available_negatives)
                    )

                passages = [positive_passage] + negative_passages
                prepared_pairs = [self._prepare_pair(query, p) for p in passages]

                return prepared_pairs

        self._dataset = RerankerTrainDataset(
            dataset=raw_dataset,
            tokenizer=self._tokenizer,
            max_query_length=self.data_config.max_query_length,
            max_passage_length=self.data_config.max_passage_length,
            train_group_size=self.data_config.train_group_size,
            query_column=self.data_config.query_column,
            positive_column=self.data_config.positive_column,
            negative_column=self.data_config.negative_column,
        )

    def train(self) -> TrainingResult:
        """Execute training."""
        import torch
        from torch.nn import CrossEntropyLoss
        from transformers import TrainingArguments, Trainer, DataCollatorWithPadding

        start_time = time.time()
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Custom data collator
        class RerankerCollator(DataCollatorWithPadding):
            def __init__(self, tokenizer, query_max_len: int, passage_max_len: int, **kwargs):
                super().__init__(tokenizer, **kwargs)
                self.query_max_len = query_max_len
                self.passage_max_len = passage_max_len

            def __call__(self, features):
                if isinstance(features[0], list):
                    features = sum(features, [])

                collated = self.tokenizer.pad(
                    features,
                    padding=self.padding,
                    max_length=self.query_max_len + self.passage_max_len,
                    pad_to_multiple_of=self.pad_to_multiple_of,
                    return_tensors="pt",
                )
                return {"pair": collated}

        # Custom trainer with ranking loss
        class RankerTrainer(Trainer):
            def __init__(self, train_group_size: int, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.train_group_size = train_group_size

            def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
                batch_size = self.args.per_device_train_batch_size
                labels = torch.zeros(batch_size, dtype=torch.long, device=model.device)

                outputs = model(**inputs["pair"])
                logits = outputs.logits.view(batch_size, -1)

                loss_fn = CrossEntropyLoss()
                loss = loss_fn(logits, labels)

                return (loss, outputs) if return_outputs else loss

        # Build training args
        trainer_kwargs = self.training_config.to_trainer_kwargs()
        trainer_kwargs["output_dir"] = str(self.output_dir)
        trainer_kwargs["dataloader_pin_memory"] = False
        trainer_kwargs["remove_unused_columns"] = False  # Keep custom columns

        # Only drop last if we have enough samples
        dataset_len = len(self._dataset)
        batch_size = self.training_config.per_device_train_batch_size
        trainer_kwargs["dataloader_drop_last"] = dataset_len >= batch_size * 2

        training_args = TrainingArguments(**trainer_kwargs)

        print(f"[INFO] Dataset size: {dataset_len}, Batch size: {batch_size}")

        # Data collator
        data_collator = RerankerCollator(
            self._tokenizer,
            query_max_len=self.data_config.max_query_length,
            passage_max_len=self.data_config.max_passage_length,
        )

        # Callbacks
        metric_callback = MetricLoggingCallback()
        callbacks = [
            ProgressCallback(str(self.output_dir)),
            metric_callback,
        ]

        # Create trainer
        self._trainer = RankerTrainer(
            train_group_size=self.data_config.train_group_size,
            model=self._model,
            args=training_args,
            data_collator=data_collator,
            train_dataset=self._dataset,
            callbacks=callbacks,
        )

        # Train
        try:
            train_result = self._trainer.train()
            training_time = time.time() - start_time

            return TrainingResult(
                success=True,
                output_path=str(self.output_dir),
                final_loss=metric_callback.get_final_loss(),
                total_steps=train_result.global_step,
                training_time_seconds=training_time,
                metrics=train_result.metrics if hasattr(train_result, 'metrics') else {},
            )
        except Exception as e:
            return TrainingResult(
                success=False,
                output_path=str(self.output_dir),
                error_message=str(e),
                training_time_seconds=time.time() - start_time,
            )

    def save(self, save_path: Optional[str] = None) -> str:
        """Save LoRA adapter and tokenizer."""
        path = Path(save_path or self.output_dir)
        path.mkdir(parents=True, exist_ok=True)

        self._model.save_pretrained(path)
        self._tokenizer.save_pretrained(path)

        return str(path)
