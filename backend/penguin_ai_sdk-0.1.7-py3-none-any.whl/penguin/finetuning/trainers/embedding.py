"""
Penguin Embedding Finetuning Trainer

Uses sentence-transformers for embedding model finetuning.
Supports LoRA adapters for large models via PEFT.
"""

import time
from pathlib import Path
from typing import Optional

from ..base import BaseTrainer, DependencyError
from ..config import TrainingConfig, DataConfig, TrainingResult, EmbeddingLossType
from ..models import get_model, resolve_model_id
from ..callbacks import ProgressCallback, MetricLoggingCallback


class EmbeddingTrainer(BaseTrainer):
    """
    Embedding Finetuning trainer using sentence-transformers.

    Features:
    - Configurable loss functions (TripletLoss, MultipleNegativesRankingLoss, etc.)
    - Optional LoRA adapters for large models (via PEFT)
    - Support for various embedding models
    - Batch mining for hard negatives

    Example (full fine-tuning):
        trainer = EmbeddingTrainer(
            model_name="bge-m3-embedding",
            training_config=TrainingConfig.default_embedding(),
            data_config=DataConfig(dataset_path="data.jsonl"),
            output_dir="./model"
        )

    Example (with LoRA for large models):
        from penguin.finetuning import LoRAConfig
        trainer = EmbeddingTrainer(
            model_name="gte-qwen2-1.5b",
            training_config=TrainingConfig(lora=LoRAConfig.for_embedding()),
            data_config=DataConfig(
                dataset_path="data.jsonl",
                embedding_loss_type="mnrl",  # MultipleNegativesRankingLoss
            ),
            output_dir="./adapter"
        )
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._use_lora = False
        self._tokenizer = None

    @property
    def trainer_type(self) -> str:
        return "embedding"

    def _check_dependencies(self) -> None:
        """Check that required dependencies are installed."""
        try:
            from sentence_transformers import SentenceTransformer  # noqa: F401
            from sentence_transformers.losses import TripletLoss  # noqa: F401
        except ImportError as e:
            raise DependencyError(
                package="sentence-transformers",
                trainer_type="embedding",
                install_hint="pip install penguin-ai-sdk[finetuning-embedding]"
            )

        # Check PEFT dependencies if LoRA is enabled
        if self.training_config.lora:
            try:
                import peft  # noqa: F401
                import bitsandbytes  # noqa: F401
            except ImportError:
                raise DependencyError(
                    package="peft",
                    trainer_type="embedding (with LoRA)",
                    install_hint="pip install peft bitsandbytes"
                )

    def load_model(self) -> None:
        """Load model - with LoRA if configured, otherwise sentence-transformers."""
        self._check_dependencies()

        if self.training_config.lora:
            self._load_model_with_lora()
        else:
            self._load_model_sentence_transformers()

    def _load_model_sentence_transformers(self) -> None:
        """Load model using sentence-transformers (full fine-tuning)."""
        from sentence_transformers import SentenceTransformer

        hf_model_id = resolve_model_id(self.model_name, "embedding")

        self._model = SentenceTransformer(hf_model_id)
        self._use_lora = False

        # Set max sequence length from model info if available
        model_info = get_model(self.model_name)
        if model_info:
            self._model.max_seq_length = min(
                model_info.max_seq_length,
                self._model.max_seq_length
            )

    def _load_model_with_lora(self) -> None:
        """Load model with LoRA using Transformers + PEFT (parameter-efficient fine-tuning)."""
        import torch
        from transformers import AutoModel, AutoTokenizer, BitsAndBytesConfig
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType

        hf_model_id = resolve_model_id(self.model_name, "embedding")

        # Quantization config for 4-bit loading
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
        )

        # Load tokenizer
        self._tokenizer = AutoTokenizer.from_pretrained(hf_model_id, trust_remote_code=True)

        # Load base model with quantization
        self._base_model = AutoModel.from_pretrained(
            hf_model_id,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True,
        )

        # Prepare for k-bit training
        self._base_model = prepare_model_for_kbit_training(self._base_model)

        # Create LoRA config
        lora_cfg = self.training_config.lora
        peft_config = LoraConfig(
            r=lora_cfg.r,
            lora_alpha=lora_cfg.lora_alpha,
            lora_dropout=lora_cfg.lora_dropout,
            target_modules=lora_cfg.target_modules,
            bias=lora_cfg.bias,
            task_type=TaskType.FEATURE_EXTRACTION,
        )

        # Apply LoRA
        self._model = get_peft_model(self._base_model, peft_config)
        self._use_lora = True

        # Print trainable parameters
        trainable_params = sum(p.numel() for p in self._model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self._model.parameters())
        print(f"LoRA enabled: {trainable_params:,} trainable / {total_params:,} total ({100 * trainable_params / total_params:.2f}%)")

    def load_dataset(self) -> None:
        """Load and prepare embedding dataset."""
        import json
        from pathlib import Path
        from sentence_transformers import InputExample

        dataset_path = Path(self.data_config.dataset_path)

        examples = []

        # Support both single JSONL file and directory of files
        if dataset_path.is_file():
            files = [dataset_path]
        else:
            files = list(dataset_path.glob("*.jsonl")) + list(dataset_path.glob("*.json"))

        if not files:
            raise ValueError(f"No JSON/JSONL files found at {dataset_path}")

        anchor_col = self.data_config.anchor_column
        positive_col = self.data_config.positive_text_column
        negative_col = self.data_config.negative_text_column

        for file_path in files:
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue

                    data = json.loads(line)

                    # Get anchor text
                    anchor = data.get(anchor_col, "")
                    if not anchor:
                        continue

                    # Get positive text(s)
                    positive = data.get(positive_col, "")
                    if isinstance(positive, list):
                        positive = positive[0] if positive else ""

                    # Get negative text(s)
                    negative = data.get(negative_col, "")
                    if isinstance(negative, list):
                        negative = negative[0] if negative else ""

                    if positive and negative:
                        # Triplet format: anchor, positive, negative
                        examples.append(InputExample(
                            texts=[anchor, positive, negative]
                        ))
                    elif positive:
                        # Pair format: anchor, positive
                        examples.append(InputExample(
                            texts=[anchor, positive],
                            label=1.0  # Similar
                        ))

        if not examples:
            raise ValueError("No valid examples found in dataset")

        self._dataset = examples

    def _get_loss_function(self):
        """
        Get loss function based on config and dataset format.

        Returns:
            Configured loss function for training.
        """
        from sentence_transformers import losses

        loss_type = self.data_config.embedding_loss_type
        sample = self._dataset[0]
        has_negatives = len(sample.texts) == 3

        # Map loss type to sentence-transformers loss class
        if loss_type == EmbeddingLossType.TRIPLET:
            if not has_negatives:
                raise ValueError("TripletLoss requires negatives in dataset (anchor, positive, negative)")
            return losses.TripletLoss(model=self._model)

        elif loss_type == EmbeddingLossType.COSINE:
            return losses.CosineSimilarityLoss(model=self._model)

        elif loss_type == EmbeddingLossType.MULTIPLE_NEGATIVES:
            # MNRL works with pairs (uses in-batch negatives) or triplets
            return losses.MultipleNegativesRankingLoss(model=self._model)

        elif loss_type == EmbeddingLossType.CONTRASTIVE:
            return losses.ContrastiveLoss(model=self._model)

        elif loss_type == EmbeddingLossType.ANGLE:
            if not has_negatives:
                raise ValueError("AnglELoss requires negatives in dataset (anchor, positive, negative)")
            return losses.AnglELoss(model=self._model)

        else:
            # Auto-detect based on dataset format (fallback)
            if has_negatives:
                return losses.TripletLoss(model=self._model)
            else:
                return losses.CosineSimilarityLoss(model=self._model)

    def train(self) -> TrainingResult:
        """Execute training."""
        import os
        from sentence_transformers.trainer import SentenceTransformerTrainer
        from sentence_transformers.training_args import SentenceTransformerTrainingArguments
        from torch.utils.data import DataLoader
        from datasets import Dataset

        start_time = time.time()
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Disable W&B if report_to is "none"
        if self.training_config.report_to == "none":
            os.environ["WANDB_DISABLED"] = "true"

        # Use LoRA-specific training path if enabled
        if self._use_lora:
            return self._train_with_lora(start_time)

        # Get configured loss function
        train_loss = self._get_loss_function()

        # Create data loader (for legacy fallback)
        train_dataloader = DataLoader(
            self._dataset,
            shuffle=True,
            batch_size=self.training_config.per_device_train_batch_size,
        )

        # Convert InputExample list to HuggingFace Dataset for SentenceTransformerTrainer
        sample = self._dataset[0]
        has_negatives = len(sample.texts) == 3

        if has_negatives:
            hf_dataset = Dataset.from_dict({
                "anchor": [ex.texts[0] for ex in self._dataset],
                "positive": [ex.texts[1] for ex in self._dataset],
                "negative": [ex.texts[2] for ex in self._dataset],
            })
        else:
            hf_dataset = Dataset.from_dict({
                "anchor": [ex.texts[0] for ex in self._dataset],
                "positive": [ex.texts[1] for ex in self._dataset],
            })

        # Training arguments
        training_args = SentenceTransformerTrainingArguments(
            output_dir=str(self.output_dir),
            num_train_epochs=self.training_config.num_train_epochs or 3,
            per_device_train_batch_size=self.training_config.per_device_train_batch_size,
            learning_rate=self.training_config.learning_rate,
            warmup_ratio=0.1,
            fp16=self.training_config.fp16,
            bf16=self.training_config.bf16,
            logging_steps=self.training_config.logging_steps,
            save_steps=self.training_config.save_steps or 500,
            save_total_limit=self.training_config.save_total_limit,
            report_to=self.training_config.report_to,
        )

        try:
            # Use the new SentenceTransformerTrainer
            trainer = SentenceTransformerTrainer(
                model=self._model,
                args=training_args,
                train_dataset=hf_dataset,  # Use HuggingFace Dataset
                loss=train_loss,
            )

            train_result = trainer.train()
            training_time = time.time() - start_time

            # Extract metrics and final loss
            metrics = train_result.metrics if hasattr(train_result, 'metrics') else {}
            final_loss = metrics.get('train_loss')

            return TrainingResult(
                success=True,
                output_path=str(self.output_dir),
                final_loss=final_loss,
                total_steps=train_result.global_step if hasattr(train_result, 'global_step') else 0,
                training_time_seconds=training_time,
                metrics=metrics,
            )

        except (TypeError, AttributeError):
            # Fall back to legacy training method
            try:
                # Calculate total steps
                steps_per_epoch = len(train_dataloader)
                epochs = self.training_config.num_train_epochs or 3

                # Legacy fit method
                self._model.fit(
                    train_objectives=[(train_dataloader, train_loss)],
                    epochs=epochs,
                    warmup_steps=int(steps_per_epoch * 0.1),
                    output_path=str(self.output_dir),
                    show_progress_bar=True,
                )

                training_time = time.time() - start_time

                return TrainingResult(
                    success=True,
                    output_path=str(self.output_dir),
                    total_steps=steps_per_epoch * epochs,
                    training_time_seconds=training_time,
                )

            except Exception as e:
                return TrainingResult(
                    success=False,
                    output_path=str(self.output_dir),
                    error_message=str(e),
                    training_time_seconds=time.time() - start_time,
                )

        except Exception as e:
            return TrainingResult(
                success=False,
                output_path=str(self.output_dir),
                error_message=str(e),
                training_time_seconds=time.time() - start_time,
            )

    def _train_with_lora(self, start_time: float) -> TrainingResult:
        """Execute LoRA training using Transformers Trainer."""
        import torch
        from transformers import Trainer, TrainingArguments
        from torch.utils.data import Dataset

        class EmbeddingDataset(Dataset):
            """Dataset wrapper for embedding training with LoRA."""
            def __init__(self, examples, tokenizer, max_length=512):
                self.examples = examples
                self.tokenizer = tokenizer
                self.max_length = max_length

            def __len__(self):
                return len(self.examples)

            def __getitem__(self, idx):
                example = self.examples[idx]
                # Concatenate texts for embedding training
                # Format: [CLS] anchor [SEP] positive [SEP] (negative [SEP])
                texts = example.texts

                if len(texts) == 3:
                    # Triplet: anchor, positive, negative
                    anchor_enc = self.tokenizer(
                        texts[0], truncation=True, max_length=self.max_length,
                        padding="max_length", return_tensors="pt"
                    )
                    positive_enc = self.tokenizer(
                        texts[1], truncation=True, max_length=self.max_length,
                        padding="max_length", return_tensors="pt"
                    )
                    negative_enc = self.tokenizer(
                        texts[2], truncation=True, max_length=self.max_length,
                        padding="max_length", return_tensors="pt"
                    )
                    return {
                        "anchor_input_ids": anchor_enc["input_ids"].squeeze(0),
                        "anchor_attention_mask": anchor_enc["attention_mask"].squeeze(0),
                        "positive_input_ids": positive_enc["input_ids"].squeeze(0),
                        "positive_attention_mask": positive_enc["attention_mask"].squeeze(0),
                        "negative_input_ids": negative_enc["input_ids"].squeeze(0),
                        "negative_attention_mask": negative_enc["attention_mask"].squeeze(0),
                    }
                else:
                    # Pair: anchor, positive
                    anchor_enc = self.tokenizer(
                        texts[0], truncation=True, max_length=self.max_length,
                        padding="max_length", return_tensors="pt"
                    )
                    positive_enc = self.tokenizer(
                        texts[1], truncation=True, max_length=self.max_length,
                        padding="max_length", return_tensors="pt"
                    )
                    return {
                        "anchor_input_ids": anchor_enc["input_ids"].squeeze(0),
                        "anchor_attention_mask": anchor_enc["attention_mask"].squeeze(0),
                        "positive_input_ids": positive_enc["input_ids"].squeeze(0),
                        "positive_attention_mask": positive_enc["attention_mask"].squeeze(0),
                    }

        class ContrastiveLossTrainer(Trainer):
            """Custom trainer with contrastive loss for embedding."""

            def __init__(self, *args, loss_type="mnrl", **kwargs):
                super().__init__(*args, **kwargs)
                self.loss_type = loss_type

            def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
                # Get embeddings for anchor
                anchor_outputs = model(
                    input_ids=inputs["anchor_input_ids"],
                    attention_mask=inputs["anchor_attention_mask"],
                )
                anchor_emb = self._mean_pooling(anchor_outputs, inputs["anchor_attention_mask"])
                anchor_emb = torch.nn.functional.normalize(anchor_emb, p=2, dim=1)

                # Get embeddings for positive
                positive_outputs = model(
                    input_ids=inputs["positive_input_ids"],
                    attention_mask=inputs["positive_attention_mask"],
                )
                positive_emb = self._mean_pooling(positive_outputs, inputs["positive_attention_mask"])
                positive_emb = torch.nn.functional.normalize(positive_emb, p=2, dim=1)

                # Compute loss based on type
                if "negative_input_ids" in inputs:
                    # Triplet loss
                    negative_outputs = model(
                        input_ids=inputs["negative_input_ids"],
                        attention_mask=inputs["negative_attention_mask"],
                    )
                    negative_emb = self._mean_pooling(negative_outputs, inputs["negative_attention_mask"])
                    negative_emb = torch.nn.functional.normalize(negative_emb, p=2, dim=1)

                    # Triplet margin loss
                    loss = torch.nn.functional.triplet_margin_loss(
                        anchor_emb, positive_emb, negative_emb, margin=1.0
                    )
                else:
                    # Contrastive loss (in-batch negatives / MNRL style)
                    # Scale similarity for better gradients (temperature scaling)
                    similarity = torch.matmul(anchor_emb, positive_emb.T) * 20.0
                    labels = torch.arange(similarity.size(0), device=similarity.device)
                    loss = torch.nn.functional.cross_entropy(similarity, labels)

                return (loss, anchor_outputs) if return_outputs else loss

            def _mean_pooling(self, model_output, attention_mask):
                """Mean pooling - take average of token embeddings."""
                token_embeddings = model_output.last_hidden_state
                input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
                return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(
                    input_mask_expanded.sum(1), min=1e-9
                )

        try:
            # Create dataset
            max_length = min(self.data_config.max_seq_length, 512)  # Reasonable default
            train_dataset = EmbeddingDataset(self._dataset, self._tokenizer, max_length)

            # Training arguments
            training_args = TrainingArguments(
                output_dir=str(self.output_dir),
                num_train_epochs=self.training_config.num_train_epochs or 3,
                per_device_train_batch_size=self.training_config.per_device_train_batch_size,
                learning_rate=self.training_config.learning_rate,
                warmup_ratio=0.1,
                fp16=self.training_config.fp16,
                bf16=self.training_config.bf16,
                logging_steps=self.training_config.logging_steps,
                save_steps=self.training_config.save_steps or 500,
                save_total_limit=self.training_config.save_total_limit,
                report_to=self.training_config.report_to,
                gradient_accumulation_steps=self.training_config.gradient_accumulation_steps,
                remove_unused_columns=False,  # Keep our custom columns
            )

            # Create trainer
            loss_type = self.data_config.embedding_loss_type.value if self.data_config.embedding_loss_type else "mnrl"
            trainer = ContrastiveLossTrainer(
                model=self._model,
                args=training_args,
                train_dataset=train_dataset,
                loss_type=loss_type,
            )

            # Train
            train_result = trainer.train()
            training_time = time.time() - start_time

            # Save adapter
            self._model.save_pretrained(str(self.output_dir))
            self._tokenizer.save_pretrained(str(self.output_dir))

            # Extract final loss from metrics
            metrics = train_result.metrics if hasattr(train_result, 'metrics') else {}
            final_loss = metrics.get('train_loss')

            return TrainingResult(
                success=True,
                output_path=str(self.output_dir),
                final_loss=final_loss,
                total_steps=train_result.global_step if hasattr(train_result, 'global_step') else 0,
                training_time_seconds=training_time,
                metrics=metrics,
            )

        except Exception as e:
            return TrainingResult(
                success=False,
                output_path=str(self.output_dir),
                error_message=str(e),
                training_time_seconds=time.time() - start_time,
            )

        finally:
            # Cleanup GPU memory
            self._cleanup_lora_training(trainer if 'trainer' in dir() else None)

    def _cleanup_lora_training(self, trainer=None):
        """Clean up GPU memory after LoRA training."""
        import gc
        import torch

        try:
            if trainer is not None:
                del trainer
        except Exception:
            pass

        try:
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                try:
                    torch.cuda.ipc_collect()
                except Exception:
                    pass
                try:
                    torch.cuda.synchronize()
                except Exception:
                    pass
        except Exception:
            pass

    def save(self, save_path: Optional[str] = None) -> str:
        """Save the fine-tuned model or LoRA adapter."""
        path = Path(save_path or self.output_dir)
        path.mkdir(parents=True, exist_ok=True)

        if self._use_lora:
            # Save LoRA adapter
            self._model.save_pretrained(str(path))
            if self._tokenizer:
                self._tokenizer.save_pretrained(str(path))
        else:
            # Save sentence-transformers model
            self._model.save(str(path))

        return str(path)
