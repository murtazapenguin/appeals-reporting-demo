"""
Penguin Finetuning Trainers

Trainer implementations for different model types.
"""

# Lazy imports - trainers are imported on demand by factory
__all__ = [
    "LLMTrainer",
    "RerankerTrainer",
    "EmbeddingTrainer",
]


def __getattr__(name: str):
    """Lazy import trainers to avoid loading heavy dependencies."""
    if name == "LLMTrainer":
        from .llm import LLMTrainer
        return LLMTrainer
    elif name == "RerankerTrainer":
        from .reranker import RerankerTrainer
        return RerankerTrainer
    elif name == "EmbeddingTrainer":
        from .embedding import EmbeddingTrainer
        return EmbeddingTrainer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
