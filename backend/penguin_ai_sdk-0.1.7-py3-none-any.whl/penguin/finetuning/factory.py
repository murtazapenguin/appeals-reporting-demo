"""
Penguin Finetuning Factory

Factory functions for creating trainers with lazy loading.
"""

from typing import Optional, Union, Dict, Any

from .base import BaseTrainer
from .config import TrainingConfig, DataConfig, TrainingResult
from .models import get_default_model, TrainerType


# Trainer registry - lazy imports to avoid loading heavy dependencies
TRAINER_CLASSES = {
    "llm": ("penguin.finetuning.trainers.llm", "LLMTrainer"),
    "reranker": ("penguin.finetuning.trainers.reranker", "RerankerTrainer"),
    "embedding": ("penguin.finetuning.trainers.embedding", "EmbeddingTrainer"),
}


def _import_trainer_class(trainer_type: str) -> type:
    """
    Dynamically import trainer class to avoid loading all dependencies.

    Args:
        trainer_type: Type of trainer ("llm", "reranker", "embedding")

    Returns:
        Trainer class

    Raises:
        ValueError: If trainer type is unknown
    """
    if trainer_type not in TRAINER_CLASSES:
        raise ValueError(
            f"Unknown trainer type: {trainer_type}. "
            f"Available types: {', '.join(TRAINER_CLASSES.keys())}"
        )

    module_path, class_name = TRAINER_CLASSES[trainer_type]

    import importlib
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def create_trainer(
    trainer_type: str,
    model: Optional[str] = None,
    training_config: Optional[TrainingConfig] = None,
    data_config: Optional[DataConfig] = None,
    output_dir: str = "./output",
    **kwargs
) -> BaseTrainer:
    """
    Create a finetuning trainer.

    Args:
        trainer_type: Type of trainer ("llm", "reranker", "embedding")
        model: Model identifier (uses default if not specified)
        training_config: Training hyperparameters
        data_config: Dataset configuration
        output_dir: Where to save outputs
        **kwargs: Additional trainer-specific configuration

    Returns:
        Configured trainer instance

    Raises:
        ValueError: If trainer_type is unknown or data_config is missing

    Example:
        # LLM finetuning
        trainer = create_trainer(
            "llm",
            model="qwen3-14b",
            data_config=DataConfig(dataset_path="data.csv"),
            output_dir="./adapters"
        )

        result = trainer.train()
        trainer.save()
    """
    trainer_type = trainer_type.lower()

    # Use default model if not specified
    if model is None:
        model = get_default_model(trainer_type)

    # Use default configs if not specified
    if training_config is None:
        if trainer_type == "llm":
            training_config = TrainingConfig.default_llm()
        elif trainer_type == "reranker":
            training_config = TrainingConfig.default_reranker()
        elif trainer_type == "embedding":
            training_config = TrainingConfig.default_embedding()
        else:
            training_config = TrainingConfig()

    if data_config is None:
        raise ValueError("data_config is required")

    # Import and instantiate the trainer class
    trainer_class = _import_trainer_class(trainer_type)

    return trainer_class(
        model_name=model,
        training_config=training_config,
        data_config=data_config,
        output_dir=output_dir,
        **kwargs
    )


def get_available_trainers() -> list:
    """
    Get list of available trainer types based on installed dependencies.

    Returns:
        List of trainer types that have their dependencies installed
    """
    available = []

    # Check LLM (Unsloth)
    try:
        from unsloth import FastLanguageModel  # noqa: F401
        available.append("llm")
    except ImportError:
        # Fall back to checking transformers + trl
        try:
            from transformers import AutoModelForCausalLM  # noqa: F401
            from trl import SFTTrainer  # noqa: F401
            available.append("llm")
        except ImportError:
            pass

    # Check Reranker (transformers + peft)
    try:
        from transformers import AutoModelForSequenceClassification  # noqa: F401
        from peft import get_peft_model  # noqa: F401
        available.append("reranker")
    except ImportError:
        pass

    # Check Embedding (sentence-transformers)
    try:
        from sentence_transformers import SentenceTransformer  # noqa: F401
        available.append("embedding")
    except ImportError:
        pass

    return available


def train(
    trainer_type: str,
    dataset_path: str,
    model: Optional[str] = None,
    output_dir: str = "./output",
    **kwargs
) -> TrainingResult:
    """
    High-level training function.

    This is the main entry point for users who want a simple interface.

    Args:
        trainer_type: "llm", "reranker", or "embedding"
        dataset_path: Path to training data
        model: Model identifier (optional)
        output_dir: Where to save the adapter
        **kwargs: Training hyperparameters (learning_rate, max_steps, etc.)

    Returns:
        TrainingResult with success status and metrics

    Example:
        from penguin.finetuning import train

        result = train(
            "llm",
            dataset_path="training_data.csv",
            model="qwen3-14b",
            output_dir="./my_adapter",
            max_steps=100,
        )

        if result.success:
            print(f"Model saved to {result.output_path}")
    """
    # Separate config params from data params
    training_field_names = set(TrainingConfig.model_fields.keys())
    data_field_names = set(DataConfig.model_fields.keys())

    config_params = {
        k: v for k, v in kwargs.items()
        if k in training_field_names
    }

    data_params = {
        k: v for k, v in kwargs.items()
        if k in data_field_names and k != 'dataset_path'
    }
    data_params['dataset_path'] = dataset_path

    # Build training config
    training_config = None
    if trainer_type == "llm":
        training_config = TrainingConfig.default_llm()
    elif trainer_type == "reranker":
        training_config = TrainingConfig.default_reranker()
    elif trainer_type == "embedding":
        training_config = TrainingConfig.default_embedding()
    else:
        training_config = TrainingConfig()

    # Apply overrides
    for k, v in config_params.items():
        if hasattr(training_config, k):
            setattr(training_config, k, v)

    # Build data config
    data_config = DataConfig(**data_params)

    # Create and run trainer
    trainer = create_trainer(
        trainer_type=trainer_type,
        model=model,
        training_config=training_config,
        data_config=data_config,
        output_dir=output_dir,
    )

    try:
        trainer.load_model()
        trainer.load_dataset()
        result = trainer.train()
        if result.success:
            trainer.save()
        return result
    finally:
        trainer.cleanup()
