"""
Penguin Finetuning Configuration

Pydantic models for training configuration.
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from pathlib import Path

from pydantic import BaseModel, Field, field_validator


class QuantizationType(str, Enum):
    """Quantization options for training."""
    NONE = "none"
    INT8 = "int8"
    INT4 = "int4"
    NF4 = "nf4"


class OptimizerType(str, Enum):
    """Available optimizers."""
    ADAMW = "adamw_torch"
    ADAMW_8BIT = "adamw_8bit"
    ADAMW_FUSED = "adamw_torch_fused"
    SGD = "sgd"
    ADAFACTOR = "adafactor"
    PAGED_ADAMW_8BIT = "paged_adamw_8bit"
    PAGED_ADAMW_32BIT = "paged_adamw_32bit"


class LRSchedulerType(str, Enum):
    """Learning rate scheduler types."""
    CONSTANT = "constant"
    LINEAR = "linear"
    COSINE = "cosine"
    COSINE_WITH_RESTARTS = "cosine_with_restarts"


class EmbeddingLossType(str, Enum):
    """Loss functions for embedding training."""
    TRIPLET = "triplet"                    # TripletLoss - classic margin loss
    COSINE = "cosine"                      # CosineSimilarityLoss - similarity regression
    MULTIPLE_NEGATIVES = "mnrl"            # MultipleNegativesRankingLoss - in-batch negatives (default)
    CONTRASTIVE = "contrastive"            # ContrastiveLoss - pair-based
    ANGLE = "angle"                        # AnglELoss - angular distance


class LoRAConfig(BaseModel):
    """LoRA configuration for PEFT training."""
    r: int = 64
    lora_alpha: int = 64
    lora_dropout: float = 0.0
    target_modules: List[str] = Field(
        default_factory=lambda: ["q_proj", "k_proj", "v_proj"]
    )
    bias: str = "none"
    use_rslora: bool = False

    @classmethod
    def for_llm(cls) -> "LoRAConfig":
        """Default LoRA config for LLM finetuning (Unsloth-optimized)."""
        return cls(
            r=64,
            lora_alpha=64,
            lora_dropout=0.0,  # Unsloth fast path prefers 0
            target_modules=["q_proj", "k_proj", "v_proj"],
        )

    @classmethod
    def for_reranker(cls) -> "LoRAConfig":
        """Default LoRA config for reranker finetuning."""
        return cls(
            r=64,
            lora_alpha=16,
            lora_dropout=0.1,
            target_modules=["query", "value"],
        )

    @classmethod
    def for_embedding(cls) -> "LoRAConfig":
        """Default LoRA config for embedding finetuning.

        Uses 'query' and 'value' target modules which work with:
        - BGE models (XLM-RoBERTa based)
        - E5 models (encoder-based)

        For Qwen-based models (like GTE-Qwen2), use:
            LoRAConfig(target_modules=["q_proj", "v_proj"])
        """
        return cls(
            r=32,
            lora_alpha=32,
            lora_dropout=0.1,
            target_modules=["query", "value"],  # BGE/E5 style
        )


class TrainingConfig(BaseModel):
    """
    Training hyperparameters.

    Designed to work with both Hugging Face Trainer and SFTTrainer.
    """
    # Core training params
    learning_rate: float = 2e-4
    num_train_epochs: Optional[int] = None
    max_steps: int = 150
    per_device_train_batch_size: int = 1
    gradient_accumulation_steps: int = 1

    # Regularization
    weight_decay: float = 0.01
    max_grad_norm: float = 1.0

    # Optimizer & scheduler
    optimizer: OptimizerType = OptimizerType.ADAMW_8BIT
    lr_scheduler_type: LRSchedulerType = LRSchedulerType.CONSTANT
    warmup_steps: int = 5

    # Precision
    fp16: bool = False
    bf16: bool = True

    # Logging & checkpointing
    logging_steps: int = 1
    save_steps: Optional[int] = None
    save_total_limit: Optional[int] = 3

    # Reproducibility
    seed: int = 3407

    # W&B integration
    report_to: str = "none"  # "none", "wandb", "tensorboard"
    run_name: Optional[str] = None

    # LoRA
    lora: Optional[LoRAConfig] = None

    # Quantization
    quantization: QuantizationType = QuantizationType.INT4

    # LLM-specific
    completion_only: bool = True  # Train on responses only

    @classmethod
    def default_llm(cls) -> "TrainingConfig":
        """Default config for LLM finetuning (Unsloth-optimized)."""
        return cls(
            learning_rate=2e-4,
            max_steps=150,
            per_device_train_batch_size=1,
            optimizer=OptimizerType.ADAMW_8BIT,
            lora=LoRAConfig.for_llm(),
            quantization=QuantizationType.INT4,
            completion_only=True,
        )

    @classmethod
    def default_reranker(cls) -> "TrainingConfig":
        """Default config for reranker finetuning."""
        return cls(
            learning_rate=2e-5,
            max_steps=1000,
            per_device_train_batch_size=4,
            optimizer=OptimizerType.ADAMW,
            lora=LoRAConfig.for_reranker(),
            quantization=QuantizationType.INT4,
        )

    @classmethod
    def default_embedding(cls) -> "TrainingConfig":
        """Default config for embedding finetuning (full fine-tuning, no LoRA).

        For LoRA fine-tuning of large models, explicitly set:
            lora=LoRAConfig.for_embedding()
        """
        return cls(
            learning_rate=2e-5,
            num_train_epochs=3,
            max_steps=-1,  # Use epochs
            per_device_train_batch_size=16,
            optimizer=OptimizerType.ADAMW,
            lora=None,  # No LoRA by default - user must explicitly enable
        )

    def to_trainer_kwargs(self) -> Dict[str, Any]:
        """Convert to kwargs for HuggingFace Trainer/SFTTrainer."""
        kwargs = {
            "learning_rate": self.learning_rate,
            "per_device_train_batch_size": self.per_device_train_batch_size,
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "weight_decay": self.weight_decay,
            "max_grad_norm": self.max_grad_norm,
            "warmup_steps": self.warmup_steps,
            "fp16": self.fp16,
            "bf16": self.bf16,
            "logging_steps": self.logging_steps,
            "seed": self.seed,
            "report_to": self.report_to,
            "lr_scheduler_type": self.lr_scheduler_type.value,
            "optim": self.optimizer.value,
        }

        # Handle epochs vs steps
        if self.num_train_epochs is not None and self.max_steps <= 0:
            kwargs["num_train_epochs"] = self.num_train_epochs
        else:
            kwargs["max_steps"] = self.max_steps

        if self.run_name:
            kwargs["run_name"] = self.run_name

        if self.save_steps:
            kwargs["save_steps"] = self.save_steps

        if self.save_total_limit:
            kwargs["save_total_limit"] = self.save_total_limit

        return kwargs


class DataConfig(BaseModel):
    """Dataset configuration."""
    dataset_path: str

    # LLM-specific
    input_column: str = "input"
    output_column: str = "output"
    reasoning_column: Optional[str] = None  # Column containing thinking/reasoning (enables thinking mode)
    system_prompt: Optional[str] = None
    user_prompt: Optional[str] = None

    # Reranker-specific
    query_column: str = "query"
    positive_column: str = "pos"
    negative_column: str = "neg"
    max_query_length: int = 128
    max_passage_length: int = 1024
    train_group_size: int = 8

    # Embedding-specific
    anchor_column: str = "anchor"
    positive_text_column: str = "positive"
    negative_text_column: str = "negative"
    embedding_loss_type: EmbeddingLossType = EmbeddingLossType.MULTIPLE_NEGATIVES  # Default to MNRL (most efficient)

    # Common
    max_seq_length: int = 32000

    @field_validator('dataset_path')
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate and normalize dataset path."""
        return str(Path(v))


class TrainingProgress(BaseModel):
    """Training progress tracking."""
    progress_percentage: float = 0.0
    current_step: int = 0
    total_steps: int = 0
    current_epoch: Optional[float] = None
    latest_loss: Optional[float] = None
    learning_rate: Optional[float] = None


class TrainingResult(BaseModel):
    """Result of a training run."""
    success: bool
    output_path: str
    final_loss: Optional[float] = None
    total_steps: int = 0
    training_time_seconds: float = 0.0
    metrics: Dict[str, Any] = Field(default_factory=dict)
    error_message: Optional[str] = None

    def __bool__(self) -> bool:
        """Allow using result in boolean context."""
        return self.success
