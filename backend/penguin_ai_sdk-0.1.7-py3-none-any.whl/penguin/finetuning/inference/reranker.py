"""
Penguin Reranker Inference

Cross-encoder inference for query-document scoring.
"""

from typing import List, Optional, Dict, Any, Union
from pathlib import Path

from .base import BaseInferenceEngine, DependencyError
from .config import RerankerConfig


class RerankerInference(BaseInferenceEngine):
    """
    Reranker inference engine using cross-encoder architecture.

    Loads finetuned reranker models and scores query-document pairs.

    Example:
        engine = RerankerInference("./reranker_adapter")

        # Score documents
        scores = engine.score("What is AI?", ["AI is...", "Weather is..."])
        # [0.95, 0.12]

        # Rerank documents
        ranked = engine.rerank("What is AI?", documents, top_k=5)
    """

    def __init__(
        self,
        model_path: str,
        base_model: Optional[str] = None,
        device: str = "auto",
        config: Optional[RerankerConfig] = None,
        **kwargs
    ):
        """
        Initialize reranker inference engine.

        Args:
            model_path: Path to the finetuned reranker model or adapter
            base_model: Base model HF ID (if model_path is adapter only)
            device: Device to use ("auto", "cuda", "cpu")
            config: Reranker configuration
        """
        super().__init__(model_path, device, **kwargs)
        self.base_model = base_model
        self.config = config or RerankerConfig()

    @property
    def engine_type(self) -> str:
        return "reranker"

    def _check_dependencies(self) -> None:
        """Check that required dependencies are installed."""
        try:
            from transformers import AutoModelForSequenceClassification  # noqa: F401
            from transformers import AutoTokenizer  # noqa: F401
        except ImportError:
            raise DependencyError(
                package="transformers",
                engine_type="reranker",
                install_hint="pip install penguin-ai-sdk[finetuning]"
            )

    def load(self) -> None:
        """Load the reranker model."""
        self._check_dependencies()

        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        device = self._resolve_device()

        # Determine model path
        model_path = str(self.model_path)

        # Check if this is a PEFT adapter
        adapter_config_path = Path(model_path) / "adapter_config.json"
        is_adapter = adapter_config_path.exists()

        if is_adapter:
            # Load base model + adapter
            from peft import PeftModel

            if not self.base_model:
                # Try to get base model from adapter config
                import json
                with open(adapter_config_path) as f:
                    config = json.load(f)
                    self.base_model = config.get("base_model_name_or_path")

            if not self.base_model:
                raise ValueError(
                    "base_model must be specified when loading a PEFT adapter"
                )

            # Load base model
            base = AutoModelForSequenceClassification.from_pretrained(
                self.base_model,
                torch_dtype=torch.bfloat16,
                device_map=device,
            )

            # Load adapter
            self._model = PeftModel.from_pretrained(base, model_path)
            self._tokenizer = AutoTokenizer.from_pretrained(self.base_model)
        else:
            # Load full model
            self._model = AutoModelForSequenceClassification.from_pretrained(
                model_path,
                torch_dtype=torch.bfloat16,
                device_map=device,
            )
            self._tokenizer = AutoTokenizer.from_pretrained(model_path)

        self._model.eval()
        self._loaded = True

    def _encode_pairs(
        self,
        query: str,
        documents: List[str],
    ) -> Dict[str, Any]:
        """
        Tokenize query-document pairs for cross-encoder.

        Args:
            query: The query text
            documents: List of document texts

        Returns:
            Tokenized inputs ready for the model
        """
        import torch

        pairs = [[query, doc] for doc in documents]

        inputs = self._tokenizer(
            pairs,
            padding=True,
            truncation=True,
            max_length=self.config.max_length,
            return_tensors="pt",
        )

        # Move to model device
        device = next(self._model.parameters()).device
        return {k: v.to(device) for k, v in inputs.items()}

    def score(
        self,
        query: str,
        documents: Union[str, List[str]],
        batch_size: Optional[int] = None,
    ) -> List[float]:
        """
        Score query-document pairs.

        Args:
            query: The query text
            documents: Document(s) to score against the query
            batch_size: Batch size for scoring (default from config)

        Returns:
            List of relevance scores (0-1, higher is more relevant)
        """
        import torch

        if not self._loaded:
            self.load()

        # Handle single document
        if isinstance(documents, str):
            documents = [documents]

        batch_size = batch_size or self.config.batch_size
        all_scores = []

        with torch.no_grad():
            for i in range(0, len(documents), batch_size):
                batch_docs = documents[i:i + batch_size]
                inputs = self._encode_pairs(query, batch_docs)

                outputs = self._model(**inputs)
                logits = outputs.logits

                # Apply sigmoid for relevance scores
                scores = torch.sigmoid(logits).squeeze(-1)
                all_scores.extend(scores.cpu().tolist())

        # Handle single score case
        if len(all_scores) == 1 and isinstance(all_scores[0], float):
            return all_scores

        # Ensure we return a flat list
        return [float(s) for s in all_scores]

    def rerank(
        self,
        query: str,
        documents: List[str],
        top_k: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Rerank documents by relevance to query.

        Args:
            query: The query text
            documents: List of documents to rerank
            top_k: Number of top documents to return (None for all)

        Returns:
            List of dicts with 'document', 'score', and 'index' keys,
            sorted by score descending
        """
        if not self._loaded:
            self.load()

        scores = self.score(query, documents)

        # Create result list with original indices
        results = [
            {
                "document": doc,
                "score": score,
                "index": idx,
            }
            for idx, (doc, score) in enumerate(zip(documents, scores))
        ]

        # Sort by score descending
        results.sort(key=lambda x: x["score"], reverse=True)

        # Apply top_k
        if top_k is not None:
            results = results[:top_k]

        return results
