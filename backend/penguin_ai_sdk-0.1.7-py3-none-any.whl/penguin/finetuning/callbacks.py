"""
Penguin Finetuning Callbacks

Training callbacks for progress tracking and early stopping.
"""

import json
from pathlib import Path
from typing import Optional, Any, Dict

# Import TrainerCallback for proper inheritance
try:
    from transformers import TrainerCallback
    HAS_TRANSFORMERS = True
except ImportError:
    # Fallback base class if transformers not installed
    class TrainerCallback:
        def on_init_end(self, args, state, control, **kwargs): pass
        def on_train_begin(self, args, state, control, **kwargs): pass
        def on_train_end(self, args, state, control, **kwargs): pass
        def on_step_end(self, args, state, control, **kwargs): pass
        def on_epoch_end(self, args, state, control, **kwargs): pass
        def on_log(self, args, state, control, logs=None, **kwargs): pass
    HAS_TRANSFORMERS = False


class ProgressCallback(TrainerCallback):
    """
    Callback to write real-time progress to progress.json during training.

    Compatible with HuggingFace TrainerCallback interface.
    """

    def __init__(self, output_dir: str):
        """
        Initialize the progress callback.

        Args:
            output_dir: Directory to write progress.json
        """
        self.output_dir = Path(output_dir)
        self.progress_path = self.output_dir / "progress.json"
        self.last_loss: Optional[float] = None

        # Ensure output directory exists
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def on_log(self, args, state, control, logs: Optional[Dict[str, Any]] = None, **kwargs):
        """
        Write progress info to progress.json on every log event.

        This method signature matches HuggingFace TrainerCallback.
        """
        if not state:
            return

        # Calculate progress percentage
        progress_percentage = 0.0
        if state.max_steps and state.max_steps > 0:
            progress_percentage = (state.global_step / state.max_steps) * 100

        # Extract loss and epoch from logs
        if logs and "loss" in logs:
            self.last_loss = logs["loss"]

        current_epoch = logs.get("epoch") if logs else None
        learning_rate = logs.get("learning_rate") if logs else None

        # Build progress data
        progress_data = {
            "progress_percentage": round(progress_percentage, 2),
            "current_step": state.global_step,
            "total_steps": state.max_steps,
            "current_epoch": round(current_epoch, 2) if current_epoch is not None else None,
            "latest_loss": round(self.last_loss, 4) if self.last_loss is not None else None,
            "learning_rate": learning_rate,
        }

        # Write to progress.json
        try:
            with open(self.progress_path, "w") as f:
                json.dump(progress_data, f, indent=2)
        except Exception:
            # Silently fail to avoid disrupting training
            pass

    def on_train_begin(self, args, state, control, **kwargs):
        """Called at the beginning of training."""
        pass

    def on_train_end(self, args, state, control, **kwargs):
        """Called at the end of training."""
        # Write final progress
        progress_data = {
            "progress_percentage": 100.0,
            "current_step": state.global_step if state else 0,
            "total_steps": state.max_steps if state else 0,
            "current_epoch": None,
            "latest_loss": round(self.last_loss, 4) if self.last_loss is not None else None,
            "status": "completed",
        }
        try:
            with open(self.progress_path, "w") as f:
                json.dump(progress_data, f, indent=2)
        except Exception:
            pass

    def on_step_end(self, args, state, control, **kwargs):
        """Called at the end of each step."""
        pass

    def on_epoch_end(self, args, state, control, **kwargs):
        """Called at the end of each epoch."""
        pass


class LossThresholdStoppingCallback(TrainerCallback):
    """
    Early stopping callback based on loss threshold.

    Stops training when loss stays below threshold for a consecutive
    number of steps (default 30).

    Compatible with HuggingFace TrainerCallback interface.
    """

    def __init__(self, threshold: float = 0.01, patience: int = 30):
        """
        Initialize the callback.

        Args:
            threshold: Loss threshold below which to count steps
            patience: Number of consecutive steps below threshold to trigger stop
        """
        self.threshold = threshold
        self.patience = patience
        self.consecutive_count = 0

    def on_log(self, args, state, control, logs: Optional[Dict[str, Any]] = None, **kwargs):
        """
        Check loss and potentially stop training.
        """
        if not logs:
            return

        loss = logs.get("loss")
        if loss is None:
            return

        if loss > self.threshold:
            self.consecutive_count = 0
        else:
            self.consecutive_count += 1
            if self.consecutive_count >= self.patience:
                control.should_training_stop = True
                print(
                    f"Training stopped: loss ({loss:.4f}) below threshold "
                    f"({self.threshold}) for {self.patience} consecutive steps"
                )

    def on_train_begin(self, args, state, control, **kwargs):
        """Reset counter at training start."""
        self.consecutive_count = 0

    def on_train_end(self, args, state, control, **kwargs):
        """Called at the end of training."""
        pass

    def on_step_end(self, args, state, control, **kwargs):
        """Called at the end of each step."""
        pass

    def on_epoch_end(self, args, state, control, **kwargs):
        """Called at the end of each epoch."""
        pass


class MetricLoggingCallback(TrainerCallback):
    """
    Callback to collect and log training metrics.

    Compatible with HuggingFace TrainerCallback interface.
    """

    def __init__(self):
        """Initialize the callback."""
        self.metrics: Dict[str, list] = {
            "loss": [],
            "learning_rate": [],
            "epoch": [],
            "step": [],
        }

    def on_log(self, args, state, control, logs: Optional[Dict[str, Any]] = None, **kwargs):
        """Collect metrics from logs."""
        if not logs or not state:
            return

        if "loss" in logs:
            self.metrics["loss"].append(logs["loss"])
        if "learning_rate" in logs:
            self.metrics["learning_rate"].append(logs["learning_rate"])
        if "epoch" in logs:
            self.metrics["epoch"].append(logs["epoch"])

        self.metrics["step"].append(state.global_step)

    def get_metrics(self) -> Dict[str, list]:
        """Return collected metrics."""
        return self.metrics

    def get_final_loss(self) -> Optional[float]:
        """Return the final loss value."""
        if self.metrics["loss"]:
            return self.metrics["loss"][-1]
        return None

    def on_train_begin(self, args, state, control, **kwargs):
        """Reset metrics at training start."""
        for key in self.metrics:
            self.metrics[key] = []

    def on_train_end(self, args, state, control, **kwargs):
        """Called at the end of training."""
        pass

    def on_step_end(self, args, state, control, **kwargs):
        """Called at the end of each step."""
        pass

    def on_epoch_end(self, args, state, control, **kwargs):
        """Called at the end of each epoch."""
        pass
