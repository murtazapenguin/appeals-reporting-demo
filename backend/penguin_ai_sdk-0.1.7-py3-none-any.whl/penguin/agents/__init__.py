"""
Penguin Agents Module

Provides agent functionality for LLM + tool orchestration.

Classes:
    Agent: Reusable agent with pre-configured LLM and tools
    AgentResponse: Response container from agent runs
    ToolGeneratorService: Generate tools from natural language
    GeneratedTool: Container for generated tools awaiting registration
    CodeGeneratorAgent: Agent for generating code from workflow descriptions
    WorkflowSuggestionAgent: Agent for workflow design and orchestration

Checkpointing:
    CheckpointManager: High-level API for checkpoint operations
    CheckpointRegistry: File-based storage for checkpoints
    AgentCheckpoint: Persisted state of an agent execution
    CheckpointSummary: Lightweight checkpoint summary for listing
    CheckpointStatus: Status enum (RUNNING, COMPLETED, FAILED)
    CheckpointToolMismatchError: Error when resume tools don't match

Functions:
    chat_with_tools: Execute an agentic loop with tool execution
    list_resumable_runs: List agent runs that can be resumed
    cleanup_old_checkpoints: Remove old and completed checkpoints
"""

from .base import Agent, AgentResponse, chat_with_tools
from .tool_generator import ToolGeneratorService, GeneratedTool
from .coder import CodeGeneratorAgent, PenguinCoderAgent
from .workflow import WorkflowSuggestionAgent
from .checkpoint import (
    CheckpointManager,
    CheckpointRegistry,
    AgentCheckpoint,
    CheckpointSummary,
    CheckpointStatus,
    CheckpointToolMismatchError,
    list_resumable_runs,
    cleanup_old_checkpoints,
)

__all__ = [
    # Core agent classes
    "Agent",
    "AgentResponse",
    "chat_with_tools",
    # Tool generation
    "ToolGeneratorService",
    "GeneratedTool",
    # Code generation
    "CodeGeneratorAgent",
    "PenguinCoderAgent",  # Backwards compat alias
    "WorkflowSuggestionAgent",
    # Checkpointing
    "CheckpointManager",
    "CheckpointRegistry",
    "AgentCheckpoint",
    "CheckpointSummary",
    "CheckpointStatus",
    "CheckpointToolMismatchError",
    "list_resumable_runs",
    "cleanup_old_checkpoints",
]
