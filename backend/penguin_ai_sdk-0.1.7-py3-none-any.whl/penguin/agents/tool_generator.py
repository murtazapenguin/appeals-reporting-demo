"""
Tool Generator Service

Generates tools from natural language descriptions using LLM,
then allows users to review and register them.

Uses Penguin LLM and Tools modules for provider-agnostic operation.
"""

import json
import logging
from typing import Any, Dict, Optional, Tuple

from penguin.llm import create_client, UserMessage, SystemMessage
from penguin.tools import ToolRegistry, tool, ToolExecutor

logger = logging.getLogger(__name__)


# System prompt for tool generation
TOOL_GENERATION_PROMPT = """
You are an expert programmer specializing in creating AI tools. Your task is to generate a JSON schema and a corresponding Python function based on a user's natural language description.

You MUST follow these rules:
1. The JSON schema must conform to the OpenAI tool format. It must have a `type` of "function" and a `function` object containing `name`, `description`, and `parameters`.
2. The `parameters` object itself MUST have a `"type": "object"` field, alongside the `properties` field. This is critical.
3. The Python function must have a name that matches the `name` in the schema.
4. The function's parameters must match the `properties` defined in the schema, including type hints.
5. The function should include a clear docstring explaining what it does, its arguments, and what it returns.
6. The function should return a JSON string as its final output. It must handle potential errors gracefully within a try-except block and return errors as a JSON string too.
7. You MUST wrap the generated JSON schema in `<<<SCHEMA>>>` and `</SCHEMA>>>` tags.
8. You MUST wrap the generated Python code in `<<<PYTHON>>>` and `</PYTHON>>>` tags.
9. Do NOT include any other text, explanations, or introductory sentences outside of these tags.
"""


class GeneratedTool:
    """Container for a generated tool awaiting registration."""

    def __init__(
        self,
        name: str,
        description: str,
        schema: Dict[str, Any],
        code: str,
        raw_response: str
    ):
        self.name = name
        self.description = description
        self.schema = schema
        self.code = code
        self.raw_response = raw_response

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "schema": self.schema,
            "code": self.code,
        }

    def __repr__(self) -> str:
        return f"<GeneratedTool name={self.name}>"


class ToolGeneratorService:
    """
    Service for generating and registering tools from natural language descriptions.

    Two-step process:
    1. generate_tool() - LLM creates schema + code, returns for user review
    2. register_tool() - User approves and adds to persistent registry

    Example:
        service = ToolGeneratorService()

        # Step 1: Generate (user reviews output)
        generated = await service.generate_tool(
            "Create a tool that converts temperature from Celsius to Fahrenheit"
        )
        print(generated.schema)
        print(generated.code)

        # Step 2: Register (user approves)
        tool = service.register_tool(generated)

        # Now available for use
        executor = service.get_executor()
        tools = executor.to_provider_format("bedrock")
    """

    def __init__(
        self,
        provider: str = "bedrock",
        model: str = "claude-sonnet-4-5",
        registry: Optional[ToolRegistry] = None,
        **client_kwargs
    ):
        """
        Initialize the tool generator service.

        Args:
            provider: LLM provider ("bedrock", "gemini", "openai")
            model: Model identifier
            registry: Optional existing ToolRegistry (creates new if None)
            **client_kwargs: Additional args for LLM client (e.g., region_name)
        """
        self.llm_client = create_client(provider, model=model, **client_kwargs)
        self.registry = registry or ToolRegistry()

        logger.info(f"ToolGeneratorService initialized with {provider}/{model}")

    # ==================== GENERATION ====================

    async def generate_tool(self, description: str) -> GeneratedTool:
        """
        Generate a tool from natural language description.

        Returns a GeneratedTool object for user review before registration.

        Args:
            description: Natural language description of the tool to create

        Returns:
            GeneratedTool with schema, code, and metadata

        Raises:
            ValueError: If LLM output cannot be parsed
        """
        logger.info(f"Generating tool from description: {description[:100]}...")

        # Call LLM to generate schema + code
        messages = [
            SystemMessage(TOOL_GENERATION_PROMPT),
            UserMessage(description)
        ]

        result = await self.llm_client.create(
            messages,
            temperature=0.0,
            max_tokens=4096
        )

        raw_response = result.content
        logger.debug(f"LLM response: {raw_response}")

        # Parse the response
        schema, code = self._parse_llm_output(raw_response)

        if schema is None or code is None:
            raise ValueError(
                f"Failed to parse LLM output. Raw response:\n{raw_response}"
            )

        # Extract tool metadata
        func_info = schema.get("function", {})
        name = func_info.get("name", "unknown")
        tool_description = func_info.get("description", "")

        generated = GeneratedTool(
            name=name,
            description=tool_description,
            schema=schema,
            code=code,
            raw_response=raw_response
        )

        logger.info(f"Generated tool: {name}")
        return generated

    def _parse_llm_output(self, llm_response: str) -> Tuple[Optional[Dict], Optional[str]]:
        """Parse LLM output to extract schema and function code."""
        try:
            # Extract schema
            schema_start = llm_response.find("<<<SCHEMA>>>")
            schema_end = llm_response.find("</SCHEMA>>>")

            if schema_start == -1 or schema_end == -1:
                logger.error("Schema tags not found in response")
                return None, None

            schema_str = llm_response[schema_start + 12:schema_end].strip()
            schema_json = json.loads(schema_str)

            # Extract Python code
            code_start = llm_response.find("<<<PYTHON>>>")
            code_end = llm_response.find("</PYTHON>>>")

            if code_start == -1 or code_end == -1:
                logger.error("Python code tags not found in response")
                return None, None

            python_code = llm_response[code_start + 12:code_end].strip()

            return schema_json, python_code

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse schema JSON: {e}")
            return None, None
        except Exception as e:
            logger.error(f"Failed to parse LLM output: {e}")
            return None, None

    # ==================== REGISTRATION ====================

    def register_tool(self, generated: GeneratedTool, persist: bool = True):
        """
        Register a generated tool in the registry.

        Args:
            generated: GeneratedTool from generate_tool()
            persist: Whether to persist to disk (default: True)

        Returns:
            The created FunctionTool

        Raises:
            ValueError: If tool code is invalid or name already exists
        """
        logger.info(f"Registering tool: {generated.name}")

        # Check if tool already exists
        if generated.name in self.registry:
            raise ValueError(f"Tool '{generated.name}' already exists in registry")

        # Use registry's create_from_code method
        tool = self.registry.create_from_code(
            name=generated.name,
            description=generated.description,
            code=generated.code,
            persist=persist
        )

        logger.info(f"Tool '{generated.name}' registered successfully")
        return tool

    def register_from_dict(
        self,
        name: str,
        description: str,
        code: str,
        persist: bool = True
    ):
        """
        Register a tool directly from schema and code strings.

        Useful when receiving tool data from an API request.

        Args:
            name: Tool function name
            description: Tool description
            code: Python code defining the function
            persist: Whether to persist to disk

        Returns:
            The created FunctionTool
        """
        return self.registry.create_from_code(
            name=name,
            description=description,
            code=code,
            persist=persist
        )

    # ==================== REGISTRY ACCESS ====================

    def get_executor(self) -> ToolExecutor:
        """Get a ToolExecutor with all registered tools."""
        return self.registry.get_executor()

    def list_tools(self) -> list:
        """List all registered tool names."""
        return self.registry.list()

    def delete_tool(self, name: str) -> bool:
        """Delete a tool from the registry."""
        return self.registry.delete(name)

    def get_tool(self, name: str):
        """Get a tool by name."""
        return self.registry.get(name)

    def to_provider_format(self, provider: str) -> list:
        """Convert all tools to provider-specific format."""
        return self.registry.to_provider_format(provider)

    @property
    def total_tools(self) -> int:
        """Get total number of registered tools."""
        return len(self.registry)
