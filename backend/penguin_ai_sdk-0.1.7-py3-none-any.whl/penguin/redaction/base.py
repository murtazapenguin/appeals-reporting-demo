"""
Penguin PII Redaction Base

Abstract base class for PII redaction providers.
"""

from abc import ABC, abstractmethod
from typing import List, Set

from .models import PIIEntity, RedactionResult


class BaseRedactor(ABC):
    """Abstract base class for PII redaction providers."""

    @abstractmethod
    def get_supported_labels(self) -> Set[str]:
        """
        Returns the set of PII entity labels this provider can detect.

        Returns:
            Set of label strings (e.g., {'NAME', 'EMAIL_ADDRESS', 'DATE'})
        """
        pass

    @abstractmethod
    def redact(self, text: str) -> str:
        """
        Redact PII from text and return the masked result.

        Args:
            text: Input text containing potential PII

        Returns:
            Text with PII replaced by labels (e.g., "[NAME]")
        """
        pass

    @abstractmethod
    def predict(self, text: str) -> List[PIIEntity]:
        """
        Detect PII entities in text without redacting.

        Args:
            text: Input text to analyze

        Returns:
            List of detected PII entities with positions
        """
        pass

    @abstractmethod
    def redact_with_details(self, text: str) -> RedactionResult:
        """
        Redact PII and return full details including entities.

        Args:
            text: Input text containing potential PII

        Returns:
            RedactionResult with original text, redacted text, and entity list
        """
        pass
