"""
Penguin PII Redactor

API-based PII redaction using Penguin's deployed PII detection service.
"""

import os
from typing import List, Set

import requests

from ..base import BaseRedactor
from ..models import PIIEntity, RedactionResult


class PenguinPIIRedactor(BaseRedactor):
    """
    PII redactor using Penguin's deployed API.

    No local model required - all processing is done via the API.

    Supported labels:
        - PASSWORD
        - DATE
        - NUMERICAL_PII
        - EMAIL_ADDRESS
        - DOB
        - NAME
        - LOCATION_ADDRESS

    Example:
        >>> from penguin.redaction import PenguinPIIRedactor
        >>> redactor = PenguinPIIRedactor()
        >>> redactor.redact("John Smith's email is john@example.com")
        "[NAME] [NAME]'s email is [EMAIL_ADDRESS]..."
    """

    SUPPORTED_LABELS = {
        "PASSWORD",
        "DATE",
        "NUMERICAL_PII",
        "EMAIL_ADDRESS",
        "DOB",
        "NAME",
        "LOCATION_ADDRESS",
    }

    def __init__(self, base_url: str = None, timeout: int = 30):
        """
        Initialize the PII redactor.

        Args:
            base_url: API base URL. Defaults to PENGUIN_PII_API_URL env var
                      or the production endpoint.
            timeout: Request timeout in seconds (default: 30)
        """
        self.base_url = base_url or os.environ.get(
            "PENGUIN_PII_API_URL",
            "https://dev-api.penguinai.co/infer-platform-mvp-dev/pii"
        )
        self.timeout = timeout

    def get_supported_labels(self) -> Set[str]:
        """Returns the set of PII labels this provider can detect."""
        return self.SUPPORTED_LABELS

    def predict(self, text: str) -> List[PIIEntity]:
        """
        Detect PII entities in text without redacting.

        Args:
            text: Input text to analyze

        Returns:
            List of PIIEntity objects with detected entities

        Raises:
            requests.HTTPError: If API request fails
        """
        response = requests.post(
            f"{self.base_url}/predict",
            json={"text": text},
            headers={"Content-Type": "application/json"},
            timeout=self.timeout
        )
        response.raise_for_status()

        data = response.json()
        # Filter out 'O' (non-entity) labels
        return [
            PIIEntity(**entity)
            for entity in data["entities"]
            if entity["label"] != "O"
        ]

    def redact(self, text: str) -> str:
        """
        Redact PII from text and return the masked result.

        Args:
            text: Input text containing potential PII

        Returns:
            Text with PII replaced by labels (e.g., "[NAME]")

        Raises:
            requests.HTTPError: If API request fails
        """
        response = requests.post(
            f"{self.base_url}/redact-text",
            json={"text": text},
            headers={"Content-Type": "application/json"},
            timeout=self.timeout
        )
        response.raise_for_status()

        return response.json()["redacted_text"]

    def redact_with_details(self, text: str) -> RedactionResult:
        """
        Redact PII and return full details including entities.

        Args:
            text: Input text containing potential PII

        Returns:
            RedactionResult with original text, redacted text, and entity list

        Raises:
            requests.HTTPError: If API request fails
        """
        response = requests.post(
            f"{self.base_url}/redact-text",
            json={"text": text},
            headers={"Content-Type": "application/json"},
            timeout=self.timeout
        )
        response.raise_for_status()

        data = response.json()
        return RedactionResult(
            original_text=data["original_text"],
            redacted_text=data["redacted_text"],
            entities=[PIIEntity(**e) for e in data["entities_redacted"]],
            provider="penguin_pii_api"
        )
