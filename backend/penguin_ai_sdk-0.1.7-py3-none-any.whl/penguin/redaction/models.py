"""
Penguin PII Redaction Models

Pydantic models for PII detection and redaction results.
"""

from typing import List
from pydantic import BaseModel


class PIIEntity(BaseModel):
    """Represents a detected PII entity."""
    text: str
    label: str
    start: int
    end: int


class RedactionResult(BaseModel):
    """Result of a redaction operation with full details."""
    original_text: str
    redacted_text: str
    entities: List[PIIEntity]
    provider: str = "penguin_pii_api"
