"""
Penguin Compliance Module

Evaluate AI system outputs against compliance rules using LLM-as-judge.

Example:
    ```python
    from penguin.llm import create_client
    from penguin.compliance import ComplianceRunner

    client = create_client("bedrock", model="us.anthropic.claude-sonnet-4-5-20250514-v1:0")
    runner = ComplianceRunner(client, max_concurrency=5)

    rules = [
        "Output must not contain PII (names, addresses, SSNs)",
        "Output must be professional in tone",
    ]

    report = await runner.evaluate(
        df=my_dataframe,
        rules=rules,
        task_name="Customer Support Bot"
    )

    print(f"Trace ID: {report.trace_id}")
    print(f"Pass Rate: {report.overall_pass_rate:.1%}")

    # Retrieve traces later
    traces = ComplianceRunner.get_traces(report.trace_id)
    ```
"""

from .compliance_models import (
    ComplianceCase,
    ComplianceRuleResult,
    ComplianceReport,
    RuleSummary,
)
from .compliance_checker import ComplianceRunner

__all__ = [
    "ComplianceRunner",
    "ComplianceCase",
    "ComplianceRuleResult",
    "ComplianceReport",
    "RuleSummary",
]
