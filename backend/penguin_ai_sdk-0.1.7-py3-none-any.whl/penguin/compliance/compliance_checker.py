"""
Penguin Compliance Runner

Main orchestrator for compliance evaluation on input-output pairs.
"""

import asyncio
import logging
import uuid
from typing import Dict, List, Optional, Any

import pandas as pd

from ..llm.base import BaseChatCompletionClient
from ..llm.messages import SystemMessage, UserMessage
from ..observability import (
    get_exporter,
    set_trace_context,
    reset_context,
    get_tracer,
)
from ..observability.attributes import GenAIAttributes

from .compliance_models import (
    ComplianceCase,
    ComplianceRuleResult,
    ComplianceReport,
    RuleSummary,
    BatchRuleResponse,
)

logger = logging.getLogger("penguin.compliance")


class ComplianceRunner:
    """
    Main orchestrator for compliance evaluation.

    Evaluates input-output pairs against compliance rules using LLM-as-judge.
    Each evaluation is traced and can be retrieved later using the trace_id.

    Example:
        ```python
        from penguin.llm import create_client
        from penguin.compliance import ComplianceRunner

        client = create_client("bedrock", model="us.anthropic.claude-sonnet-4-5-20250514-v1:0")
        runner = ComplianceRunner(client, max_concurrency=5)

        rules = [
            "Output must not contain PII (names, addresses, SSNs)",
            "Output must be professional in tone",
        ]

        report = await runner.evaluate(
            df=my_dataframe,
            rules=rules,
            task_name="Customer Support Bot",
            input_col="input",
            output_col="output"
        )

        print(f"Trace ID: {report.trace_id}")
        print(f"Pass Rate: {report.overall_pass_rate:.1%}")
        ```
    """

    def __init__(
        self,
        client: BaseChatCompletionClient,
        max_concurrency: int = 5
    ):
        """
        Initialize the compliance runner.

        Args:
            client: LLM client for evaluation (any provider via BaseChatCompletionClient)
            max_concurrency: Maximum concurrent LLM evaluations (default: 5)
        """
        self.client = client
        self.semaphore = asyncio.Semaphore(max_concurrency)
        self.max_concurrency = max_concurrency

    def _df_to_cases(
        self,
        df: pd.DataFrame,
        input_col: str,
        output_col: str,
        context_col: Optional[str] = None
    ) -> List[ComplianceCase]:
        """Convert DataFrame rows to ComplianceCase objects."""
        cases = []
        for idx, row in df.iterrows():
            input_text = str(row.get(input_col, "")) if pd.notna(row.get(input_col)) else ""
            output_text = str(row.get(output_col, "")) if pd.notna(row.get(output_col)) else ""
            context = None
            if context_col and context_col in row:
                context = str(row.get(context_col, "")) if pd.notna(row.get(context_col)) else None

            case = ComplianceCase(
                row_index=int(idx),
                input_text=input_text,
                output_text=output_text,
                context=context
            )
            cases.append(case)
        return cases

    async def _evaluate_batch(
        self,
        rules_list: List[str],
        case: ComplianceCase,
        task_name: str,
        use_thinking: bool = True
    ) -> List[ComplianceRuleResult]:
        """
        Evaluate multiple rules on one case in a single LLM call.

        Args:
            rules_list: List of rule descriptions (up to 10)
            case: The input-output pair to evaluate
            task_name: Name/description of the task
            use_thinking: Whether to enable thinking mode (default: True)

        Returns:
            List of ComplianceRuleResult, one per rule
        """
        async with self.semaphore:
            # Build numbered rules list for prompt
            rules_text = "\n".join(
                f"[{i}] {rule}" for i, rule in enumerate(rules_list)
            )

            system_content = f"""You are a compliance evaluator for: {task_name}

You will evaluate the OUTPUT against MULTIPLE RULES.
For EACH rule, determine if it passes or fails.

Think through each rule carefully before making a decision.
Return your evaluation for ALL rules in the specified JSON format."""

            user_content = f"""RULES TO EVALUATE:
{rules_text}

INPUT: {case.input_text}

OUTPUT: {case.output_text}"""

            if case.context:
                user_content += f"\n\nCONTEXT: {case.context}"

            user_content += """

Evaluate the OUTPUT against EACH rule above.
Return JSON with an evaluation for each rule by its index (0-based)."""

            messages = [
                SystemMessage(system_content),
                UserMessage(user_content)
            ]

            try:
                # Build request kwargs
                request_kwargs = {
                    "messages": messages,
                    "output_format": BatchRuleResponse,
                    "temperature": 0.0,
                }

                # Enable thinking if supported and requested
                if use_thinking and self.client.capabilities.supports_thinking:
                    request_kwargs["thinking"] = True

                response = await self.client.create(**request_kwargs)

                # Log thinking if available
                if hasattr(response, 'thinking') and response.thinking:
                    logger.debug(f"Thinking (row {case.row_index}): {response.thinking[:200]}...")

                # Parse response
                content = response.content
                results = []

                if isinstance(content, dict):
                    evaluations = content.get("evaluations", [])
                else:
                    # Try to parse string as JSON
                    import json
                    try:
                        parsed = json.loads(str(content))
                        evaluations = parsed.get("evaluations", [])
                    except (json.JSONDecodeError, TypeError):
                        # Return all as failed if parse error
                        return [
                            ComplianceRuleResult(
                                rule_name=rule[:100],
                                row_index=case.row_index,
                                passed=False,
                                reason=f"Parse error: {str(content)[:100]}"
                            )
                            for rule in rules_list
                        ]

                # Map evaluations back to rules
                eval_by_index = {e.get("rule_index", i): e for i, e in enumerate(evaluations)}

                for i, rule in enumerate(rules_list):
                    eval_data = eval_by_index.get(i, {})
                    results.append(ComplianceRuleResult(
                        rule_name=rule[:100],
                        row_index=case.row_index,
                        passed=bool(eval_data.get("passed", False)),
                        reason=str(eval_data.get("reason", "No reason provided"))
                    ))

                return results

            except Exception as e:
                logger.error(f"Error batch evaluating on row {case.row_index}: {e}")
                return [
                    ComplianceRuleResult(
                        rule_name=rule[:100],
                        row_index=case.row_index,
                        passed=False,
                        reason=f"Evaluation error: {str(e)}"
                    )
                    for rule in rules_list
                ]

    async def evaluate(
        self,
        df: pd.DataFrame,
        rules: List[str],
        task_name: str,
        input_col: str = "input",
        output_col: str = "output",
        context_col: Optional[str] = None,
        threshold: float = 0.7,
        batch_size: int = 10,
        use_thinking: bool = True
    ) -> ComplianceReport:
        """
        Evaluate compliance rules on input-output pairs.

        Args:
            df: DataFrame with input-output pairs
            rules: List of rule description strings
            task_name: Description of the task being evaluated
            input_col: Column name for input text (default: "input")
            output_col: Column name for output text (default: "output")
            context_col: Optional column name for additional context
            threshold: Pass/fail threshold for overall_passed (default: 0.7)
            batch_size: Max rules to evaluate per LLM call (default: 10)
            use_thinking: Enable thinking mode for supported models (default: True)

        Returns:
            ComplianceReport with trace_id for later retrieval
        """
        tracer = get_tracer("penguin.compliance")

        # Initialize trace_id and tokens - will be updated from OTel span
        trace_id = str(uuid.uuid4())  # Fallback UUID
        tokens = set_trace_context(trace_id, str(uuid.uuid4()))  # Initialize tokens

        try:
            with tracer.start_as_current_span("compliance.evaluate") as span:
                # Get actual OTel trace_id from the span context
                span_context = span.get_span_context()
                if span_context.is_valid:
                    trace_id = format(span_context.trace_id, '032x')
                    # Update trace context with OTel trace_id
                    reset_context(*tokens)
                    tokens = set_trace_context(trace_id, format(span_context.span_id, '016x'))

                span.set_attribute("compliance.trace_id", trace_id)
                span.set_attribute("compliance.task_name", task_name)
                span.set_attribute("compliance.row_count", len(df))
                span.set_attribute("compliance.rule_count", len(rules))

                logger.info(f"Starting compliance evaluation: {task_name}")
                logger.info(f"  Trace ID: {trace_id}")
                logger.info(f"  Rows: {len(df)}, Rules: {len(rules)}")

                # Convert DataFrame to cases
                cases = self._df_to_cases(df, input_col, output_col, context_col)

                # Initialize result structures
                # row_results[row_index][rule_name] = ComplianceRuleResult
                row_results: List[Dict[str, ComplianceRuleResult]] = [{} for _ in cases]
                rule_summaries: Dict[str, RuleSummary] = {}

                # Initialize pass counts for each rule
                rule_pass_counts: Dict[str, int] = {rule: 0 for rule in rules}

                # Batch evaluation: evaluate all rules per row in single LLM calls
                logger.info(f"  Using batch evaluation (batch_size={batch_size}, thinking={use_thinking})")

                # Create tasks for each case (evaluating all rules in batches)
                async def evaluate_case_batched(case: ComplianceCase) -> List[ComplianceRuleResult]:
                    all_results = []
                    # Split rules into batches
                    for i in range(0, len(rules), batch_size):
                        batch = rules[i:i + batch_size]
                        batch_results = await self._evaluate_batch(
                            batch, case, task_name, use_thinking
                        )
                        all_results.extend(batch_results)
                    return all_results

                tasks = [evaluate_case_batched(case) for case in cases]
                all_case_results = await asyncio.gather(*tasks, return_exceptions=True)

                # Process results
                for case_idx, case_results in enumerate(all_case_results):
                    if isinstance(case_results, Exception):
                        # Handle exceptions - mark all rules as failed
                        for rule in rules:
                            result = ComplianceRuleResult(
                                rule_name=rule[:100],
                                row_index=case_idx,
                                passed=False,
                                reason=f"Evaluation error: {str(case_results)}"
                            )
                            row_results[case_idx][rule] = result
                    else:
                        for result in case_results:
                            row_results[case_idx][result.rule_name] = result
                            if result.passed:
                                # Find original rule by prefix match
                                for rule in rules:
                                    if rule[:100] == result.rule_name:
                                        rule_pass_counts[rule] += 1
                                        break

                # Build rule summaries
                total = len(cases)
                for rule in rules:
                    passed_count = rule_pass_counts[rule]
                    rule_summaries[rule] = RuleSummary(
                        rule_name=rule,
                        total_evaluated=total,
                        passed_count=passed_count,
                        failed_count=total - passed_count,
                        pass_rate=passed_count / total if total > 0 else 0.0
                    )
                    logger.info(f"  {rule[:50]}: {passed_count}/{total} passed ({passed_count/total*100:.1f}%)")

                # Calculate overall compliance
                if rule_summaries:
                    overall_pass_rate = sum(s.pass_rate for s in rule_summaries.values()) / len(rule_summaries)
                else:
                    overall_pass_rate = 0.0

                overall_passed = overall_pass_rate >= threshold

                # Build report
                report = ComplianceReport(
                    trace_id=trace_id,
                    task_name=task_name,
                    total_rows=len(df),
                    rules_evaluated=rules,
                    rule_summaries=rule_summaries,
                    row_results=row_results,
                    overall_pass_rate=overall_pass_rate,
                    overall_passed=overall_passed
                )

                # Record final metrics on span
                span.set_attribute("compliance.overall_pass_rate", overall_pass_rate)
                span.set_attribute("compliance.overall_passed", overall_passed)

                logger.info(f"Compliance evaluation complete.")
                logger.info(f"  Overall pass rate: {overall_pass_rate:.1%}")
                logger.info(f"  Trace ID: {trace_id}")

                return report

        finally:
            # Reset trace context
            reset_context(*tokens)

    @staticmethod
    def get_traces(trace_id: str) -> List[Dict[str, Any]]:
        """
        Retrieve all traces for a given trace_id.

        Args:
            trace_id: The trace ID from a ComplianceReport

        Returns:
            List of span dictionaries from the trace file
        """
        try:
            exporter = get_exporter()
            all_spans = exporter.read_all()
            return [s for s in all_spans if s.get("trace_id") == trace_id]
        except Exception as e:
            logger.warning(f"Error reading traces: {e}")
            return []

    def to_dataframe(
        self,
        report: ComplianceReport,
        include_reasons: bool = True
    ) -> pd.DataFrame:
        """
        Convert compliance report to a DataFrame.

        Adds columns for each rule's pass/fail status.

        Args:
            report: ComplianceReport from evaluate()
            include_reasons: Whether to include reason columns (default: True)

        Returns:
            DataFrame with compliance columns added
        """
        data = []

        for row_idx, row_result in enumerate(report.row_results):
            row_data = {"row_index": row_idx}

            for rule_name, result in row_result.items():
                # Use a shorter key for the column name
                short_name = rule_name[:50] if len(rule_name) > 50 else rule_name
                row_data[f"{short_name}_passed"] = result.passed
                if include_reasons:
                    row_data[f"{short_name}_reason"] = result.reason

            data.append(row_data)

        return pd.DataFrame(data)
